require.config({

    baseUrl: "/public/js",

    paths: {
/*        'stacktrace': '//cdnjs.cloudflare.com/ajax/libs/stacktrace.js/0.6.0/stacktrace.min',
        domReady: '//cdnjs.cloudflare.com/ajax/libs/require-domReady/2.0.1/domReady',
        jquery: "//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min",
        angular: "//ajax.googleapis.com/ajax/libs/angularjs/1.2.19/angular.min",
        restangular: "//cdnjs.cloudflare.com/ajax/libs/restangular/1.4.0/restangular.min",
        uiRouter: "//cdnjs.cloudflare.com/ajax/libs/angular-ui-router/0.2.10/angular-ui-router.min",
        "ui.bootstrap": "//cdnjs.cloudflare.com/ajax/libs/angular-ui-bootstrap/0.10.0/ui-bootstrap-tpls.min",
        lodash: "//cdnjs.cloudflare.com/ajax/libs/lodash.js/2.4.1/lodash.min",
        d3: '//cdnjs.cloudflare.com/ajax/libs/d3/3.4.10/d3',
        text: "lib/requirejs-text",
        utils: "lib/utils"
*/
        'stacktrace': 'lib/stacktrace',
        domReady: 'lib/requirejs-domReady',
        jquery: "lib/jquery-v1.11.0",
        angular: "lib/angular/angular",
        restangular: "lib/angular/restangular",
        uiRouter: "lib/angular/ui-router",
        "ui.bootstrap": "lib/angularbootstrap/ui-bootstrap",
        lodash: "lib/lodash-v2.4.1",
        d3: 'lib/d3',
        text: "lib/requirejs-text",
        utils: "lib/utils",
        "angularFileUpload": 'lib/cust/angular-file-upload',
        "timer": 'lib/cust/angular-timer',
        "createEvent":'app/modules/createEvent/createEventDirective',
        "eventDetailsDeps": 'lib/angular-text-editor/textAngular',
        "eventDetails": 'app/modules/createEvent/eventDetails/eventDetailsCtrl',
        "eventContacts": 'app/modules/createEvent/eventContacts/eventContactsCtrl',
        "eventVideo": 'app/modules/createEvent/eventVideo/eventVideoCtrl',
        "eventTheme": 'app/modules/createEvent/eventThemes/eventThemeCtrl'

    },

    waitSeconds: 7000,

    shim: {
        'angular': {
            exports: 'angular'
        },
        'restangular': {
            deps:["lodash"]
        },
        'uiRouter': {
            deps:["angular"]
        },
        'ui.bootstrap': {
            deps:["angular"]
        },
        'jquery': {
            exports: '$'
        },
        'lodash': {
            exports: '_'
        },
        'd3': {
            exports: 'd3'
        },
        'createEvent':{
            deps: [
                    "angular",
                    'eventDetails',
                    'angularFileUpload',
                    'eventContacts',
                    'eventVideo',
                    'eventTheme',
                    //'app/modules/createEvent/createEventModule',
                    //'app/modules/createEvent/createEventDirective',
                    'app/modules/createEvent/createEventModel',
                    'app/modules/createEvent/createEventService'
                  ],
            exports: 'createEvent'
        },
        'eventDetailsDeps': {
            deps:[
                    "angular",
                    'lib/angular/angular-sanitize',
                    'lib/angular-text-editor/textAngular-sanitize',
                    'lib/angular-text-editor/textAngularSetup',

                 ],
            exports: 'eventDetailsDeps'
        },
        'eventDetails': {
            deps:[
                    "angular",

                    'app/modules/createEvent/eventDetails/eventDetailsService',
                    'app/modules/createEvent/eventDetails/eventDetailsModel',
                    'app/modules/createEvent/eventDetails/eventDetailsDirective'
                 ],
            exports: 'eventDetails'
        },
        'eventContacts': {
            deps:[
                    "angular",
                    'app/modules/createEvent/eventContacts/eventContactsService',
                    'app/modules/createEvent/eventContacts/eventContactsModel',
                    'app/modules/createEvent/eventContacts/eventContactsDirective'
                 ],
            exports: 'eventContacts'
        },
        'eventVideo': {
            deps:[
                    "angular",
                    'app/modules/createEvent/eventVideo/eventVideoService',
                    'app/modules/createEvent/eventVideo/eventVideoModel',
                    'app/modules/createEvent/eventVideo/eventVideoDirective',
                    'app/modules/createEvent/eventVideo/videoRecorderService',
                    'app/modules/createEvent/eventVideo/videoRecorderDirective',
                    'app/modules/createEvent/eventVideo/encodingService'
                ],
            exports: 'eventVideo'
        },
        'eventTheme': {
            deps:[
                    "angular",
                    'app/modules/createEvent/eventThemes/eventThemeService',
                    'app/modules/createEvent/eventThemes/eventThemeModel',
                    'app/modules/createEvent/eventThemes/eventThemeDirective'
                 ]
        }
    }

});


/**
 * LOAD GLOBAL SCRIPTS FIRST
 * To catch global errors
 */
require(['stacktrace'], function (stacktrace) {
    'use strict';
    window.printStackTrace = stacktrace;
});
console.log(window.document.readyState);
require(['domReady'], function (domReady) {
    console.log("In dom ready");
    require([
        'jquery',
        'angular',
        'd3',
        'utils'
    ], function(){
        console.log("main Dependencies loaded");
        console.log(angular);
        require([
                'uiRouter',
                'ui.bootstrap',
                'restangular',
                'app/app'
            ],
            function () {
                require([
                    'app/services/userModel',
                    'app/services/authService',
                    'app/services/userService',
                    'lib/cust/ocLazyLoad',
                    'lib/cust/localStorageAMD',
                    'lib/angular-strap/angular-strap',
                    'app/modules/headerModule/headerModule',
                    'app/modules/dashboard/dashboardModule',
                    'app/modules/createEvent/createEventModule',
                    'app/modules/createEvent/eventDetails/eventDetailsModule',
                    'app/modules/createEvent/eventContacts/eventContactsModule',
                    'app/modules/createEvent/eventVideo/eventVideoModule',
                    'app/modules/createEvent/eventThemes/eventThemeModule',
                    'app/modules/eventsLibrary/eventsLibraryModule',
                    'app/modules/guestModule/guestModule',
                    'app/modules/contacts/contactsModule'
                ], function(){

                    console.log("Main modules loaded");
                    require([
                            //Global dependencies
                            'lib/bootstrap/bootstrap',
                            'app/services/lazyLoadService',
                            'app/routes',
                            'app/services/loggingService',
                            'app/services/utilityService',
                            'app/modules/appModule/appController',
                            'lib/angular-strap/angular-strap.tpl',
                            'app/services/eventService',
                            'app/services/contactsService',
                            'app/services/contactsJSONModel',

                            //Header dependencies
                            'app/modules/headerModule/headerController',
                            //Events Library
                            'lib/cust/angular-socialshare',
                             'app/modules/eventsLibrary/eventsLibraryModel',
                             'app/modules/eventsLibrary/eventsLibraryCtrl',
                             'app/modules/eventsLibrary/eventsLibraryDirective',

                            //Cretae Event Dependencies
                            'app/modules/createEvent/createEventCtrl',
                            /*
                            'lib/angular/angular-sanitize',
                            'lib/angular-text-editor/textAngular-sanitize',
                            'lib/angular-text-editor/textAngularSetup',
                            'lib/angular-text-editor/textAngular',

                            'app/modules/createEvent/createEventDirective',
                            'app/modules/createEvent/createEventCtrl',
                            'app/modules/createEvent/createEventModel',
                            'app/modules/createEvent/createEventService',
                            */
                            //Dashboard dependencies

                            'app/modules/dashboard/dashboardModel',
                            'app/modules/dashboard/dashboardCtrl',
                            'app/modules/dashboard/defaultEventsCtrl',
                            //GuestModule Dependencies
                            'lib/cust/jquery.backstretch.min',
                            'app/modules/guestModule/guestCtrl',
                            'app/services/guestService',
                            'app/modules/guestModule/guestDirective',

                            //Contacts Dependencies
                             'app/modules/contactsImport/contacts-import-api',
                             'app/services/contactsService',
                             'app/modules/contacts/contactsModel',
                             'app/modules/contacts/groupsModel',
                             'app/modules/contacts/contactsCtrl',

                            //Analytics Dependencies
                            'app/modules/analytics/analyticsCtrl'

                        ],

                        function () {
                            console.log("All dependencies loaded");
                            angular.bootstrap(document.body, [
                                'Inwiter'
                            ]);

                        });
                });

            });
    });
});



