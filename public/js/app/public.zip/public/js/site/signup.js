(function(){

'use strict';

    var signup = angular.module('Signup', []);

    /**
     * Signup controller
     */
        signup.controller('SignupCtrl',['SignupService', '$scope', 'SignupModel', 'ajaxURL', function(Signup, $scope, SignupModel, ajaxURL){

            /**
             * Signup form model
             * @type {{}}
             */
            $scope.signUp = {businessName:'',businessDBA:'',guestURL:'',country:'',address1:'',address2:'',city:'',state:'',zipCode:'',phoneCode:'',phoneNum:'',firstName:'',lastName:'',emailID:'',password:'',repeatPassword:'', isNotValid: true};
            $scope.signupData = {};
            $scope.signupResponse = '';
            $scope.signupError = ''; //For view
            $scope.showSignupError = false;
            $scope.emailAvailability = false;
            $scope.guestURLAvailability = false;
            $scope.signupPromise = {};
            $scope.plan = {'name':''};
            $scope.userDefaults = {latitude:'', longitude: '', userIP: '', appType: 0, timeZoneOffSet:'', countryCode: ''};

            (function(){
                $scope.plan.name = getQueryStringData('plan');
                console.log($scope.plan.name);
                if($scope.plan.name == ''){
                    window.location = '/pricing/index';
                }
                console.log();
            })();

            /**
             * Signup form submit action
             * @param signupData {{}}
             */
            $scope.submit = function(signupData){
                console.log(signupData);
                /** store form model in scope model **/
                $scope.signupData = angular.copy(signupData);

                /** submit form after validation **/
                if(validateSignupForm($scope.signupData)){
                    signupData.plan = getQueryStringData('plan');
                    signupData.userType = getQueryStringData('userType');
                    signupData.amount = getQueryStringData('amount');
                    var signupObj = SignupModel.formSignupJSON(signupData, $scope.userDefaults);
                    console.log(signupObj);
                    var payload = 'userData='+encodeURIComponent(JSON.stringify(signupObj));
                    submitSignupForm(payload);
                }

            };

            function getQueryStringData(name) {
                name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
                var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
                    results = regex.exec(location.search);
                return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
            }

            /**
             * To submit signup form
             * @param signupData {{}}
             */
            function submitSignupForm(signupData){
                Signup.submit(signupData).then(function(response){
                    onSignupResponse(response.data);
                });
            }

            /**
             * on signup response method
             * @param data {{}}
             */
            function onSignupResponse(data){
                //Do what you want on response
                //$scope.signupResponse = data;
                console.log(data);
                //$scope.signupResponse = data.description;
                if(data.status.toUpperCase() === 'SUCCESS'){
                    window.location = ajaxURL.signupSuccessURL;
                }else{
                    $scope.signupResponse = data.description;
                }
            }

            /**
             * Set signup form in case of any error redirection
             * @param signupData {{}}
             */
            function setSignupForm(signupData){
                $scope.signupData = signupData;
            }

            /**
             * Validate signup model
             * @param data {{}}
             * @returns {boolean}
             */
            function validateSignupForm(data){
                var returnvl = true;
                /** Write validation functions here **/

                return returnvl;
            }

            /**
             * Signup error handling method
             * @param error {string}
             * @param flag {bool}
             */
            function showHideSignupError(error,flag){
                $scope.signupError = error;
                $scope.showSignupError = flag;
            }


            /**
             * check email availability for registration
             * @param emailData {{}}
             * @param data {{}}
             */
            $scope.checkEmailAvailability = function(emailData, data){
                console.log(emailData, data);
                if(data.required != true && data.emial != true) {
                    var filter = 'emailID='+ emailData;
                    Signup.checkEmailAvailability(filter).then(function (response) {
                        console.log(response);
                        if(response.data.status.toUpperCase() == 'SUCCESS'){
                            $scope.emailAvailability = true;
                            $scope.signUp.isNotValid = true;
                        }else{
                            $scope.emailAvailability = false;
                            $scope.signUp.isNotValid = false;
                        }
                        //$scope.emailAvailability = response.data;
                    });
                }
            };

            $scope.checkGuestURLAvailability = function(name){
                var filter = 'guestURL='+ name;
                Signup.checkGuestURLAvailability(filter).then(function(response){
                    console.log(response);
                    if(response.data.status.toUpperCase() == 'SUCCESS'){
                        $scope.guestURLAvailability = true;
                        $scope.signUp.isNotValid = true;
                    }else{
                        $scope.guestURLAvailability = false;
                        $scope.signUp.isNotValid = false;
                    }
                }, errorHandler)
            };


            /**
             * Auto fill user location data
             */
            (function(){
                Signup.getUserLocation().then(function(response){
                    console.log(response);
                    if(response.data.status.toUpperCase() == 'SUCCESS'){
                        setUserLocationDetails(response.data.data);
                    }
                });
            })();

            function setUserLocationDetails(data){
                $scope.signUp.city = data.city;
                $scope.signUp.country = data.country;
                $scope.signUp.state = data.region;
                $scope.userDefaults.timeZoneOffSet = getTimeZone();
                $scope.userDefaults.latitude = data.latitude;
                $scope.userDefaults.longitude = data.longitude;
                $scope.userDefaults.userIP = data.userIP;
                $scope.userDefaults.countryCode = data.countryCode;
            }

            function getTimeZone(){
                var dt = new Date(); //Wed Jul 09 2014 11:07:00 GMT+0530 (IST)
                dt = dt.toString();
                console.log(dt);
                var a = dt.split("GMT");
                var b = a[1].split(" ");
                var c = b[0].substring(0, 3);
                var d = b[0].substring(3, 7);
                var e = c+':'+d;
                console.log(e);
                return e;
            }
        }]);


    /**
     * Signup model
     * to maintain model requied by server
     */
    signup.factory('SignupModel',[function(){
        var signupJSON = {"userInfo":{"emailID":"","password":"","userType":"","paymentType":"","authenticationType":"","alternativeEmailID":"","userIP":"","latitude":"","longitude":"","appType":""},"userProfile":{"userType":"","businessName":"","businessDBA":"","firstName":"","lastName":"","middleName":"","nickName":"","birthday":"","gender":"","timeZone":"","alternativeEmailID":"","hostEmailID":"","rsvpEmailID":"","countryCode":""},"userPayment":{"emailID":"","paymentType":"","paymentSchedule":"","payment":"","paidBy":"","upgrade":""},"userAddress":{"addressType":"","addressOne":"","addressTwo":"","city":"","state":"","country":"","zipcode":"","phoneNumber":""}};
        return{
            formSignupJSON: function(data, userDefaults){
                var signupObj = angular.copy(signupJSON);
                signupObj.userInfo.emailID =  data.emailID;
                signupObj.userInfo.password = data.password;
                signupObj.userInfo.userType = data.userType; //PERSONAL OR BUSINESS
                signupObj.userInfo.paymentType = data.plan; //PAYMENT OPTION SELECTED
                signupObj.userInfo.authenticationType = ""; //FACEBOOK OR GOOGLE
                signupObj.userInfo.alternativeEmailID = "";
                signupObj.userInfo.userIP = userDefaults.userIP;
                signupObj.userInfo.latitude = userDefaults.latitude;
                signupObj.userInfo.longitude = userDefaults.longitude;
                signupObj.userInfo.appType = userDefaults.appType;

                signupObj.userProfile.userType = data.userType; //PERSONAL OR BUSINESS
                signupObj.userProfile.businessName = data.businessName;
                signupObj.userProfile.businessDBA = data.businessDBA;
                signupObj.userProfile.firstName = data.firstName;
                signupObj.userProfile.lastName = data.lastName;
                signupObj.userProfile.middleName = "";
                signupObj.userProfile.nickName = "";
                signupObj.userProfile.birthday = "";
                signupObj.userProfile.gender = "";
                signupObj.userProfile.timeZone = userDefaults.timeZoneOffSet;
                signupObj.userProfile.alternativeEmailID = "";
                signupObj.userProfile.hostEmailID = data.emailID; //SAME AS USER EMAIL ID
                signupObj.userProfile.rsvpEmailID = data.emailID; //SAME AS USER EMAIL ID
                signupObj.userProfile.countryCode = userDefaults.countryCode;
                signupObj.userProfile.personalizedURL = data.guestURL;

                signupObj.userPayment.emailID = data.emailID;
                signupObj.userPayment.paymentType = data.plan; //PAYMENT OPTION SELECTED
                signupObj.userPayment.paymentSchedule = "";
                signupObj.userPayment.payment = data.amount; //PAY AMOUNT
                signupObj.userPayment.paidBy = ""; // PAID USING
                signupObj.userPayment.upgrade = "0";

                signupObj.userAddress.addressType = "";
                signupObj.userAddress.addressOne = data.address1;
                signupObj.userAddress.addressTwo = data.address2;
                signupObj.userAddress.city = data.city;
                signupObj.userAddress.state = data.state;
                signupObj.userAddress.country = data.country;
                signupObj.userAddress.zipcode = data.zipCode;
                signupObj.userAddress.phoneNumber = data.phoneCode+data.phoneNumber;
                return signupObj;
            }
        }
    }]);

    /**
     * Signup service for server side communication
     *
     */
        signup.factory('SignupService',['$http','ajaxURL',function($http, URL){
            return {
                /**
                 * submit signup details to server
                 * @param signupData {{}}
                 * @returns {event}
                 */
              submit: function(signupData){
                    console.log(signupData);
                    var promise = $http({
                                            url: URL.signupSubmit.toString(),
                                            method: 'post',
                                            data: signupData,
                                            headers: {
                                                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                                            }
                                        }).success(function(response){
                        return response;
                    });
                    return promise;
              },
                /**
                 * check email availability from server
                  * @param emailData {{}}
                 * @returns {event}
                 */
              checkEmailAvailability: function(emailData){
                    console.log(emailData);
                  var promise = $http({
                                        url: (URL.signupCheckEmailAvailability).toString(),
                                        data: emailData,
                                        headers: {
                                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                                        }
                                       }).success(function(response){
                      return response;
                  });
                  return promise;
              },
              checkGuestURLAvailability: function(name){
                  var promise = $http({
                                        url: (URL.signupGuestURLAvailability).toString(),
                                        data: name,
                                        headers:{
                                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                                        }
                                      }).success(function(response){
                      return response;
                  });
                  return promise;
              },
              getUserLocation: function(){
                  var promise = $http({
                                          url: (URL.signupUserLocation).toString(),
                                          method: 'get'
                                     });
                  return promise;
              }
            };
        }]);

    /**
     * Signup directives
     */
        signup.directive('checkEmailAvailability',[function(){
            return{
                restrict: 'A',
                require: 'ngModel',
                link: function(scope, elm, attr){
                    if(attr.type === 'text'){
                        elm.unbind('input').unbind('keydown').unbind('change');
                        elm.bind('blur', function(){
                            var emailData = {"email": elm.val()};
                            scope.checkEmailAvailability(emailData);
                        });
                    }else{
                        return;
                    }
                }
            }
        }]);

    /**
     * Password match directive
     */
        signup.directive('match', function () {
            return {
                require: 'ngModel',
                restrict: 'A',
                scope: {
                    match: '='
                },
                link: function(scope, elem, attrs, ctrl) {
                    scope.$watch(function() {
                        return (ctrl.$pristine && angular.isUndefined(ctrl.$modelValue)) || scope.match === ctrl.$modelValue;
                    }, function(currentValue) {
                        ctrl.$setValidity('match', currentValue);
                    });
                }
            };
        });

    /**
     * Signup constant values for http requests
     */
        signup.value("ajaxURL",{
                                "signupSubmit": ajaxURL.signupSubmit,
                                "signupCheckEmailAvailability": ajaxURL.signupCheckEmailAvailability,
                                "signupGuestURLAvailability": ajaxURL.signupGuestURLAvailability,
                                "signupSuccessURL": ajaxURL.signupSuccessURL,
                                "signupUserLocation": ajaxURL.signupUserLocation
                                }
                    );
})();
