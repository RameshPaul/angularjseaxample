/**
 * Mock json static class
 */
function mockjson(){}

/**
 * Mock json configuration value
 * By default false
 * true => for testing with mock json
 * false => for testing with real data
 * @type {boolean}
 */
mockjson.isActive = true;

/**
 * Signup data mock object
 * @type {{}}
 */
mockjson.signupData = {};

/**
 * Signin mock data object
 * @type {{}}
 */
mockjson.signinData = {"userid":"2","email":"ramesh@inwiter.com","clientId":"123456789","clientSecret":"a1b2c3d4e5f6","accessToken":"AP16MD3217"};

/**
 * Ajax URL function
 */
function ajaxURL(){}

/** SIGNUP **/
ajaxURL.signupSubmit = '/signup/doRegistration/';
ajaxURL.signupCheckEmailAvailability = '/user/checkEmail/';
ajaxURL.signupGuestURLAvailability = '/user/checkGuestURL/';
ajaxURL.signupSuccessURL = '/signup/success/';
ajaxURL.signupUserLocation = '/getuserlocation/';

/** SIGNIN **/
ajaxURL.signinSubmit = '/signin/doSignIn/';
ajaxURL.signinSuccessURL = '/dashboard';

/** FORGOTPASSWORD **/
ajaxURL.forgotPasswordSubmit = '/forgotpassword/';

/** RESETPASSWORD **/
ajaxURL.resetPasswordSubmit = '/resetpassword/submit/';

