(function(){

    'use strict';

    var signin = angular.module('Signin', []);

    /**
     * Signin controller
     */
    signin.controller('SigninCtrl',['SigninService', '$scope', 'ajaxURL', function(Signin, $scope, ajaxURL){

        /**
         * Signin form model
         * @type {{}}
         */
        $scope.signin = {};
        $scope.signinData = {};
        $scope.signinResponse = '';
        $scope.signinError = ''; //For view
        $scope.showSigninError = false;
        $scope.emailAvailability = true;
        $scope.signinPromise = {};
        $scope.signinMessage = '';


        /**
         * Signin form submit action
         * @param signinData {{}}
         */
        $scope.login = function(signinData){
            console.log("in update");
            /** store form model in scope model **/
            $scope.signinData = angular.copy(signinData);
            var data = 'emailID='+$scope.signinData.emailID+'&password='+encodeURIComponent($scope.signinData.password);

            /** submit form after validation **/
            if(validateSigninForm($scope.signinData)){
                console.log('Validation passed');
                submitSigninForm(data);
            }

        };

        /**
         * To submit signin form
         * @param signinData {{}}
         */
        function submitSigninForm(signinData){
            Signin.submit(signinData).then(function(response){
                onSigninResponse(response.data);
            });
        }

        /**
         * on signin response method
         * @param data {{}}
         */
        function onSigninResponse(data){
            //Do what you want on response
            console.log(data);

            if(data.status.toUpperCase() == 'SUCCESS'){
              if(data.data.emailVerify == '0'){
                $scope.signinResponse = 'Email not verified please verify email';//data.description;
              }else{
                window.location = ajaxURL.signinSuccessURL;
              }
            }else{
                $scope.signinResponse = data.description;
            }
        }

        /**
         * To handle signin submit event
         */
        function signinSubmitEvent(){
            $scope.signinPromise.then(function(response){
                console.log("http response");
                $scope.signinResponse = response;
                onSigninResponse($scope.signinResponse);
            });
        }

        /**
         * Set signin form in case of any error redirection
         * @param signinData {{}}
         */
        function setSigninForm(signinData){
            $scope.signinData = signinData;
        }

        /**
         * Validate signin model
         * @param data {{}}
         * @returns {boolean}
         */
        function validateSigninForm(data){
            var returnvl = true;
            /** Write validation functions here **/

            return returnvl;
        }

        /**
         * Signin error handling method
         * @param error {string}
         * @param flag {bool}
         */
        function showHideSigninError(error,flag){
            $scope.signinError = error;
            $scope.showSigninError = flag;
        }


    }]);

    /**
     * Signin service for server side communication
     *
     */
    signin.factory('SigninService',['$http','ajaxURL',function($http,URL){
        return {
            /**
             * submit signin details to server
             * @param signinData {{}}
             * @returns {event}
             */
            submit: function(signinData){
                console.log(signinData);
                var promise = $http({
                                        url: (URL.signinSubmit).toString(),
                                        method: 'post',
                                        data: signinData,
                                        headers: {
                                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                                        }
                                    }).success(function(response){
                    return response;
                });
                return promise;
            }
        };
    }]);


    /**
     * Signin configuration
     *
     */
    //signin.value("ajaxURL",{"signinSubmit": ajaxURL.signinSubmit, "signinSuccessURL":ajaxURL.signinSuccessURL});


    /**
    *   FORGOT PASSWORD FUNCTIONALITY
    **/
    var forgotpassword = signin;

    forgotpassword.controller('ForgotPasswordCtrl',['ForgotpasswordService', '$scope',function(forgotpassword, $scope){

        /**
         * forgotpassword form model
         * @type {{}}
         */
        $scope.forgotpasswordData = {};
        $scope.forgotpasswordResponse = '';
        $scope.forgotpasswordError = ''; //For view
        $scope.showforgotpasswordError = false;
        $scope.emailAvailability = true;
        $scope.forgotpasswordPromise = {};

        console.log("IN forgotpassword ctrl");

        /**
         * forgotpassword form submit action
         * @param forgotpasswordData {{}}
         */
        $scope.forgotPassword = function(forgotpasswordData){

            /** store form model in scope model **/
            $scope.forgotpasswordData = angular.copy(forgotpasswordData);
            console.log('Forgot Password data: ', forgotpasswordData);
            var data = 'emailID='+$scope.forgotpasswordData.emailID;
            /** submit form after validation **/
            if(validateforgotpasswordForm($scope.forgotpasswordData)){
                submitforgotpasswordForm(data);
            }

        };

        /**
         * To submit forgotpassword form
         * @param forgotpasswordData {{}}
         */
        function submitforgotpasswordForm(forgotpasswordData){
            forgotpassword.submit(forgotpasswordData).then(function(response){
                onforgotpasswordResponse(response.data);
            });
        }


        /**
         * Set forgotpassword form in case of any error redirection
         * @param forgotpasswordData {{}}
         */
        function setforgotpasswordForm(forgotpasswordData){
            $scope.forgotpasswordData = forgotpasswordData;
        }

        /**
         * Validate forgotpassword model
         * @param data {{}}
         * @returns {boolean}
         */
        function validateforgotpasswordForm(data){
            var returnvl = true;
            /** Write validation functions here **/

            return returnvl;
        }

        /**
         * forgotpassword error handling method
         * @param error {string}
         * @param flag {bool}
         */
        function showHideforgotpasswordError(error,flag){
            $scope.forgotpasswordError = error;
            $scope.showforgotpasswordError = flag;
        }

        /**
         * on forgotpassword response method
         * @param data {{}}
         */
        function onforgotpasswordResponse(data){
            //Do what you want on response
            $scope.forgotpasswordResponse = data.description;
        }

        /**
         * Handle signup success
         * @param data {{}}
         */
        function handleforgotpasswordSuccess(data){
            //Do what you want to do after forgotpassword response
            //Based on user business status navigate to payment gateway or dashboard

        }
    }]);

    /**
     * forgotpassword service for server side communication
     *
     */
    forgotpassword.factory('ForgotpasswordService',['$http','ajaxURL',function($http,URL){
        console.log("in forgotpassword service");
        return {
            /**
             * submit forgotpassword details to server
             * @param forgotpasswordData {{}}
             * @returns {event}
             */
            submit: function(forgotpasswordData){
                console.log(forgotpasswordData);
                var promise = $http({
                                        url: (URL.forgotPasswordSubmit).toString(),
                                        method: 'post',
                                        data: forgotpasswordData,
                                        headers: {
                                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                                    }
                }).success(function(response){
                    return response;
                });
                return promise;
        }
        };
    }]);


    /**
     * forgotpassword configuration
     *
     */
    forgotpassword.value("ajaxURL",{"signinSubmit": ajaxURL.signinSubmit, "signinSuccessURL":ajaxURL.signinSuccessURL, "forgotPasswordSubmit": ajaxURL.forgotPasswordSubmit});

})();
