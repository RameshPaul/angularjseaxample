(function(){

    'use strict';

    var login = angular.module('AppLogin', ['LocalStorage']);

    /**
     * App login class
     */
    login.factory('AppLoginService',['LocalStorageSerice', '$scope',function(LocalStorage, $scope){
        console.log("in app login service");
        return{
            setUser: function(userData){
                //Clear all Localstorage before setting data
                LocalStorage.clearAll();
                LocalStorage.set('_inwiterAppUser',userData);
            },
            getUser: function(){
                return LocalStorage.get('_inwiterAppUser');
            }
        };
    }]);


})();
