(function(){

    'use strict';

    var resetpassword = angular.module('Resetpassword', []);

    /**
     * resetpassword controller
     */
    resetpassword.controller('ResetpasswordCtrl',['ResetpasswordService', '$scope',function(resetpassword, $scope){

        /**
         * resetpassword form model
         * @type {{}}
         */
        $scope.resetpasswordData = {};
        $scope.resetpasswordResponse = {};
        $scope.resetpasswordError = ''; //For view
        $scope.showresetpasswordError = false;
        $scope.emailAvailability = true;


        /**
         * resetpassword form submit action
         * @param resetpasswordData {{}}
         */
        $scope.update = function(resetpasswordData){

            /** store form model in scope model **/
            $scope.resetpasswordData = angular.copy(resetpasswordData);

            /** submit form after validation **/
            if(validateresetpasswordForm($scope.resetpasswordData)){
                submitresetpasswordForm(resetpasswordData);
            }

        }

        /**
         * To submit resetpassword form
         * @param resetpasswordData {{}}
         */
        function submitresetpasswordForm(resetpasswordData){
            resetpassword.submit(resetpasswordData).then(function(response){
                onresetpasswordResponse(response.data);
            });
        }


        /**
         * Set resetpassword form in case of any error redirection
         * @param resetpasswordData {{}}
         */
        function setresetpasswordForm(resetpasswordData){
            $scope.resetpasswordData = resetpasswordData;
        }

        /**
         * Validate resetpassword model
         * @param data {{}}
         * @returns {boolean}
         */
        function validateresetpasswordForm(data){
            var returnvl = true;
            /** Write validation functions here **/

            return returnvl;
        }

        /**
         * resetpassword error handling method
         * @param error {string}
         * @param flag {bool}
         */
        function showHideresetpasswordError(error,flag){
            $scope.resetpasswordError = error;
            $scope.showresetpasswordError = flag;
        }

        /**
         * on resetpassword response method
         * @param data {{}}
         */
        function onresetpasswordResponse(data){
            //Do what you want on response
            $scope.resetpasswordResponse = data;
        }

        /**
         * Handle signup success
         * @param data {{}}
         */
        function handleresetpasswordSuccess(data){
            //Do what you want to do after resetpassword response
            //Based on user business status navigate to payment gateway or dashboard

        }
    }]);

    /**
     * resetpassword service for server side communication
     *
     */
    resetpassword.factory('ResetpasswordService',['$http','ajaxURL',function($http,URL){
        return {
            /**
             * submit resetpassword details to server
             * @param resetpasswordData {{}}
             * @returns {event}
             */
            submit: function(resetpasswordData){
                var promise = $http.post((URL.resetPasswordSubmit).toString(), resetpasswordData).success(function(response){
                    return response;
                });
                return promise;
            }
        };
    }]);


    /**
     * resetpassword configuration
     *
     */
    resetpassword.value("ajaxURL",{"resetPasswordSubmit": ajaxURL.resetPasswordSubmit});

})();
