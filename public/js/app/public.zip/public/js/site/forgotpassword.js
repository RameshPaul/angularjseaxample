(function(){

    'use strict';

    var forgotpassword = angular.module('Signin');

    console.log("forgotpassword module");
    /**
     * forgotpassword controller
     */
    forgotpassword.controller('ForgotPasswordCtrl',['ForgotpasswordService', '$scope',function(forgotpassword, $scope){

        /**
         * forgotpassword form model
         * @type {{}}
         */
        $scope.forgotpasswordData = {};
        $scope.forgotpasswordResponse = {};
        $scope.forgotpasswordError = ''; //For view
        $scope.showforgotpasswordError = false;
        $scope.emailAvailability = true;
        $scope.forgotpasswordPromise = {};

        console.log("IN forgotpassword ctrl");

        /**
         * forgotpassword form submit action
         * @param forgotpasswordData {{}}
         */
        $scope.forgotPassword = function(forgotpasswordData){

            /** store form model in scope model **/
            $scope.forgotpasswordData = angular.copy(forgotpasswordData);
            console.log('Forgot Password data: ', forgotpasswordData);
            var data = 'emailID='+$scope.forgotpasswordData.emailID;
            /** submit form after validation **/
            if(validateforgotpasswordForm($scope.forgotpasswordData)){
                submitforgotpasswordForm(data);
            }

        };

        /**
         * To submit forgotpassword form
         * @param forgotpasswordData {{}}
         */
        function submitforgotpasswordForm(forgotpasswordData){
            forgotpassword.submit(forgotpasswordData).then(function(response){
                onforgotpasswordResponse(response.data);
            });
        }


        /**
         * Set forgotpassword form in case of any error redirection
         * @param forgotpasswordData {{}}
         */
        function setforgotpasswordForm(forgotpasswordData){
            $scope.forgotpasswordData = forgotpasswordData;
        }

        /**
         * Validate forgotpassword model
         * @param data {{}}
         * @returns {boolean}
         */
        function validateforgotpasswordForm(data){
            var returnvl = true;
            /** Write validation functions here **/

            return returnvl;
        }

        /**
         * forgotpassword error handling method
         * @param error {string}
         * @param flag {bool}
         */
        function showHideforgotpasswordError(error,flag){
            $scope.forgotpasswordError = error;
            $scope.showforgotpasswordError = flag;
        }

        /**
         * on forgotpassword response method
         * @param data {{}}
         */
        function onforgotpasswordResponse(data){
            //Do what you want on response
            $scope.forgotpasswordResponse = data;
        }

        /**
         * Handle signup success
         * @param data {{}}
         */
        function handleforgotpasswordSuccess(data){
            //Do what you want to do after forgotpassword response
            //Based on user business status navigate to payment gateway or dashboard

        }
    }]);

    /**
     * forgotpassword service for server side communication
     *
     */
    forgotpassword.factory('ForgotpasswordService',['$http','ajaxURL',function($http,URL){
        console.log("in forgotpassword service");
        return {
            /**
             * submit forgotpassword details to server
             * @param forgotpasswordData {{}}
             * @returns {event}
             */
            submit: function(forgotpasswordData){
                console.log(forgotpasswordData);
                var promise = $http({
                                        url: (URL.forgotPasswordSubmit).toString(),
                                        method: 'post',
                                        data: forgotpasswordData,
                                        headers: {
                                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                                    }
                }).success(function(response){
                    return response;
                });
                return promise;
        }
        };
    }]);


    /**
     * forgotpassword configuration
     *
     */
    forgotpassword.value("ajaxURL",{"forgotPasswordSubmit": ajaxURL.forgotPasswordSubmit});

})();
