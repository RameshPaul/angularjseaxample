define(['angular'], function(){

    var inwiterApp = angular.module("Inwiter");

    inwiterApp.factory('isUserLoggedIn',['$http', 'ajaxURL', 'AuthService', 'UserModel', function($http, ajaxURL, AuthService, UserModel){
        var resolver = {
            isUserLoggedIn: function(){
                console.log("app login service resolve");

                $http({method: 'GET', url: ajaxURL.userID.toString()}).then(function(res){
                    console.log(res);
                    var response = res.data;
                    if(response.status.toUpperCase() === 'SUCCESS'){
                        getUserDetails(response.data.userID);
                    }else{
                        errorHandler(response);
                    }
                },errorHandler);

                function getUserDetails(userID){
                    $http({method: 'GET', url: ajaxURL.userDetails+userID}).then(function(response){
                        console.log(response);
                        var res = response.data;
                        if(res.status.toUpperCase() === 'SUCCESS'){
                            setUserDetails(res.data);
                        }else{
                            errorHandler(res)
                        }
                    },errorHandler);
                }

                function errorHandler(response){
                    console.log(response.description);
                    window.location = '/home';
                }

                function setUserDetails(res){
                    var userAuth = {};
                    var userDetails = {};
                    userAuth.userID = res.userAPIKeys.userID;
                    userAuth.userName = res.userProfile.firstName+' '+res.userProfile.lastName;
                    userAuth.appID = res.userAPIKeys.appID;
                    userAuth.appSecret = res.userAPIKeys.appSecret;
                    userAuth.accessToken = res.userAPIKeys.accessToken;
                    AuthService.login(userAuth);

                    userDetails.userID = res.userAPIKeys.userID;
                    userDetails.userName = res.userProfile.firstName+' '+res.userProfile.lastName;
                    userDetails.userEmail = res.userProfile.hostEmailID;
                    userDetails.userType = res.userProfile.userType;
                    userDetails.userStatus = res.userProfile.status;
                    userDetails.planExpired = res.userPayment.paymentStatus;
                    UserModel.setUser(userDetails);
                    var paymentStatus = userDetails.planExpired;
                    if(paymentStatus){
                        //TODO CONTINUEUE
                    }else{
                        //TODO REDIRECT TO PAYMENT SCREEN
                    }
                }

                return {};
            }

        };
        return resolver.isUserLoggedIn();
    }]);

});