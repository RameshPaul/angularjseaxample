define([
        'angular'
    ],
    function (angular) {

        angular.module('Inwiter')

            .factory('UserModel', ['$rootScope', function ($rootScope) {

                var userModel = {};
                    this.userID = userModel.userId;
                    this.userName = userModel.userName;
                    this.firstName = userModel.firstName;
                    this.lastName = userModel.lastName;
                    this.userEmail = userModel.userEmail;
                    this.userType = userModel.userType;
                    this.userStatus = userModel.userStatus;
                    this.planExpired = userModel.planExpired;
                    this.businessDBA = userModel.businessDBA;
                    this.rsvpEmailID = userModel.rsvpEmailID;
                    this.timeZone = userModel.timeZone;
                    this.personalizedURL = userModel.personalizedURL;

                return {
                    /**
                     * Set user model for further reference
                     * @param user
                     */
                    setUser: function(user){
                        userModel = user;
                        console.log("User model is set", user);
                        $rootScope.$emit("onUserModelReady");
                    },
                    /**
                     * To return user model whoever asks
                     * @returns {{}}
                     */
                    getUser: function(){
                        return userModel;
                    },
                    /**
                     * To update user data if needed
                     * @param data
                     */
                    updateUserData: function(data){

                    }

                }

            }]);

    });