define([
        'angular'
    ],
    function (angular) {
        var loggingModule = angular.module('Inwiter');

        /**
         * Service that gives us a nice Angular-esque wrapper around the
         * stackTrace.js pintStackTrace() method.
         */
        loggingModule.factory(
            "traceService",
            function () {
                return({
                    print: printStackTrace
                });
            }
        );

        /**
         * Override Angular's built in exception handler, and tell it to
         * use our new exceptionLoggingService which is defined below
         */
        loggingModule.provider(
            "$exceptionHandler", {
                $get: function (exceptionLogService) {
                    return(exceptionLogService);
                }
            }
        );

        /**
         * Exception Logging Service, currently only used by the $exceptionHandler
         * it preserves the default behaviour ( logging to the console) but
         * also posts the error server side after generating a stacktrace.
         */
        loggingModule.factory(
            "exceptionLogService",
            ["$log", "$window", "traceService", "ajaxURL",
                function ($log, $window, traceService, ajaxURL) {
                    function error(exception, cause) {

                        // preserve the default behaviour which will log the error
                        // to the console, and allow the application to continue running.
                        $log.error.apply($log, arguments);

                        // now try to log the error to the server side.
                        try {
                            var errorMessage = exception.toString();

                            // use our traceService to generate a stack trace
                            var stackTrace = traceService.print({e: exception});

                            // use AJAX (in this example jQuery) and NOT
                            // an angular service such as $http
                            jQuery.ajax({
                                type: "POST",
                                url: (ajaxURL.errorLoggingURL).toString(),
                                contentType: "application/json",
                                data: angular.toJson({
                                    url: $window.location.href,
                                    message: errorMessage,
                                    type: "exception",
                                    stackTrace: stackTrace,
                                    cause: ( cause || "")
                                })
                            });
                        } catch (loggingError) {
                            $log.warn("Error server-side logging failed");
                            $log.log(loggingError);
                        }
                    }

                    return(error);
                }]
        );
        /**
         * Application Logging Service to give us a way of logging
         * error / debug statements from the client to the server.
         */
        loggingModule.factory(
            "appLogService",
            ["$log", "$window", "ajaxURL", function ($log, $window, ajaxURL) {

                return({
                    error: function (message) {
                        // preserve default behaviour
                        $log.error.apply($log, arguments);
                        // send server side
                        jQuery.ajax({
                            type: "POST",
                            url: (ajaxURL.errorLoggingURL).toString(),
                            contentType: "application/json",
                            data: angular.toJson({
                                url: $window.location.href,
                                message: message,
                                type: "error"
                            })
                        });
                    },
                    debug: function (message) {
                        $log.log.apply($log, arguments);
                        jQuery.ajax({
                            type: "POST",
                            url: (ajaxURL.errorLoggingURL).toString(),
                            contentType: "application/json",
                            data: angular.toJson({
                                url: $window.location.href,
                                message: message,
                                type: "debug"
                            })
                        });
                    }
                });
            }]
        );
    });