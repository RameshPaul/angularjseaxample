define([
    'angular'
],
function (angular) {

    angular.module('Inwiter')

        .factory('LazyLoadService', ['$ocLazyLoad', function ($ocLazyLoad) {

            var lazyLoad =
               {
                loadCSS: function(url){
                    var link = document.createElement("link");
                    link.type = "text/css";
                    link.rel = "stylesheet";
                    link.href = url;
                    document.getElementsByTagName("head")[0].appendChild(link);
                },
                createEvent : {
                    textEditor: function(){
                        var lazy = $ocLazyLoad.load([{
                            name: 'textAngular',
                            files: [
                                '/public/js/lib/angular/angular-sanitize.js',
                                '/public/js/lib/angular-text-editor/textAngular-sanitize.js',
                                '/public/js/lib/angular-text-editor/textAngularSetup.js',
                                '/public/js/lib/angular-text-editor/textAngular.js'
                            ]
                        }]).then(function() {
                            console.log("text angular loaded");
                        });
                        return lazy;
                    },
                    googleAddressLocation: function(){
                        var lazy = $ocLazyLoad.load([{
                            name: 'GoogleLocationModule',
                            files: [
                                '/public/js/lib/cust/googleLocationHelper.js'
                            ]
                        }]).then(function() {
                            console.log("google mpas helper loaded");
                        });
                        return lazy;
                    },
                    eventDetails : function (callback) {
                       var lazy = $ocLazyLoad.load([{
                                    name: 'Inwiter.CreateEvent.EventDetails',
                                    files: [
                                            '/public/js/app/modules/createEvent/eventDetails/eventDetailsModule.js',
                                            '/public/js/app/modules/createEvent/eventDetails/eventDetailsService.js',
                                            '/public/js/app/modules/createEvent/eventDetails/eventDetailsModel.js',
                                            '/public/js/app/modules/createEvent/eventDetails/eventDetailsDirective.js',
                                            '/public/js/app/modules/createEvent/eventDetails/eventDetailsCtrl.js'
                                        ]
                                }]).then(function() {
                                    callback();
                                });
                        return lazy;
                   },
                    eventContacts : function () {
                        var lazy = $ocLazyLoad.load([{
                            name: 'Inwiter.CreateEvent.EventContacts',
                            files: [
                                '/public/js/app/modules/createEvent/eventContacts/eventContactsModule.js',
                                '/public/js/app/modules/createEvent/eventContacts/eventContactsService.js',
                                '/public/js/app/modules/createEvent/eventContacts/eventContactsModel.js',
                                '/public/js/app/modules/createEvent/eventContacts/eventContactsDirective.js',
                                '/public/js/app/modules/createEvent/eventContacts/eventContactsCtrl.js'
                            ]
                        }]).then(function() {
                            console.log('Event contacts module loading done');
                        });
                        return lazy;
                    },
                    eventVideoDependencies: function(module){

                        if(module == 'fileUpload'){
                            var lazy = $ocLazyLoad.load([{
                                name: 'angularFileUpload',
                                files: [
                                    '/public/js/lib/cust/es5-shim.js',
                                    '/public/js/lib/cust/angular-file-upload.js'
                                ]
                            }]).then(function() {
                                console.log('Event video module loading done');
                            });
                            return lazy;
                        }

                        if(module == 'timer'){
                            var lazy = $ocLazyLoad.load([{
                                name: 'timer',
                                files: [
                                    '/public/js/lib/cust/angular-timer.js'
                                ]
                            }]).then(function() {
                                console.log('Event video module loading done');
                            });
                            return lazy;
                        }

                    },
                    eventVideo: function(){
                        var lazy = $ocLazyLoad.load([{
                            name: 'Inwiter.CreateEvent.EventVideo',
                            files: [
                                '/public/js/app/modules/createEvent/eventVideo/eventVideoModule.js',
                                '/public/js/app/modules/createEvent/eventVideo/eventVideoService.js',
                                '/public/js/app/modules/createEvent/eventVideo/eventVideoModel.js',
                                '/public/js/app/modules/createEvent/eventVideo/eventVideoDirective.js',
                                '/public/js/app/modules/createEvent/eventVideo/videoRecorderService.js',
                                '/public/js/app/modules/createEvent/eventVideo/videoRecorderDirective.js',
                                '/public/js/app/modules/createEvent/eventVideo/encodingService.js',
                                '/public/js/app/modules/createEvent/eventVideo/eventVideoCtrl.js'
                            ]
                        }]).then(function() {
                            console.log('Event video module loading done');
                        });
                        return lazy;
                    },
                    eventTheme: function(){
                        var lazy = $ocLazyLoad.load([{
                            name: 'Inwiter.CreateEvent.EventTheme',
                            files: [
                                '/public/js/app/modules/createEvent/eventThemes/eventThemeModule.js',
                                '/public/js/app/modules/createEvent/eventThemes/eventThemeService.js',
                                '/public/js/app/modules/createEvent/eventThemes/eventThemeModel.js',
                                '/public/js/app/modules/createEvent/eventThemes/eventThemeDirective.js',
                                '/public/js/app/modules/createEvent/eventThemes/eventThemeCtrl.js'
                            ]
                        }]).then(function() {
                            console.log('Event video module loading done');
                        });
                        return lazy;
                    }
                },
                HTML5Player: function(){
                    var link = document.createElement("link");
                    link.type = "text/css";
                    link.rel = "stylesheet";
                    link.href = '/public/js/lib/video-js/video-js.css';
                    document.getElementsByTagName("head")[0].appendChild(link);

                    require(['/public/js/lib/video-js/video.dev.js'], function (videojs) {
                         console.log("HTML5 videojs loaded");
                    });
                },
                loadAll: function(callback){
                    require([
                                'eventContacts',
                            ], function () {
                                        'use strict';
                                        //window.moment = moment;
                                        console.log("requirejs complete - event contacts module loaded");
                                        //angular.module('Inwiter.CreateEvent.EventDetails').register = registerObject;
                                        callback();
                                    });
                }
            };

            return lazyLoad;

        }]);

});