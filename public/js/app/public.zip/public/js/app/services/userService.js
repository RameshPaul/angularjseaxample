define([
    'angular'
],
function (angular) {

    angular.module('Inwiter')

        .factory('UserService', ['Restangular', function (Restangular) {

            return Restangular.service('user');

        }]);

});