define([
        'angular'
    ],
    function (angular) {

       var inwiterApp = angular.module('Inwiter');

            // main factory for authentication/currentuser information
            inwiterApp.factory('AuthService', ['Restangular', 'UserModel', 'ajaxURL', '$http', function (Restangular, UserModel, ajaxURL, $http) {

                    var user = {};
                    var currentUserId = 0;
                    var authorized = false;

                    var initialState = true;

                    var currentUser = '';

                    //USER API ACCESS
                    var clientId = '',
                        clientSecret = '',
                        accessToken = '';

            var AuthService;
                AuthService = {
                                initialState: function () {
                                    return initialState;
                                },
                                currentUserId: function(){
                                    return currentUserId;
                                },
                                login: function (userData) {
                                    //Call API Login
                                    user = userData;
                                    currentUser = userData.userName;
                                    currentUserId = userData.userID;
                                    authorized = true;
                                    initialState = false;
                                    clientId = userData.appID;
                                    clientSecret = userData.appSecret;
                                    accessToken = userData.accessToken;
                                    AuthService.setAuthDefaults();
                                    console.log("Auth login set", userData);
                                },
                                logout: function () {
                                    user = {};
                                    currentUser = null;
                                    currentUserId = 0;
                                    authorized = false;
                                    initialState = true;
                                    clientId = null;
                                    clientSecret = null;
                                    accessToken = null;
                                },
                                /**
                                 * Set default authentication headers for rest api call
                                 *
                                 */
                                setAuthDefaults: function(){
                                    Restangular.setDefaultHeaders(
                                        {
                                            "appID": clientId,
                                            "appSecret": clientSecret,
                                            "accessToken": accessToken,
                                            "Content-type": "application/x-www-form-urlencoded; charset=UTF-8"
                                        }
                                    );
                                },
                                getAccessToken: function(){
                                    return accessToken;
                                },
                                isLoggedIn: function () {
                                    return authorized;
                                },
                                authorized: function () {
                                    return authorized;
                                },
                                getHeaders: function(){
                                    return{
                                        "appID": clientId,
                                        "appSecret": clientSecret,
                                        "accessToken": accessToken
                                    }
                                },
                                isUserAlive: function(){
                                    var xhr = $http({method: 'GET', url: ajaxURL.userID});
                                    return xhr;
                                }
                    };

                if(currentUserId == 0){
                   // AuthService.getAuthorize();
                }
                return AuthService;
            }]);

            inwiterApp.value('ajaxURL',{"errorLoggingURL":"/jserrorlog", "userDetails":"/user/getuserdata/", "userID":"/user/getuserid/"});

    });