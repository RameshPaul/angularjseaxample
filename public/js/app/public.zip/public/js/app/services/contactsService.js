define([
    'angular'
],
function (angular) {

    var contacts = angular.module('Inwiter.Contacts');
    if(contacts.register != undefined){
        contacts = contacts.register;
    }
        contacts.factory('ContactsService', ['Restangular', 'AuthService', function (Restangular, Auth) {

            var contactsURL = Restangular.service('contacts', Restangular.one('user', Auth.currentUserId()));
            var groupsURL = Restangular.service('groups', Restangular.one('user', Auth.currentUserId()));
            var csvURL = Restangular.service('importcsv', Restangular.one('user', Auth.currentUserId()));

            return{
                /** CONTACTS **/
                getContacts: function(){
                    //return contactsURL; //GET REQUEST
                    return contactsURL.one();
                },
                createContacts: function(){
                    //return contactsURL; //PUT REQUEST
                    return contactsURL.one();
                },
                deleteContacts: function(){
                    return contactsURL.one(); //DELETE REQUEST
                },
                updateContacts: function(){
                    return contactsURL; //POST REQUEST
                },
                /** GROUPS **/
                createGroup: function(){
                   //return groupsURL; //PUT REQUEST
                    return groupsURL.one();
                },
                getGroups: function(){
                    //return groupsURL; //GET REQUEST
                    return groupsURL.one();
                },
                getGroupContacts: function(groupId){
                    //return Restangular.service(groupsURL, groupId); //GET REQUEST
                    return groupsURL.one(groupId);
                },
                renameGroup: function(groupId){
                    return groupsURL.one(groupId); //POST REQUEST
                },
                deleteGroups: function(){
                    return groupsURL.one(); //DELETE REQUEST
                },
                addGroupContacts: function(groupId){
                    return groupsURL.one(groupId); //PUT REQUEST
                },
                importCSVContacts: function(){
                    return csvURL.one();
                }
            }

        }]);

});