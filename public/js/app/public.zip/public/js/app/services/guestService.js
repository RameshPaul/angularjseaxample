define([
    'angular'
],
function (angular) {

var guest = angular.module('Inwiter');
    if(guest.register != undefined){
        guest = guest.register;
    }
        guest.factory('GuestService', ['Restangular', function (Restangular) {
            var url = Restangular.one('guests');
            return {
                eventID: function(transactionID){
                    return url.one(transactionID);
                },
                details : function(eventID){
                    return url.one(eventID).one('eventdetails');
                },
                scheduleInfo: function(){
                    return url.one(eventID).one('scheduleinfo');
                },
                videoTimeline: function(){
                  return url.one(eventID).one('videotimeline');
                },
                rsvp: function(eventID){
                    return url.one(eventID).one('rsvp');
                },
                guestList: function(eventID){
                    return url.one(eventID).one('rsvp');
                },
                comments: function(eventID){
                    return url.one(eventID).one('comments');
                },
                sendTestEmail: function(eventID){
                    return url.one(eventID).one('testemail');
                },
                guestView: function(transactionID){
                    return url.one(transactionID).one('guestview');
                }
            };

        }]);

});