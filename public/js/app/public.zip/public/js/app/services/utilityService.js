define([
        'angular'
    ],
    function (angular) {

        angular.module('Inwiter')

            .factory('UtilityService', ['Restangular', 'AuthService', '$rootScope', function (Restangular, Auth, $rootScope) {

                var videoTypes = /(\.|\/)(aepx|ale|avp|avs|bdm|bik|bin|bsf|camproj|cpi|dat|divx|dmsm|dream|dvdmedia|dvr-ms|dzm|dzp|edl|f4v|fbr|fcproject|hdmov|imovieproj|ism|ismv|m2p|m4v|mkv|mod|moi|mpeg|mts|mxf|ogv|otrkey|pds|prproj|psh|r3d|rcproject|3g2|3gp|asf|asx|avi|flv|x-flv|mov|mp4|mpg|wmv)$/i;
                var imageTypes = /(\.|\/)(jpeg|png|PNG|jpg|JPEG|JPG|bmp|BMP)$/i;
                var videoImageTypes = /(\.|\/)(jpeg|png|PNG|jpg|JPEG|JPG|bmp|BMP|aepx|ale|avp|avs|bdm|bik|bin|bsf|camproj|cpi|dat|divx|dmsm|dream|dvdmedia|dvr-ms|dzm|dzp|edl|f4v|fbr|fcproject|hdmov|imovieproj|ism|ismv|m2p|m4v|mkv|mod|moi|mpeg|mts|mxf|ogv|otrkey|pds|prproj|psh|r3d|rcproject|3g2|3gp|asf|asx|avi|flv|x-flv|mov|mp4|mpg|wmv)$/i;
                var maxVideoSize = 524300000000;
                var maxImageSize = 524300000000;

                var utilityService = {
                                        "isEmpty": function(value){
                                            console.log(value);
                                            value = value.replace(/^\s+/, '').replace(/\s+$/, '');
                                            if (value === '') {
                                                return false;
                                            } else {
                                                return true;
                                            }
                                        },
                                        /* ADDING NUM OF DAYS TO CURRENT DATE */
                                        "addDays": function (date, days){
                                            var days = days;
                                            var myDate = new Date(date);
                                            console.log("inpu => ", date, " output => ", myDate);
                                            var to = new Date(myDate.getTime() + days*24*60*60*1000);
                                            return to;
                                        },
                                        "validateEmail": function(email){
                                            var emailRegex = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
                                            if(emailRegex.test(email)){
                                                return true;
                                            }else{
                                                return false;
                                            }
                                        },
                                        "convertLocalToUTCDate": function(date){
                                            //CONVERTS LOACLDATE TO UTC DATE
                                            var dt = new Date(date);
                                            var newDt = dt.getFullYear()+'-'+(dt.getMonth()+1)+'-'+dt.getDate()+' '+dt.getHours()+':'+dt.getMinutes()+':'+dt.getSeconds();
                                            var utcDate = dt.getUTCFullYear()+' '+dt.getUTCMonth()+' '+dt.getUTCDate()+' '+dt.getUTCHours()+':'+dt.getUTCMinutes()+':'+dt.getUTCSeconds();
                                            console.log(utcDate);
                                            return utcDate;
                                        },
                                        "convertLocalToPHPDate": function(){
                                            var dt = new Date(date);
                                            var newDt = dt.getFullYear()+'-'+(dt.getMonth()+1)+'-'+dt.getDate()+' '+dt.getHours()+':'+dt.getMinutes()+':'+dt.getSeconds();
                                            return newDt;
                                        },
                                        "validateUTCDate": function(){
                                            return Restangular.service('utcdate', Restangular.one('user',Auth.currentUserId())).one();
                                        },
                                        "getDateDiff": function(date1, date2){
                                            //Get 1 day in milliseconds
                                            var one_day=1000*60*60*24;

                                            // Convert both dates to milliseconds
                                            var date1_ms = date1.getTime();
                                            var date2_ms = date2.getTime();

                                            // Calculate the difference in milliseconds
                                            var difference_ms = date2_ms - date1_ms;

                                            // Convert back to days and return
                                            return Math.round(difference_ms/one_day);
                                        },
                                        "timeAMPMTO24": function(time1){
                                            var time = new Date(time1);
                                            console.log("time = "+time);
                                            time = time.toString();
                                            var hrs = Number(time.match(/^(\d+)/)[1]);
                                            var mnts = Number(time.match(/:(\d+)/)[1]);
                                            var format = time.match(/\s(.*)$/)[1];
                                            if (format == "PM" && hrs < 12) hrs = hrs + 12;
                                            if (format == "AM" && hrs == 12) hrs = hrs - 12;
                                            var hours = hrs.toString();
                                            var minutes = mnts.toString();
                                            if (hrs < 10) hours = "0" + hours;
                                            if (mnts < 10) minutes = "0" + minutes;
                                            var convertedTime = hours+":"+minutes;
                                            return convertedTime;
                                        },
                                        "time24TOAMPM": function(timestamp){
                                            var dt = new Date(timestamp);
                                            var hrs = dt.getHours();
                                            var hrs1 = hrs;
                                            var min = 'AM';
                                            if(hrs >= 12){
                                                min = 'PM';
                                                hrs1 = hrs1-12;
                                            }

                                            if( hrs === 0 || hrs1 === 0){
                                                hrs1 = 12;
                                            }
                                            var time = hrs1+':'+dt.getMinutes()+" "+min;
                                            return time;
                                        },
                                        "timeAMPM": function(time){ //format should be 17:30:00
                                            var tm1 = time.split(":");
                                            var hrs = tm1[0];
                                            var hrs1 = hrs;
                                            var min = 'AM';
                                            if(hrs >= 12){
                                                min = 'PM';
                                                hrs1 = hrs1-12;
                                            }

                                            if( hrs === 0 || hrs1 === 0){
                                                hrs1 = 12;
                                            }
                                            var time = hrs1+':'+tm1[1]+" "+min;
                                            return time;
                                        },
                                        "fullTime24": function(date){
                                            var dt = new Date(date);
                                            return dt.getHours()+":"+dt.getMinutes()+":"+dt.getSeconds();
                                        },
                                        "fullDate": function(date){
                                            var dt = new Date(date);
                                            return dt.getFullYear()+"-"+(dt.getMonth()+1)+"-"+dt.getDate();
                                        },
                                        "fullMonth": function(month){
                                            var monthsAry = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
                                            month = parseInt(month);
                                            if(month == 1){
                                                return monthsAry[0];
                                            }
                                            if(month == 2){
                                                return monthsAry[1];
                                            }
                                            if(month == 3){
                                                return monthsAry[2];
                                            }
                                            if(month == 4){
                                                return monthsAry[3];
                                            }
                                            if(month == 5){
                                                return monthsAry[4];
                                            }
                                            if(month == 6){
                                                return monthsAry[5];
                                            }
                                            if(month == 7){
                                                return monthsAry[6];
                                            }
                                            if(month == 8){
                                                return monthsAry[7];
                                            }
                                            if(month == 9){
                                                return monthsAry[8];
                                            }
                                            if(month == 10){
                                                return monthsAry[9];
                                            }
                                            if(month == 11){
                                                return monthsAry[10];
                                            }
                                            if(month == 12){
                                                return monthsAry[11];
                                            }

                                        },
                                        "getTimeZoneOffSet": function(){
                                            var dt = new Date(); //Wed Jul 09 2014 11:07:00 GMT+0530 (IST)
                                            dt = dt.toString();
                                            console.log(dt);
                                            var a = dt.split("GMT");
                                            var b = a[1].split(" ");
                                            var c = b[0].substring(0, 3);
                                            var d = b[0].substring(3, 7);
                                            var e = c+':'+d;
                                            console.log(e);
                                            return e;
                                        },
                                        "getBrowser": function(){
                                            var ua= navigator.userAgent, tem,
                                                M= ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];
                                            if(/trident/i.test(M[1])){
                                                tem=  /\brv[ :]+(\d+)/g.exec(ua) || [];
                                                return 'IE '+(tem[1] || '');
                                            }
                                            if(M[1]=== 'Chrome'){
                                                tem= ua.match(/\bOPR\/(\d+)/)
                                                if(tem!= null) return 'Opera '+tem[1];
                                            }
                                            M= M[2]? [M[1], M[2]]: [navigator.appName, navigator.appVersion, '-?'];
                                            if((tem= ua.match(/version\/(\d+)/i))!= null) M.splice(1, 1, tem[1]);
                                            return M.join(' ');
                                        },
                                        "getDeviceType": function(){
                                            return navigator.platform;
                                        },
                                        "getOSType": function(){

                                        },
                                        "objectToRequestData" : function(item){
                                            var form_data = '';

                                            for ( var key in item ) {
                                                form_data = form_data+key+'='+item[key]+'&';
                                            }
                                            console.log(form_data);
                                            return form_data.slice(0, -1);
                                        },
                                        "isObjectEmpty" : function (obj) {
                                            for (var i in obj) if (obj.hasOwnProperty(i)) return false;
                                            return true;
                                        },
                                        "validateVideo" : function(files){
                                            var videoSize = maxVideoSize; //524300000000;
                                            var data = {'files': [files]};
                                            var lnt = data.files.length;
                                            console.log(lnt);
                                            console.log(data);
                                            var returnvl = {
                                                                val : false,
                                                                error : 'format'
                                                           };
                                            for ( var i = 0; i < lnt; i++) {
                                                var type1 = data.files[i].name;
                                                var type2 = type1.split(".");
                                                var type = '.' + type2[type2.length - 1];
                                                console.log(type);
                                                var size = data.files[i].size;
                                                if (size <= videoSize) {
                                                    if (videoTypes.test(type)) {
                                                        returnvl.val = true;
                                                    } else {
                                                        i = lnt;
                                                        returnvl.val = false;
                                                    }
                                                } else {
                                                    returnvl.val = false;
                                                    returnvl.error = 'size';
                                                }
                                            }
                                            console.log(returnvl);
                                            return returnvl;
                                        },
                                        "validateImage" : function(files){
                                            var imageSize = maxImageSize;
                                            var data = {'files': [files]};
                                            var lnt = data.files.length;
                                            console.log(lnt);
                                            console.log(data);
                                            var returnvl = {
                                                                val : false,
                                                                error : 'format'
                                                           };
                                            for ( var i = 0; i < lnt; i++) {
                                                var type1 = data.files[i].name;
                                                var type2 = type1.split(".");
                                                var type = '.' + type2[type2.length - 1];
                                                console.log(type);
                                                var size = data.files[i].size;
                                                if (size <= imageSize) {
                                                    if (imageTypes.test(type)) {
                                                        returnvl.val = true;
                                                    } else {
                                                        i = lnt;
                                                        returnvl.val = false;
                                                    }
                                                } else {
                                                    returnvl.val = false;
                                                    returnvl.error = 'size';
                                                }
                                            }
                                            console.log(returnvl);
                                            return returnvl;
                                        },
                                        "validateVideosImages" : function(files){
                                            var videoSize = maxVideoSize;
                                            var data = {'files': [files]};
                                            var lnt = data.files.length;
                                            console.log(lnt);
                                            console.log(data);
                                            var returnvl = {
                                                                val : false,
                                                                error : 'format'
                                                           };
                                            for ( var i = 0; i < lnt; i++) {
                                                var type1 = data.files[i].name;
                                                var type2 = type1.split(".");
                                                var type = '.' + type2[type2.length - 1];
                                                console.log(type);
                                                var size = data.files[i].size;
                                                if (size <= videoSize) {
                                                    if (videoImageTypes.test(type)) {
                                                        returnvl.val = true;
                                                    } else {
                                                        i = lnt;
                                                        returnvl.val = false;
                                                    }
                                                } else {
                                                    returnvl.val = false;
                                                    returnvl.error = 'size';
                                                }
                                            }
                                            console.log(returnvl);
                                            return returnvl;
                                        },
                                        checkObjectKey: function (obj, key, defaultValue, value){
                                            if(value == undefined){
                                                value = obj[key];
                                            }
                                            return obj.hasOwnProperty(key) ? value : defaultValue;
                                        },
                                        getQueryStringData: function(name){
                                            name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
                                            var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
                                                results = regex.exec(location.search);
                                            return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
                                        },
                                        getDefaultTimeZone: function(offSet){
                                            var timeZone = '';
                                            switch (offSet){
                                                case '-12:00':
                                                            timeZone =  "-12:00_International Date Line West";
                                                            break;
                                                case '-11:00':
                                                            timeZone =  "-11:00_Coordinated Universal Time-11";
                                                            break;
                                                case '-10:00':
                                                            timeZone =  "-10:00_Hawaii";
                                                            break;
                                                case '-9:00':
                                                            timeZone =  "-09:00_Alaska";
                                                            break;
                                                case '-8:00':
                                                    timeZone =  "-08:00_Pacific Time [US & Canada]";
                                                    break;
                                                case '-7:00':
                                                    timeZone =  "-07:00_Mountain Time [US & Canada]";
                                                    break;
                                                case '-6:00':
                                                    timeZone =  "-06:00_Central Time [US & Canada]";
                                                    break;
                                                case '-5:00':
                                                    timeZone =  "-05:00_Eastern Time [US & Canada]";
                                                    break;
                                                case '-4:30':
                                                    timeZone =  "-04:30_Caracas";
                                                    break;
                                                case '-4:00':
                                                    timeZone =  "-04:00_Atlantic Time [Canada]";
                                                    break;
                                                case '-3:30':
                                                    timeZone =  "-03:30_Newfoundland";
                                                    break;
                                                case '-3:00':
                                                    timeZone =  "-03:00_Buenos Aires";
                                                    break;
                                                case '-2:00':
                                                    timeZone =  "-02:00_Mid-Atlantic";
                                                    break;
                                                case '-1:00':
                                                    timeZone =  "-01:00_Azores";
                                                    break;
                                                case '00:00':
                                                    timeZone =  "00:00_Dublin, Edinburgh, Lisbon, London";
                                                    break;
                                                case '+01:00':
                                                    timeZone =  "+01:00_Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna";
                                                    break;
                                                case '+02:00':
                                                    timeZone =  "+02:00_Cairo";
                                                    break;
                                                case '+03:00':
                                                    timeZone =  "+03:00_Kuwait, Riyadh";
                                                    break;
                                                case '+04:00':
                                                    timeZone =  "+04:00_Abu Dhabi, Muscat";
                                                    break;
                                                case '+04:30':
                                                    timeZone =  "+04:30_Kabul";
                                                    break;
                                                case '+05:00':
                                                    timeZone =  "+05:00_Islamabad, Karachi";
                                                    break;
                                                case '+05:30':
                                                    timeZone =  "+05:30_Chennai, Kolkata, Mumbai, New Delhi";
                                                    break;
                                                case '+05:45':
                                                    timeZone =  "+05:45_Kathmandu";
                                                    break;
                                                case '+06:00':
                                                    timeZone =  "+06:00_Dhaka";
                                                    break;
                                                case '+06:30':
                                                    timeZone =  "+06:30_Yangon [Rangoon]";
                                                    break;
                                                case '+07:00':
                                                    timeZone =  "+07:00_Bangkok, Hanoi, Jakarta";
                                                    break;
                                                case '+08:00':
                                                    timeZone =  "+08:00_Beijing, Chongqing, Hong Kong, Urumqi";
                                                    break;
                                                case '+09:00':
                                                    timeZone =  "+09:00_Osaka, Sapporo, Tokyo";
                                                    break;
                                                case '+09:30':
                                                    timeZone =  "+09:30_Adelaide";
                                                    break;
                                                case '+10:00':
                                                    timeZone =  "+10:00_Canberra, Melbourne, Sydney";
                                                    break;
                                                case '+11:00':
                                                    timeZone =  "+11:00_Solomon Is., New Caledonia";
                                                    break;
                                                case '+12:00':
                                                    timeZone =  "+12:00_Coordinated Universal Time+12";
                                                    break;

                                                default:
                                                    timeZone =  "-05:00_Eastern Time [US & Canada]";
                                                    break;
                                            }
                                            return timeZone;
                                        }


            };
                return utilityService;

            }]);

    });

