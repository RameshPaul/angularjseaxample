define([
    'angular'
],
function (angular) {

    angular.module('Inwiter')

        .factory('EventService', ['Restangular', 'AuthService', function (Restangular, Auth) {

            return Restangular.service('events', Restangular.one('user', Auth.currentUserId())).one();

        }]);

});