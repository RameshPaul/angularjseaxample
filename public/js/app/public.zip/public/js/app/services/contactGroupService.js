define([
        'angular'
    ],
    function (angular) {

        angular.module('Inwiter')

            .factory('ContactGroupService', ['Restangular', 'AuthService', function (Restangular, Auth) {

                return Restangular.service('groups', Restangular.one('user', Auth.currentUserId())).one();

            }]);

    });