define(['angular'], function(angular){
    var contactsModel = angular.module("Inwiter");

    contactsModel.factory("ContactsJSONModel", ['UtilityService', function(Utility){
        var contactsProvider;
        var groupObj = {groupName: "", groupID:"", keyDate:""};
        var contactsAry = [];
        var finalContactsObj = {userContact: {}, userGroups: []};
        var contactsObj = {firstName:"", lastName:"", email:"", gender:"", contactID:""};

        function checkObjectKey(obj, key, defaultValue){
            return obj.hasOwnProperty(key) ? obj[key] : defaultValue;
        }

            contactsProvider = {
                                    "createGroup": function(groupName){
                                        var obj = angular.copy(groupObj);
                                            obj.groupName = groupName;
                                        var data = {'userGroup': encodeURIComponent(JSON.stringify(obj))};
                                        return Utility.objectToRequestData(data);
                                    },
                                    "updateGroup": function(){

                                    },
                                    "deleteGroup": function(){

                                    },
                                    "addContactsToGroup": function(groupData, contacts){
                                        var cncts = angular.copy(contactsAry);
                                        for(var i=0; i<contacts.length; i++) {
                                            var cobj = angular.copy(contactsObj);
                                            cobj.email = contacts[i].email;
                                            cobj.firstName = checkObjectKey(contacts[i], 'firstName', '');
                                            cobj.lastName = checkObjectKey(contacts[i], 'lastName', '');
                                            cobj.contactID = checkObjectKey(contacts[i], 'contactID', '');
                                            cobj.gender = checkObjectKey(contacts[i], 'gender', '');

                                            var gobj = angular.copy(groupObj);
                                            gobj.groupName = checkObjectKey(groupData, 'groupName', '');
                                            gobj.groupID = groupData.groupID;
                                            gobj.keyDate = checkObjectKey(contacts[i], 'keyDate', '');

                                            var cnt = angular.copy(finalContactsObj);
                                            cnt.userContact = cobj;
                                            cnt.userGroups.push(gobj);
                                            cncts.push(cnt);
                                        }
                                        var data = {'userContacts': encodeURIComponent(JSON.stringify(cncts))};
                                        return Utility.objectToRequestData(data);
                                    }
                               };
        return contactsProvider;
    }]);
});