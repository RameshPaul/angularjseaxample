define([
    'angular'
],

function (angular) {
    'use strict';

    var inwiterApp =  angular.module('Inwiter', [
                                    'oc.lazyLoad',
                                    'ui.router',
                                    'restangular',
                                    'LocalStorage',
                                    //'routeResolverServices',
                                    'Inwiter.Header',
                                    'ui.bootstrap',
                                    'Inwiter.Dashboard',
                                    'Inwiter.CreateEvent',
                                    'Inwiter.EventsLibrary',
                                    'Inwiter.GuestModule',
                                    'Inwiter.Contacts'
                                ]);



    /**
     * Inspecting HTTP service to log errors
     * this interceptor uses the application logging service to
     * log server-side any errors from $http requests
     */
    inwiterApp.config(['$httpProvider', '$ocLazyLoadProvider', function($httpProvider, $ocLazyLoadProvider) {
        $httpProvider.responseInterceptors.push([
            '$rootScope', '$q', '$injector','$location','appLogService',
            function($rootScope, $q, $injector, $location, appLogService){
                return function(promise){
                    return promise.then(function(response){
                        // http on success
                        return response;
                    }, function (response) {
                        // http on failure
                        // in this example im just looking for 500, in production
                        // you'd obviously need to be more discerning
                        if(response.status === null || response.status === 500) {
                            var error = {
                                method: response.config.method,
                                url: response.config.url,
                                message: response.data,
                                status: response.status
                            };
                            appLogService.error(JSON.stringify(error));
                        }
                        return $q.reject(response);
                    });
                };
            }
        ]);

        /** Lazy load config **/
        $ocLazyLoadProvider.config({
            loadedModules: ['Inwiter'],
            asyncLoader: require
        });

    }]);



    console.log("in app.js file");

    /**
     * APP CONSTANTS
     * external ajax request
     * social network credentials
     *
     */
    inwiterApp.value('ajaxURL',{"errorLoggingURL":"/jserrorlog", "userDetails":"/user/getuserdata/", "userID":"/user/getuserid/"});
    inwiterApp.value('base_url','http://inwiter.com/');
    inwiterApp.value("SocialShareAPIKeys",{
                                            "fb": {
                                                    "appId": _socialAPIKeys.facebook.appID,//"177448212466459",
                                                    "appSecret": _socialAPIKeys.facebook.appSecret,//"b043415308c91962037fa527f82b3353",
                                                    "permissions": _socialAPIKeys.facebook.permissions
                                                  },
                                            "twitter": {
                                                        "appId":"",
                                                        "appSecret":""
                                                       },
                                            "googlePlus": {
                                                            "appId":"",
                                                            "appSecret":""
                                                          },
                                            "google": {
                                                        "login": {
                                                            "appID": '',
                                                            "appSecret": ''
                                                        },
                                                        "captcha": {
                                                            "appID": '',
                                                            "appSecret": ''
                                                        }
                                                      }
                                          }
    );
});