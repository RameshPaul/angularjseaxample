define([
    'angular'
],
function (angular) {
    var eventDetails = angular.module('Inwiter.CreateEvent.EventDetails');

    eventDetails.directive("eventDateTime",['UtilityService',function(Utility){
        return{
            restrict: 'A',
            link: function(scope, element, attrs){
                    console.log(element);
                    console.log(attrs);
                console.log(element.val());
                var elmId = attrs.id;
                var numDays = scope.maxDays;

                jQuery("#"+elmId).datetimepicker({
                    format: "MM dd yyyy - HH:ii P",
                    showMeridian: true,
                    autoclose: true,
                    todayBtn: true
                });

                var elmValue = element.val();

                var nwdt = new Date();
                var monthNames = [ "January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December" ];
                var hours = nwdt.getHours();
                //var hours = (hours+24-2)%24;
                var mid='AM';
                if(hours==0){ //At 00 hours we need to show 12 am
                    hours=12;
                }else if(hours>12){
                    hours=hours%12;
                    mid='PM';
                }
                var origStDtVl = elmValue;
                var origStDt = elmValue.split(" ");
                var orig_new_dt = monthNames[nwdt.getMonth()]+' '+nwdt.getDate()+' '+nwdt.getFullYear()+' - '+hours+':'+nwdt.getMinutes()+' '+mid;
                var orig_dt = monthNames[nwdt.getMonth()]+' '+nwdt.getDate()+' '+nwdt.getFullYear();

                if(origStDt[2] == '-1'){
                    element.val(orig_new_dt);
                }else if(!Utility.isEmpty(origStDtVl)){
                    element.val(orig_new_dt);
                }

                jQuery('#'+elmId).click(function(e){
                    console.log("at start date click");
                    console.log(e.target.id);
                    if(e.target.id == elmId){
                        jQuery('#'+elmId).datetimepicker('show');
                    }
                });

                jQuery('#'+elmId).datetimepicker('setStartDate', orig_new_dt);
                jQuery('#'+elmId).datetimepicker('setEndDate', Utility.addDays(orig_dt,numDays));

                //Update SCOPE
                scope.eventDetails.eventStartDateTime = orig_new_dt;
                //scope.$apply();
                //$('#ORIG_END_DT').datetimepicker('setStartDate', orig_new_dt);
                //$('#ORIG_END_DT').datetimepicker('setEndDate', addDays(orig_dt,numDays));

            }
        }
    }]);

    eventDetails.directive("eventDate",['UtilityService',function(Utility){
        return{
            restrict: 'A',
            link: function(scope, element, attrs){
                console.log(element);
                console.log(attrs);
                console.log(element.val());
                var elmId = attrs.id;
                var numDays = scope.maxDays;

                jQuery("#"+elmId).datetimepicker({
                    format: "MM dd yyyy",
                    showMeridian: true,
                    autoclose: true,
                    todayBtn: true
                });

                var elmValue = element.val();

                var nwdt = new Date();
                var monthNames = [ "January", "February", "March", "April", "May", "June","July", "August", "September", "October", "November", "December" ];
                var hours = nwdt.getHours();
                //var hours = (hours+24-2)%24;
                var mid='AM';
                if(hours==0){ //At 00 hours we need to show 12 am
                    hours=12;
                }else if(hours>12){
                    hours=hours%12;
                    mid='PM';
                }
                var origStDtVl = elmValue;
                var origStDt = elmValue.split(" ");
                var orig_new_dt = monthNames[nwdt.getMonth()]+' '+nwdt.getDate()+' '+nwdt.getFullYear();
                var orig_dt = monthNames[nwdt.getMonth()]+' '+nwdt.getDate()+' '+nwdt.getFullYear();

                if(origStDt[2] == '-1'){
                    element.val(orig_new_dt);
                }else if(!Utility.isEmpty(origStDtVl)){
                    element.val(orig_new_dt);
                }

                jQuery('#'+elmId).click(function(e){
                    console.log("at start date click");
                    console.log(e.target.id);
                    if(e.target.id == elmId){
                        jQuery('#'+elmId).datetimepicker('show');
                    }
                });

                jQuery('#'+elmId).datetimepicker('setStartDate', orig_new_dt);
                jQuery('#'+elmId).datetimepicker('setEndDate', Utility.addDays(orig_dt,numDays));

                //Update SCOPE
                scope.eventDetails.eventStartDateTime = orig_new_dt;
                //scope.$apply();
                //$('#ORIG_END_DT').datetimepicker('setStartDate', orig_new_dt);
                //$('#ORIG_END_DT').datetimepicker('setEndDate', addDays(orig_dt,numDays));

            }
        }
    }]);




});