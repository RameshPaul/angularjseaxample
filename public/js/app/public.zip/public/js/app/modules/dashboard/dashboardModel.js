define([
    'angular'
],function(angualr){
    var dashboard = angular.module("Inwiter.Dashboard");
    if(dashboard.register != undefined){
        dashboard = dashboard.register;
    }
    dashboard.factory("DashboardModel", [function(){
        console.log("dashboard model loaded");
    }]);
});