define([
    'angular'
],
function(angular){
    var eventVideo  = angular.module("Inwiter.CreateEvent.EventVideo");
    eventVideo.factory("EventVideoService",[function(){

    }]);

    eventVideo.factory("EncodingService",[function(){
        var encodingQueue = [];
        var encoder = {
            addItem: function(item){
                var pos = encodingQueue.push(item);
                return pos;
            },
            removeItem: function(index){
                var pos = encodingQueue.splice(index, 1);
                return pos;
            },
            getStatus: function(index){
                return encodingQueue[index].status;
            },
            startEncoding: function(index){

            },
            stopEncoding: function(index){

            }
        };
        return encoder;
    }]);
});
