define([
    'angular'
], function(angular){
    var guest = angular.module("Inwiter.GuestModule");
    if(guest.register != undefined){
        guest = guest.register;
    }

    guest.controller("GuestCtrl",['$scope', '$rootScope', '$location', '$stateParams', 'GuestService', 'UtilityService', 'appLogService', 'AuthService', '$sce', function($scope, $rootScope, $location, $stateParams, GuestService, Utility, appLogService, Auth, $sce){

        //Route to this page if it is active
        $scope.isActive = function(route) {
            return route === $location.path();
        };

        //SET DEFAULT HEADERS FOR EVERY REQUEST
        Auth.setAuthDefaults();

        console.log("in guest controller");
        //CONSTANTS
        var CONSTANTS = {};
            CONSTANTS.DRAFT_FLAG = 'DR';
            CONSTANTS.RSVP = {};
            CONSTANTS.RSVP.YES = '1';
            CONSTANTS.RSVP.NO = '2';
            CONSTANTS.RSVP.MAYBE = '3';
            CONSTANTS.RSVP.NOREPLY = '0';
            CONSTANTS.DUMMY_USER_PIC = '/public/images/user-dummy.jpg';

        //GLobal variables
        var eventType = '';
        //var isHost = false;
        //var isGuest = false;
        //var isPublic = false;
        //var isSessionExists = false;
        //var enablePreviewMode = false;
        var guestDetails = {};
            guestDetails.email = '';
            guestDetails.name = '';
            guestDetails.comment = '';
        var userID = 0;
        var sessionUserID = 0;
        var origEventID = 0;
        var origTransactionID = 0;
        var eventStatus = '';
        var eventSettings = {};
            eventSettings.isGuestListHidden = false;
            eventSettings.totalGuestsLimit = '';
            eventSettings.totalKidsLimit = '';
            eventSettings.totalGuestsAttending = '';
            eventSettings.allowKinds = false;
            eventSettings.notifyOnComment = false;
            eventSettings.notifyOnRSVP = false;
            eventSettings.notifyOnGuestView = false;


        $scope.isHost = false;
        $scope.isGuest = false;
        $scope.isPublic = false;
        $scope.isSessionExists = false;
        $scope.enablePreviewMode = false;
        $scope.enableLoadMoreGuestsBtn = true;
        $scope.rsvpCompleted = false;
        $scope.enableEndDate = true;
        $scope.enableEndTime = true;
        $scope.showRSVPPrompt = false;
        $scope.selectedGuestListTab = '1';

        $scope.guestListLimit = {};
        $scope.guestListLimit.start = 0;
        $scope.guestListLimit.end = 10000;
        $scope.guestListLimit.default = 20;
        $scope.guestListLimit.fetchedCount = 0;

        $scope.eventSettings = {};
        $scope.eventSettings.isGuestListHidden = false;
        $scope.eventSettings.totalGuestsLimit = '';
        $scope.eventSettings.totalKidsLimit = '';
        $scope.eventSettings.totalGuestsAttending = '';
        $scope.eventSettings.allowKinds = false;
        $scope.eventSettings.notifyOnComment = false;
        $scope.eventSettings.notifyOnRSVP = false;
        $scope.eventSettings.notifyOnGuestView = false;

        $scope.eventDates = {};
        $scope.eventDates.startDate = {};
        $scope.eventDates.startDate.date = '';
        $scope.eventDates.startDate.month = '';
        $scope.eventDates.startDate.year = '';
        $scope.eventDates.startDate.time = '';

        $scope.eventDates.endDate = {};
        $scope.eventDates.endDate.date = '';
        $scope.eventDates.endDate.month = '';
        $scope.eventDates.endDate.year = '';
        $scope.eventDates.endDate.time = '';

        $scope.eventVideo = {};
        $scope.eventVideo.videoURL = '';
        $scope.eventVideo.thumbURL = '';

        $scope.backgroundTheme = '';

        $scope.serverResponse = '';
        $scope.errorMessage = '';


        //RSVP Model
        $scope.rsvpModel = {guestNumber:'', kidsNumber: ''};
        $scope.rsvpComplete = {hostName: '', rsvpOption: ''};

        //Comment Model
        $scope.commentModel = {};


        /** Get paramaters from URL **/
        var parameters = $stateParams;
        var transactionID = parameters.transactionID;
        var eventID = parameters.eventID;
        console.log("state params", $stateParams);

        (function(){
            Auth.isUserAlive().then(function(res){
                var response = res.data;
                console.log(response);
                console.log(response.data);
                if(response.status.toUpperCase() == 'SUCCESS'){
                    sessionUserID = response.data.userID;
                    userID = response.data.userID;
                    init();
                }else{
                    appLogService.debug("user has no session");
                    init();
                }
            }, function(response){
                appLogService.error("got error at getting userid from server session");
            });
        })();

        function init(){
            if(transactionID == undefined){
                //User is either HOST or public user
                //transactionID = eventID;
                getEventdetails(eventID);
            }
            else
            {
                getEventID(transactionID);
            }
            console.log(transactionID, eventID);

        }


        /**
         * Guest page model
         */
        $scope.guestModel = {
            event: {},
            settings: {},
            rsvpDetails: {},
            rsvpCounts: {},
            guestList: {
                yes: [],
                no: [],
                maybe: [],
                noreply: []
            },
            comments: []
        };

        /**
         * Page scuerity Model
         */
        $scope.secureModel = {
            allowRsvp: true,
            allowComment: true,
            showGuestList: true,
            showComments: true,
            showRsvp: true,
            showRsvpCounts: true,
            showEventDetails: true
        };

        //IF GUEST IS VIEWING GET EVENT ID

        function getEventID(transactionID){
            //if($scope.isGuest){
                GuestService.eventID(transactionID).get().then(function(response){
                    console.log(response);
                    if(response.status.toUpperCase() == 'SUCCESS'){
                        origEventID = response.data.eventID;
                        origTransactionID = response.data.transactionID;
                        getEventdetails(origEventID);
                    }else{
                        appLogService.error("cannot get event ID for transaction ID"+response.data.transactionID);
                        console.log("error eventid");
                    }
                }, errorHandler);
            //}else{
            //    origEventID = transactionID;
            //    getEventdetails(origEventID);
           // }
        }

        /**
         * Error handler function
         * @param error {{}}
         */
        function errorHandler(error){
            console.log(error);
            appLogService.debug("error occured ");
            appLogService.error(error);
            $scope.errorMessage = error.description;

            $rootScope.$emit("showInfoBar", error);
        }

        /**
         * Get event details functionality
         * @param eventID {number}
         */
        function getEventdetails(eventID){
            appLogService.debug("Guest page Requested for event details transid-"+eventID);
            var request = GuestService.details(eventID).get();
            request.then(eventDetailsResponse, errorHandler);
        }

        /** Get event details repsonse
         * @param response {{}}
         */
        function eventDetailsResponse(response){
            appLogService.debug("event details fetched");
            console.log(response);
            var status = response.status;
            if(status.toUpperCase() === 'SUCCESS'){
                $scope.guestModel.event = angular.copy(response.data.eventDetails);
                $scope.guestModel.settings = angular.copy(response.data.eventSettings);
                identifyUser();
            }else{
                errorHandler(response);
            }
        }

        function identifyUser(){
            var eventUserID = $scope.guestModel.event.userID;
            if(transactionID == undefined){
                //Check whether user is loggedIn or not
                if(sessionUserID == eventUserID){
                    //User is host
                    $scope.isHost = true;
                    $scope.isSessionExists = true;
                }else{
                    //user is public
                    $scope.isPublic = true;
                }
            }else{
                //user is Guest
                $scope.isGuest = true;
            }
            console.log("user is H-"+$scope.isHost+", G-"+$scope.isGuest+", P-"+$scope.isPublic);
            checkEventDetails();
        }

        /**
         * Check event details for loading remianing details
         */
        function checkEventDetails(){
            console.log($scope.guestModel);
            eventType = $scope.guestModel.event.eventType;

            userID = $scope.guestModel.event.userID;
            eventStatus = $scope.guestModel.event.eventStatus;

            //Convert dates
            var startDate1 = $scope.guestModel.event.eventStartDate;
            var startDate = startDate1.split("-");
            $scope.eventDates.startDate.date = startDate[2];
            $scope.eventDates.startDate.month = Utility.fullMonth(startDate[1]);
            $scope.eventDates.startDate.year = startDate[0];

            var startTime1 = $scope.guestModel.event.eventStartTime;
            console.log("start time", startTime1);
            var startTime2 = Utility.timeAMPM(startTime1);
            console.log("min start time", startTime2);
            var startTime = startTime2.split(" ");
            $scope.eventDates.startDate.time = startTime[0];
            $scope.eventDates.startDate.timeMin = startTime[1];

            var endDate1 = $scope.guestModel.event.eventEndDate;
            if(endDate1 == '0000-00-00'){
                $scope.enableEndDate = false;
            }else{
                $scope.enableEndDate = true;
                var endDate = endDate1.split("-");
                $scope.eventDates.endDate.date = endDate[2];
                $scope.eventDates.endDate.month = Utility.fullMonth(endDate[1]);
                $scope.eventDates.endDate.year = endDate[0];
            }

            var endTime1 = $scope.guestModel.event.eventEndTime;
            if(endTime1 == '00:00:00'){
                $scope.enableEndTime = false;
            }else{
                var endTime2 = Utility.timeAMPM(endTime1);
                var endTime = endTime2.split(" ");
                $scope.eventDates.endDate.time = endTime[0];
                $scope.eventDates.endDate.timeMin = endTime[1];
            }


            //Decode Event Description
            var desc = decodeURIComponent($scope.guestModel.event.eventDescription);
            $scope.guestModel.event.eventDescription = $sce.trustAsHtml(desc);

            //video URL append
            $scope.eventVideo.videoURL = '/'+$scope.guestModel.event.videoFileURL;
            $scope.eventVideo.thumbURL = '/'+$scope.guestModel.event.videoThumbURL;

            //Background url
            //TODO ADD '/' to background theme when moved to test
            $scope.backgroundTheme = $scope.guestModel.event.eventGuestThemeURL;

            if(eventStatus === CONSTANTS.DRAFT_FLAG){
                //EVENT IS IN DRAFT , enable preview model
                if($scope.isHost && $scope.isSessionExists){
                    $scope.enablePreviewMode = true;
                }
            }

            if($scope.isHost){
                $scope.secureModel.showRsvp = false;
                $scope.secureModel.allowComment = false;
                $scope.secureModel.allowRsvp = false;
            }

            //CHECK GUEST LIST IS HIDDEN
            var hideGuestList = $scope.guestModel.settings.guestListHidden;
            if(hideGuestList == '1'){
                $scope.eventSettings.isGuestListHidden = true;
                $scope.secureModel.showGuestList = false;
                $scope.secureModel.showRsvpCounts = false;
            }

            //CHECK COMMENTS IS HIDDEN
            var hideComments = $scope.guestModel.settings.commentsHidden;
            if(hideComments == '1'){
                $scope.secureModel.showComments = false;
            }

            //CHECK GUEST LIMIT
            $scope.eventSettings.totalGuestsLimit = $scope.guestModel.settings.totalGuests;

            //CHECK KIDS ALLOWED
            var kidsAllowed = $scope.guestModel.settings.kidsAllowed;
            if(kidsAllowed == '1'){
                $scope.eventSettings.allowKinds = true;
            }

            //CHECK NOTIFY ON COMMENT
            var notifyComment = $scope.guestModel.settings.notifyOnComment;
            if(notifyComment == '1'){
                $scope.eventSettings.notifyOnComment = true;
            }

            //CHECK NOTIFY ON RSVP
            var notifyRSVP = $scope.guestModel.settings.notifyOnRSVP;
            if(notifyRSVP == '1'){
                $scope.eventSettings.notifyOnRSVP = true;
            }

            //CHECK NOTIFY ON VIEW
            var notifyView = $scope.guestModel.settings.notifyOnGuestView;
            if(notifyView == '1'){
                $scope.eventSettings.notifyOnGuestView = true;
            }

            //TODO WHEN MOVED TO TEST, PRD
            //video details mock
            //var data = {videoURL: '/usermedia/iPhoneSample.mp4',videoThumbURL: '/usermedia/iphone-thumb.jpg'};
            //$scope.eventVideo.videoURL = data.videoURL;
            //$scope.eventVideo.videoThumbURL = data.videoThumbURL;

            //TODO WHEN MOVED TO TEST, PRD
            //Background image mock
            //$scope.backgroundTheme = '/usermedia/iphone-thumb.jpg';
            setVideoOptions($scope.eventVideo);
            loadRemainingModules(origEventID);
            updateGuestView(origTransactionID);
        }

        /**
         * Loading remaining modules data
         */
        function loadRemainingModules(eventID){
            var startLimit = $scope.guestListLimit.start;
            var endLimit = parseInt(startLimit+$scope.guestListLimit.default);
            //Guest list is hidden
            if($scope.eventSettings.isGuestListHidden){
                if($scope.isHost){ //host is in the page
                    loadRsvpCounts(eventID);
                    loadGuestList('1', startLimit, endLimit, eventID);
                    loadComments('all', eventID);
                }else{ //guest is the page
                    loadRsvpDetails(origTransactionID);
                    loadComments('currentGuest', eventID);
                }
            }else{ //Guest list is not hidden
                if($scope.isHost){ //host is in the page
                    loadRsvpCounts(eventID);
                    loadGuestList('1', startLimit, endLimit, eventID);
                    loadComments('all', eventID);
                }else{ //guest is the page
                    loadRsvpCounts(eventID);
                    loadRsvpDetails(origTransactionID);
                    loadGuestList('1', startLimit, endLimit, eventID);
                    loadComments('all', eventID);
                }
            }
        }


        /**
         * Load RSVP counts functionlaity
         */
        function loadRsvpCounts(eventID){
            var filter = {"RSVPRequestType":'counts'};
            var request = GuestService.rsvp(eventID).get(filter);
            request.then(function(response){
                if(response.status.toUpperCase() == 'SUCCESS') {
                    $scope.guestModel.rsvpCounts = response.data.guestRSVPCounts;
                }else{
                    errorHandler(response);
                }
            }, errorHandler);
        }

        /**
         * Load RSVP details functionality
         */
        function loadRsvpDetails(transID){
            var filter = {"RSVPRequestType":'guestRSVPStatus'};
            console.log(filter, transID);
            var request = GuestService.rsvp(transID).get(filter);
            request.then(function(response){
                console.log(response);
                if(response.status.toUpperCase() == 'SUCCESS'){
                    $scope.guestModel.rsvpDetails = response.data.guestRSVP;
                }else{
                    errorHandler(response);
                }
            }, errorHandler);
        }

        /**
         * Load Guest list
         * @param rsvpType {string}
         * @param startLimit {number}
         * @param endLimit {number}
         */
        function loadGuestList(rsvpType, startLimit, endLimit, eventID){
            var filter = {RSVPRequestType:'list', RSVPType: rsvpType, intStartLimit: startLimit, intEndLimit: endLimit};
            var request = GuestService.guestList(eventID).get(filter);
            request.then(function(response){
                console.log("guest list received", response.data);
                if(response.status.toUpperCase() == 'SUCCESS') {
                    var data = response.data.guestRSVPList;
                    loadGuestListSuccess(response, rsvpType, endLimit);
                }
            }, errorHandler);
        }

        function loadGuestListSuccess(response, rsvpType, endLimit){
            console.log("Guest list type ", rsvpType, response);
            for(var i=0; i<response.data.guestRSVPList.length; i++){
                if(rsvpType == '1'){
                    $scope.guestModel.guestList.yes.push(response.data.guestRSVPList[i]);
                }
                if(rsvpType == '2'){
                    $scope.guestModel.guestList.no.push(response.data.guestRSVPList[i]);
                }
                if(rsvpType == '3'){
                    $scope.guestModel.guestList.maybe.push(response.data.guestRSVPList[i]);
                }
                if(rsvpType == '0'){
                    $scope.guestModel.guestList.noreply.push(response.data.guestRSVPList[i]);
                }
            }
            $scope.guestListLimit.start = endLimit;
            console.log(endLimit+"received length "+response.data.guestRSVPList.length+" limit length"+$scope.guestListLimit.default);
            console.log($scope.guestModel);
            if(response.data.guestRSVPList.length < $scope.guestListLimit.default){
                $scope.enableLoadMoreGuestsBtn = false;
            }else{
                $scope.enableLoadMoreGuestsBtn = true;
            }

            //ADD DUMMY DATA
            var dummyData = {
                                RSVPType: "0",
                                email: "ramesh.inwiter@gmail.com",
                                guestNumber: "5", guestView: "8",
                                image: "http://localhost/public/images/user-dummy.jpg",
                                kidsNumber: "0",
                                name: "Ramesh Babu CH"
                            };
            //$scope.guestModel.guestList.noreply.push(dummyData);
        }

        $scope.receiveGuestList = function(rsvpType){
            $scope.selectedGuestListTab = rsvpType;
            var startLimit, endLimit;
            console.log("receive guest list", rsvpType, startLimit, endLimit);
            resetGuestList(rsvpType);
            if(rsvpType == '1'){
                startLimit = $scope.guestListLimit.start;
                endLimit = parseInt(startLimit+$scope.guestListLimit.default);
                loadGuestList(rsvpType, startLimit, endLimit, origEventID);
            }

            if(rsvpType == '2'){
                startLimit = $scope.guestListLimit.start;
                endLimit = parseInt(startLimit+$scope.guestListLimit.default);
                loadGuestList(rsvpType, startLimit, endLimit, origEventID);
            }

            if(rsvpType == '3'){
                startLimit = $scope.guestListLimit.start;
                endLimit = parseInt(startLimit+$scope.guestListLimit.default);
                loadGuestList(rsvpType, startLimit, endLimit, origEventID);
            }

            if(rsvpType == '0'){
                startLimit = $scope.guestListLimit.start;
                endLimit = parseInt(startLimit+$scope.guestListLimit.default);
                loadGuestList(rsvpType, startLimit, endLimit, origEventID);
            }
            console.log("limits", startLimit, endLimit);
        };

        function resetGuestList(rsvpType){
            $scope.guestListLimit.start =0;
            if(rsvpType == '1'){
                $scope.guestModel.guestList.yes = [];
            }
            if(rsvpType == '2'){
                $scope.guestModel.guestList.no = [];
            }
            if(rsvpType == '3'){
                $scope.guestModel.guestList.maybe = [];
            }
            if(rsvpType == '0'){
                $scope.guestModel.guestList.noreply = [];
            }
        }

        $scope.loadMoreGuests = function(){
          var rsvpType = $scope.selectedGuestListTab;
          console.log("selected tab");
          var startLimit = $scope.guestListLimit.start;
          var endLimit = parseInt(startLimit+$scope.guestListLimit.default);
          loadGuestList(rsvpType, startLimit, endLimit, origEventID);
        };
        /**
         * Load Comments
         * @param type {string}
         */
        function loadComments(type){
            var filter = {"target":type};
            var request = GuestService.comments(origEventID).get();
            request.then(function(response){
                if(response.status.toUpperCase() == 'SUCCESS'){
                    $scope.guestModel.comments = response.data.guestCommentList;
                    console.log("comments set successfully", $scope.guestModel);
                }
            }, errorHandler);
        }

        $scope.rsvpNow = function(){
          $scope.showRSVPPrompt = $scope.showRSVPPrompt ? false : true;
        };

        /**
         * Send rsvp details to server
         * @param rsvpModel {{}}
         */
        $scope.submitRsvp = function(rsvpModel){
            if(!$scope.enablePreviewMode) {
                console.log(rsvpModel);
                var data = rsvpModel;
                data.userID = $scope.guestModel.event.userID;
                data.transactionID = origTransactionID;
                var formData1 = {"RSVPType": data.rsvpOption, "guestNumber": data.guestNumber, "kidsNumber": data.kidsNumber, "guestView": "1"};
                var formData2 = {'RSVPJSON': encodeURIComponent(JSON.stringify(formData1))};
                var formData = Utility.objectToRequestData(formData2);
                var request = GuestService.rsvp(data.transactionID).customPOST(formData);
                request.then(rsvpResponse, errorHandler);
            }else{
                showRsvpResponse();
            }
        };

        /**
         * Rsvp response
         * @param response {{}}
         */
        function rsvpResponse(response){
            $scope.serverResponse = response.description;
            console.log(response);
            if(response.status.toUpperCase() == 'SUCCESS') {
                console.log("rsvp response", response);
                var res = response.data;
                //TODO update guestModel.rsvpDetails here
                showRsvpResponse();
            }else{
                errorHandler(response);
            }
        }

        function showRsvpResponse(){
            var rsvp = $scope.rsvpModel.rsvpOption;
            var text = '';
            if(rsvp == '1'){
                text = 'Yes';
            }
            if(rsvp == '2'){
                text = 'No';
            }
            if(rsvp == '3'){
                text = 'Maybe';
            }

            $scope.rsvpComplete.hostName = $scope.guestModel.event.eventHostName;
            $scope.rsvpComplete.rsvpOption = text;
            $scope.rsvpCompleted = true;
            $scope.showRSVPPrompt = false;
        }

        $scope.changeRsvp = function(){
            $scope.rsvpCompleted = false;
            $scope.showRSVPPrompt = true;
        };

        /**
         * Send Comment to server
         * @param comment {string}
         */
        $scope.submitComment = function(comment){
            if(!$scope.enablePreviewMode) {
                var userID = $scope.guestModel.event.userID;
                var guestDetails = $scope.guestModel.rsvpDetails;
                console.log(userID, guestDetails);
                var formData1 = {"name": guestDetails.name, "email": guestDetails.email, "comment": comment};
                var formData2 = {'userID': userID, 'commentJSON': encodeURIComponent(JSON.stringify(formData1))};
                var formData = Utility.objectToRequestData(formData2);
                console.log($scope.guestModel);
                var eventID = $scope.guestModel.event.eventID;
                var request = GuestService.comments(eventID).customPOST(formData);
                request.then(commentResponse, errorHandler);
            }else{
                var dummyData = {"name":'',"email":'',"comment":'',"commentDateTime":'',"image":''};
                    dummyData.email = $scope.guestModel.event.eventHostEmail;
                    dummyData.name = $scope.guestModel.event.eventHostName;
                    dummyData.comment = comment;
                    dummyData.image = CONSTANTS.DUMMY_USER_PIC;
                showCommentResponse(dummyData);
            }
        };

        /**
         * Comment response
         * @param response
         */
        function commentResponse(response){
            console.log(response);
            $scope.serverResponse = angular.copy(response.description);
            if(response.status.toUpperCase() == 'SUCCESS') {
                var res = response.data;
                //TODO Upate guestModel.comments here
                showCommentResponse(res);
            }else{
                errorHandler(response);
            }
        }

        function showCommentResponse(data){
            $scope.guestModel.comments.unshift(data);
            $scope.commentModel.text = "";
        }

        $scope.sendTestEmail = function(){
            var data = encodeURIComponent(JSON.stringify($scope.guestModel.event));
            var filter = Utility.objectToRequestData({'eventDetails': data});
            GuestService.sendTestEmail(origEventID).customPOST(filter).then(function(response){
                console.log(response);
                if(response.status.toUpperCase() == 'SUCCESS'){
                    //TODO show test mail has been sent to your register email
                    testmailResponse();
                }
            }, errorHandler);
        };

        function testmailResponse(){
            var data = {description: "a test email has been sent to registred email"};
            $rootScope.$emit("showInfoBar",data);
        }

        function setVideoOptions(data){
            //VIDEO JS
            var _V_ = videojs;
            // custom player swf file
            _V_.options.flash.swf = "/public/js/lib/video-js/video-js.swf";

            // flashvars
            _V_.options.flash.flashVars = {
                file: data.videoURL,
                image: data.videoThumbURL,
                autostart: "false",
                provider: "http",
                "http.startparam": "starttime"
            };

            // object params
            _V_.options.flash.params = {
                allowfullscreen: "true",
                wmode: "transparent",
                allowscriptaccess: "always"
            };

            // object attributes (such as id, name, class, etc.)
            _V_.options.flash.attributes={};

            var video_1_Player = videojs('event_video');
        }

        $scope.closePreviewWindow = function(){
            window.close();
        };

        function updateGuestView(transactionID){
            GuestService.guestView(transactionID).post().then(function(response){
                console('Guest View Response', response);
                if(response.status.toUpperCase() == 'SUCCESS'){

                }
            },errorHandler);
        }

    }]);


});