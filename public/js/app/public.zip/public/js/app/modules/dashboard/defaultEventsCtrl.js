define([
    'angular'
],
function(angular){
    var dashboard = angular.module("Inwiter.Dashboard");

    if(dashboard.register != undefined){
        dashboard = dashboard.register;
    }

    dashboard.controller("DefaultEventsCtrl", ['$scope', '$location', '$rootScope', '$injector', 'Restangular', 'AuthService', 'EventService', 'EventsLibraryModel', function($scope, $location, $rootScope, $injector, Restangular, Auth, EventService, EventModel){

        var startLimit = 0;
        var defaultItemsLimit = 6;
        var viewAllItemsLimit = 10;
        var selectedTab = 'upcoming';
        var itemsQueried = 0;
        var itemsFetched = 0;
        $scope.showResponseMessage= '';
        $scope.selectedEvents = [];
        $scope.recurrenceEventsList = [];
        $scope.defaultView = true;
        $scope.response = [];
        $scope.eventsLibrary = EventModel.getEvents();



        $scope.showPastEvents = function(){
            selectedTab = 'past';
            $scope.defaultView = true;
            EventModel.removeAllEvents();
            getEvents(startLimit, defaultItemsLimit, selectedTab);
        };

        $scope.showUpcomingEvents = function(){
            selectedTab = 'upcoming';
            $scope.defaultView = true;
            EventModel.removeAllEvents();
            getEvents(startLimit, defaultItemsLimit, selectedTab);
        };

        $scope.nextPage = function(){
            console.log(itemsQueried);
            if(itemsFetched >= itemsQueried){
                var lnt = $scope.eventsLibrary.length;
                var sLimit = lnt;
                var eLimit = defaultItemsLimit;
                getEvents(sLimit, eLimit, selectedTab);
            }
        };

        $scope.showAllEvents = function(){
            $scope.defaultView = false;
            $scope.selectedEvents = [];
        };

        $scope.deleteEvent = function(eventId, flag){
            console.log("selected item index--"+eventId);
            if(typeof eventId === 'object'){
                removeSelectedEvents(eventId);
            }

            if(typeof eventId === 'number'){
                var data = [];
                data.push(eventId);
                removeSelectedEvents(data, flag);
            }
        };

        $scope.deleteSelectedEvents = function(flag){
            removeSelectedEvents($scope.selectedEvents, flag);
        };

        /**
         * Event selection functionality
         * @param size
         */

            // selected events
        $scope.selectedEvents = [];

        // toggle selection for a given eventId
        $scope.toggleEventSelection = function toggleSelection(eventId) {
            var idx = $scope.selectedEvents.indexOf(eventId);

            // is currently selected
            if (idx > -1) {
                $scope.selectedEvents.splice(idx, 1);
            }

            // is newly selected
            else {
                $scope.selectedEvents.push(eventId);
            }
            console.log($scope.selectedEvents);
        };

        /**
         * Delete/Cancel/Remove selected or signle event
         */
        function removeSelectedEvents(items, flag){
            var data = {"flag": flag, "eventIds":items};
            EventService.post(data).then(deleteSuccess, errorHandler);
        }

        function deleteSuccess(response){
            console.log(response);
            $scope.showResponseMessage = response.data;
            $scope.nextPage();
        }


        /**
         * Get events from server
         * @param startLimit {int}
         * @param endLimit {int}
         * @param type {string}
         */
        function getEvents(startLimit, endLimit, type){
            var filters = {"silimit": startLimit, "elimit": endLimit, "type": type};
            var data = EventService.getList(filters);
            console.log(data);
            $scope.response = data.$object;
            data.then(eventsResponse, errorHandler);
        }

        /**
         * events response
         * @param response
         */
        function eventsResponse(response){
            console.log($scope.response.length);
            itemsFetched = $scope.response.length;
            var res = $scope.response;
            EventModel.addEvents(res);
            updateQueue(res);
        }

        /**
         * error handler
         * @param error
         */
        function errorHandler(error){

        }

        /**
         * Update queue after server response
         * @param data
         */
        function updateQueue(data){
            $scope.eventsLibrary = EventModel.getEvents();
        }

        /**
         * Recurrence event functionality
         *
         */
        var recurrenceRequestData = {};
        $scope.recurrenceEventData = function(eventId){
            var filters = {"type":"recurrence"};
            var request = Restangular.one(EventService, eventId).getList(filters);
            recurrenceRequestData = request.$object;
            request.then(recurrenceResponse, errorHandler);
        };

        function recurrenceResponse(response){
            console.log(response);
            $scope.recurrenceEventsList = recurrenceRequestData;
        }

    }]);



});
