define([
    'angular'
],
function(angular){
    var eventsLibrary = angular.module("Inwiter.EventsLibrary");
    if(eventsLibrary.register != undefined){
        eventsLibrary = eventsLibrary.register;
    }
    eventsLibrary.factory("EventsLibraryModel", ['EventService', function(EventService){
        var eventsLibraryModel;
        var defaultEvents = [];
        var eventsModel = {
                            upcoming: [],
                            past: [],
                            all: []
                          };

        eventsLibraryModel = {
                                /** Past Events **/
                                getEvents: function(){
                                    return eventsModel;
                                },
                                addEvents: function(items, type){
                                    console.log(items, type, eventsModel);

                                    var pos = [];
                                    for(var i=0; i<items.length; i++){
                                        var p;
                                        p = eventsModel[type].push(items[i]);
                                        pos.push(p);
                                    }
                                    return pos;
                                },
                                removeEvents: function(indexesArray, type){
                                    var pos = [];
                                    for(var i=0; i<indexesArray.length; i++){
                                        var eventID = indexesArray[i];
                                        var data = eventsModel[type];
                                        for(var j=0; j<data.length; j++){
                                            var eid = data[j].eventInfo.eventID;
                                            if(eid == eventID){
                                                var p = eventsModel[type].splice(j, 1);
                                                pos.push(p);
                                            }
                                        }
                                    }
                                    return pos;
                                },
                                removeAllEvents: function(){
                                    eventsModel.upcoming = [];
                                    eventsModel.past = [];
                                    eventsModel.all = [];
                                    return true;
                                }

                            };

        return eventsLibraryModel;
    }]);
});

/**
getUpcomingEvents: function(){
    return pastEvents;
},
addToUpcomingEvents: function(items){
    pastEvents.push(items);
},
removeUpcomingEvents: function(indexesArray){
    for(var i=0; i<indexesArray.length; i++){
        var index = indexesArray[i];
        pastEvents.splice(index, 1);
    }
},
removeAllUpcomingEvents: function(){
    upcomingEvents = [];
    return true;
}
*/