define(['angular'], function(angular){
    var eventTheme = angular.module('Inwiter.CreateEvent.EventTheme');

    eventTheme.factory("EventThemeService", ['Restangular', 'AuthService', function (Restangular, Auth) {

        return  {
                    getBackgrounds: function(){
                        return Restangular.one('backgrounds');
                    },
                    uploadBackground: function(){
                        return Restangular.service('upload',Restangular.one('user', Auth.currentUserId())).one();
                    }
                }

    }]);
});