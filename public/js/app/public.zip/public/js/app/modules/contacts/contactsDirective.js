define([
    'angular'
], function(angular){
    var contacts = angular.module("Inwiter.Contacts");
    if(contacts.register != undefined){
        contacts = contacts.register;
    }
    contacts.directive("addContact", [function(){

    }]);
});