define(['angular'], function(angular){
    angular.module('Inwiter.CreateEvent.EventTheme', ['angularFileUpload']);
});