define([
        'angular'
    ],
    function (angular) {

        angular.module('Inwiter')

            .controller('AppLogoutCtrl', ['$scope', '$rootScope', 'Restangular', 'AuthService', 'UserService', 'LocalStorageService', '$location', function ($scope, $rootScope, Restangular, Auth, Users, LocalStorage, $location) {

                /** Logout from app **/
                LocalStorage.clearAll(); //Clear all locastorage data
                Auth.logout(); //Clear auth data
                window.location.href = '/';
            }]);

    });