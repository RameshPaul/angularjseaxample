define([
    'angular'
],
function (angular) {
    var eventContacts = angular.module('Inwiter.CreateEvent.EventContacts');

    eventContacts.directive("guestdir", ['$compile',function($compile){
        return {
            restrict: 'E',
            compile: function(element, attrs) {
                var html = "<input id='inputId' check-email-validity name='guestGmail' type='email' ng-model='" + attrs.guestdirModel + "' email-index='"+attrs.emailIndex+"' class='form-control input-medium' placeholder='"+attrs.placeholder+"' required/>";
                element.replaceWith(html);
                return function(scope, element, attrs, ngModel) {
                    $compile(angular.element(element))(scope);
                };
            }
        };
    }]);

    eventContacts.directive("addGuestEmail",['UtilityService', '$compile', function(Utility, $compile){
        return{
            restrict: 'A',
            link: function(scope, element, attrs) {
                element.unbind('click');
                element.bind("click", function(){
                    console.log("email -- "+attrs.addGuestEmail);
                    var email = attrs.addGuestEmail;
                    if(Utility.validateEmail(email)){
                        var prevIndex = parseInt(attrs.emailIndex);
                        scope.eventGuestList[prevIndex].addRemove = false;
                        var pos = scope.addEmail();
                        if(pos != -1){
                            //scope.eventGuestList[pos-1].valid = true;
                            var emailData = {valid: true, email: email, index: prevIndex};
                            scope.$emit("updateEmailsQueue", emailData);
                            scope.$apply();
                            console.log(scope.eventGuestList);
                            scope.$apply();
                            console.log(element.parent().next().children().eq(0));
                            element.parent().next().children().eq(0)[0].focus();
                        }
                        scope.$apply();
                    }else{
                        var pos = parseInt(attrs.emailIndex);
                        console.log(" position -"+pos);
                        scope.eventGuestList[pos].valid = false;
                        element.parent().find('input')[0].focus();
                        scope.trigger = false;
                        scope.$apply();
                    }
                });

                /**
                 * ENABLE DISABLE SAVE BUTTONS
                 */
                scope.$on("enableDisableSaveGroup", function(e, data){
                    console.log("enable disable save group event");
                    if(scope.eventGuestList.length > 0){
                        scope.disableSaveGroup = false;
                    }else {
                        scope.disableSaveGroup = true;
                    }
                    scope.$apply();
                    console.log(" save group = "+scope.disableSaveGroup);
                });
                //scope.$apply();
            }
         }
    }]);

    eventContacts.directive("removeGuestEmail", [function(){
        return{
            restrict: 'A',
            link: function(scope, element, attrs){
                element.unbind("click");
                element.bind("click", function(event){
                    var pos = parseInt(attrs.removeGuestEmail);
                    console.log("remove email directive pos", pos);
                    var limit = scope.guestListLimit;

                    var length = scope.eventGuestList.length;
                    console.log(limit, length);

                    if(length === limit){
                        console.log(scope.eventGuestList[length-1].addRemove);
                        scope.eventGuestList[length-1].addRemove = true;
                        //scope.$apply();
                        console.log(scope.eventGuestList[length-1].addRemove);
                    }
                    var rmpos = scope.removeEmail(pos);
                    scope.$apply();

                });
            }
        }
    }]);

    eventContacts.directive("checkEmailValidity", ['UtilityService', '$compile', '$timeout', function(Utility, $compile, $timeout){
        return{
            restrict: 'A',
            link: function (scope, element, attrs) {
                element.unbind('keyup');
                element.bind("keyup", function (event) {
                    console.log("on key up event");
                    var email = element.val();
                    var pos = parseInt(attrs.emailIndex);


                    if (Utility.validateEmail(email)) {
                        scope.eventGuestList[pos].valid = true;
                        scope.enableEmailsDoneBtn = false;
                        var data = {valid: true};
                        scope.$emit("isEmailValid", data);
                        if (event.which === 13) {
                            scope.eventGuestList[pos].addRemove = false;
                            var addpos = scope.addEmail();
                            if(addpos != -1) {
                                var emailData = {valid: true, email: email, index: pos};
                                scope.$emit("updateEmailsQueue", emailData);
                                scope.$apply();
                                console.log(element.parent().next().children().eq(0));
                                $timeout(function(){
                                    element.parent().next().children().eq(0)[0].focus();
                                }, 100);
                            }
                        }
                        console.log(scope.eventGuestList, scope.enableEmailsDoneBtn);
                        scope.$apply();
                    } else {
                        console.log(" position -" + pos);
                        scope.eventGuestList[pos].valid = false;
                        scope.trigger = false;
                        var data = {valid: false};
                        scope.$emit("isEmailValid", data);
                        //scope.$apply();
                    }
                    scope.$apply();
                });

            }
        }
    }]);

});
