define([
        'angular'
],
function (angular) {
    var eventDetails = angular.module('Inwiter.CreateEvent.EventContacts');

    eventDetails.controller('EventContactsCtrl',['$scope', '$location', '$rootScope', 'UserModel', 'EventGuestListModel', 'ContactsService', 'ContactsJSONModel', '$timeout', 'ContactsImporterService', 'UtilityService', 'CreateEventModel', function($scope, $location, $rootScope, UserModel, GuestListModel, ContactsService, ContactsJSONModel, $timeout, ContactsImporterService, Utility, CreateEventModel){

        //GLOBAL FALGS
        $scope.disableSaveGroup = false;
        $scope.showError = false;
        $scope.errorMessage = '';
        $scope.guestListLimit = 10000;
        $scope.contactsEntered = false;
        $scope.saveToGroupName = '';
        $scope.newGroupName = '';
        $scope.contactsGroups = [];
        $scope.enableEmailsDoneBtn = true;
        $scope.guestdirModel = '';
        $scope.emailsEnteredCount = 0;
        $scope.enteredEmails = [];
        $scope.contactObj = {"email": '', "name":'',"addRemove":true, "valid": true};
        $scope.contactsResponseText = '';
        $scope.showContactsResponse = false;
        $scope.userGroupsList = [];
        $scope.showUserGroupsList = false;
        $scope.groupSelectedComplete = false;

        //Contacts View Model
        $scope.eventGuestList = GuestListModel.getGuestList();
        $scope.eventGuestListOriginal = [];

        $rootScope.guestListData = $scope.eventGuestList;

        $scope.importContactsTemplate = ContactsImporterService.templateURL();

        //Add contact function
        $scope.addEmail = function(emailData){
            errorResponse(false, '');
            if($scope.eventGuestList.length < $scope.guestListLimit){
                var data = angular.copy($scope.contactObj);
                //var pos = GuestListModel.addNewGuest(data);
                if(emailData != undefined){
                    data.email = emailData.email;
                    data.name = emailData.name;
                    data.addRemove = false;
                    data.valid = true;
                }
                var pos = $scope.eventGuestList.push(data);
                enableDisableSaveGroup();
                //$scope.$broadcast("enableDisableSaveGroup");
                return pos;
            }else{
                errorResponse(false, 'You can only add '+ $scope.guestListLimit +' guests for your account type');
                return -1;
            }
        };
        //Remove contact
        $scope.removeEmail = function(position){
            errorResponse(false, '');
            console.log("remove position", position);
             //Send request to api if it is editing one
            //var pos = GuestListModel.removeGuest(position);
            var pos = $scope.eventGuestList.splice(position, 1);
            console.log($scope.eventGuestList);
            enableDisableSaveGroup();
            //$scope.$broadcast("enableDisableSaveGroup");
            return pos;
        };

        $scope.$on("isEmailValid", function(event, data){
            console.log("is email valid", data);
            if(data.valid){
                $scope.enableEmailsDoneBtn = false;
            }else{
                $scope.enableEmailsDoneBtn = true;
            }
        });

        $scope.$on("updateEmailsQueue", function(event, data){
            var vl = {"email": data.email, "name":'',"addRemove":false, "valid": true};
            $scope.eventGuestList[data.index].email = data.email;
            $scope.enteredEmails.push(vl);
        });

        $scope.saveToGroup = function(groupName){
            //Call to api to save entered contacts as group
            console.log("group name "+groupName);
            createGroup(groupName);
            $scope.newGroupName = '';
            console.log($scope.saveToGroupForm.newGroup.$error);
            $timeout(function(){
                //$scope.saveToGroupForm.newGroup.$error.required = false;
            }, 100);
        };

        function createGroup(groupName){
            var groupData = ContactsJSONModel.createGroup(groupName);
            ContactsService.createGroup().customPUT(groupData).then(function(response){
                console.log(response);
                if(response.status.toUpperCase() == 'SUCCESS'){
                    response.data['groupName'] = groupName;
                    addtoGroup(response.data);
                }else{
                    showResponse(response);
                }
            }, errorResponse);
        }

        function addtoGroup(groupInfo){
            console.log("groudata received ", groupData);
            var contacts = GuestListModel.getGuestList();
            var groupData = ContactsJSONModel.addContactsToGroup(groupInfo, contacts);
            console.log(groupData);
            if(contacts.length > 0){
                errorResponse(false, '');
                ContactsService.addGroupContacts(groupInfo.groupID).customPUT(groupData).then(function(response){
                    console.log(response);
                    if(response.status.toUpperCase() == 'SUCCESS'){
                        showResponse(response);
                    }else{
                        showResponse(response);
                    }
                },errorResponse);
            }else{
                errorResponse(true, 'Please enter guest eamils first');
            }
        }

        $scope.emailsEntryDone = function(guest){
            console.log("entered emails", $scope.eventGuestList);
            //$scope.eventGuestList = angular.copy($scope.enteredEmails);
            GuestListModel.setGuestList($scope.eventGuestList);
            //$scope.eventGuestList = GuestListModel.getGuestList();
            $scope.emailsEnteredCount = GuestListModel.emailsCount();
            $scope.contactsEntered = true;
        };

        $scope.emailsEntryCancel = function(){
            console.log("cancel - entered emails", $scope.enteredEmails);
            //$scope.eventGuestList = angular.copy($scope.eventGuestListOriginal);
            //GuestListModel.setGuestList($scope.eventGuestList);
            console.log($scope.eventGuestList);
        };

        $scope.openEmailsEntry = function(){
            console.log("contacts model", GuestListModel.getGuestList());
            //$scope.enteredEmails = angular.copy($scope.eventGuestList);
            $scope.eventGuestList = angular.copy(GuestListModel.getGuestList());
            //$timeout(function(){
                //$scope.eventGuestList = angular.copy($scope.enteredEmails);
                //$scope.eventGuestListOriginal = angular.copy($scope.eventGuestList);
            //}, 100);
            //console.log($scope.eventGuestListOriginal);
        };


        $rootScope.validateContacts = function validateContacts(){
            var invalidOne = [];
            var isValid = false;
            var i = 0;
            var lnt = $scope.eventGuestList.length;
            for(i; i<$scope.eventGuestList.length; i++){
                var email = $scope.eventGuestList[i].email;
                console.log(Utility.validateEmail(email));
                if(Utility.validateEmail(email)){
                    isValid = true;
                }else{
                    isValid = false;
                    i=$scope.eventGuestList.length+1;
                }
            }

            if(lnt == 1 && isValid == false){
                return false;
            }else if(lnt > 1 && isValid == false){
                return true;
            }
        }

        function enableDisableSaveGroup(){
            if(validateContacts()){
                $scope.disableSaveGroup = false;
            }else {
                $scope.disableSaveGroup = true;
            }
            $scope.$apply();
            console.log(" save group = "+$scope.disableSaveGroup);
        }


        function setGuestList(list){
            return GuestListModel.setGuestList(list);
        }



        function errorResponse(flag, message){
            if(flag){
                $scope.showError = true;
                $scope.errorMessage = message;
            }else{
                $scope.showError = false;
                $scope.errorMessage = '';
            }

        }

        function showResponse(data){
            $scope.contactsResponseText = data.description;
            $scope.showContactsResponse = true;
            $timeout(function(){
                $scope.showContactsResponse = false;
            }, 2000);
        }


        /**
         * CONTACTS IMPORT SERVICE
         */
        ContactsImporterService.init(function(data){
            console.log("contacts imported successfully", data);
        }, function(data){
            console.log("contacts import failed", data);
        });

        $rootScope.$on("importSelectedContacts", function(e, data){
            console.log("contacts imported successfully", data);
            addToContactsList(data);
        });

        function addToContactsList(data){
            console.log(validateContacts());
            if(!validateContacts()){
                $scope.eventGuestList = [];
                console.log(" validate contacts failed");

            }
            for(var i=0; i<data.length; i++){
                var cobj = angular.copy($scope.contactObj);
                cobj.email = data[i].email;
                cobj.name = data[i].name;
                cobj.addRemove = false;
                cobj.valid = true;
                console.log(cobj);
                //$scope.eventGuestList.push(cobj);
                $scope.addEmail(cobj);
                //var prevIndex = $scope.eventGuestList.length;
                //var emailData = {valid: true, email: data[i].email, index: prevIndex};
                //$scope.$emit("updateEmailsQueue", emailData);

            }
            console.log($scope.eventGuestList);
            $scope.addEmail();
            //enableDisableSaveGroup();
            var status = {valid: true};
            $scope.$emit("isEmailValid", status);
            $scope.$apply();
        }

        /**
         * GET groups list
         */
        $scope.groupSelected = '';
        $scope.groupSelectionError = false;
        $scope.groups = {};
        $scope.groups.selectedGroupName = '';
        $scope.groups.selectedGroupID = '';
        $rootScope.userGroups = [];

        $scope.onGroupSelection = function(groupID, groupName){
            console.log("group changed ", groupID);
            if(groupID != "") {
                ContactsService.getGroupContacts(groupID).get().then(function (response) {
                    console.log(response.data);
                    if (response.status.toUpperCase() == 'SUCCESS') {
                        var contacts = response.data.groupContacts;
                        var lnt = contacts.length;
                        groupSelectionResponse(contacts, groupID, groupName);
                    }
                }, function () {

                });
            }
        };

        function groupSelectionResponse(contacts, groupID, groupName){
            var lnt = contacts.length;
            console.log("group selection reponse", contacts);
            if(lnt <= 0){
                console.log("group selection error");
                $scope.groupSelectionError = true;
                $timeout(function(){
                    $scope.groupSelectionError = false;
                }, 2000);
            }else{
                $scope.groups.selectedGroupName = groupName;
                $scope.groups.selectedGroupID = groupID;
                $scope.groupSelectedComplete = true;
                $scope.contactsEntered = true;
                GuestListModel.setGuestList(contacts);
            }
        }

        $scope.changeSelectedGroup = function(){
            GuestListModel.setGuestList([]);
            $scope.groupSelectedComplete = false;
            $scope.contactsEntered = false;
        };

        function getGroups(){
            ContactsService.getGroups().customGET().then(function(response){
                console.log(response);
                if(response.status.toUpperCase() === 'SUCCESS'){
                    if(response.data.userGroups.length > 0) {
                        $scope.userGroupsList = response.data.userGroups;
                        $rootScope.userGroups = response.data.userGroups;
                        $scope.showUserGroupsList = true;
                    }else{
                        $scope.showUserGroupsList = false;
                    }
                }
            }, function(response){
                console.log(response);
            });
        }

        (function(){
            getGroups();
        })();

        /**
         * EDIT EVENT FUNCTIONALITY
         */
        if($rootScope.isEdit){
            updateEditEventData();
        }

        function updateEditEventData(){
            //var eventContacts = CreateEventModel.getEventContacts();
            //console.log(eventContacts);
            //addToContactsList(eventContacts);
        }
    }]);

});