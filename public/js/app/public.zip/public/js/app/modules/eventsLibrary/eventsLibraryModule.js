define([
    'angular'
],
function(angular){
    var eventsLibrary = angular.module("Inwiter.EventsLibrary", ['Inwiter.Socialshare']);

        eventsLibrary.run(['SocialShareAPIKeys', '$FB', function(SocialShareAPIKeys, $FB){
             $FB.init(SocialShareAPIKeys.fb.appId);
         }]);
});