define([
    'angular'
], function(angular){
    var dashboard = angular.module("Inwiter.Dashboard");
    if(dashboard.register != undefined){
        dashboard = dashboard.register;
    }
    dashboard.controller("DashboardCtrl", ['$scope', '$location', '$rootScope', 'DashboardModel', 'UserModel', function($scope, $location, $rootScope, DashboardModel, UserModel){
        //Route to this page if it is active
        $scope.isActive = function(route) {
            return route === $location.path();
        };

        //GET USERNAME
        $scope.user = UserModel.getUser();

        console.log($scope.user);
        //LOAD EVENTS LIBRARY TEMPLATE

        $scope.templates = {
            defaultEvents: {name: 'eventsLibraryDefaultTpl.html', url : '/public/js/app/modules/eventsLibrary/eventsLibraryDefaultTpl.html'},
            emptyDashboard: {name: 'eventsLibraryAllTpl.html', url : '/public/js/app/modules/eventsLibrary/eventsLibraryAllTpl.html'}
        };

        $scope.templates.eventsLibrary = $scope.templates.defaultEvents;

        console.log("In dashboard controller");

    }]);
});