define([
        'angular'
],
function (angular) {

var inwiterApp = angular.module('Inwiter.CreateEvent');
    if(inwiterApp.register != undefined){
        inwiterApp = inwiterApp.register;
    }

    inwiterApp.factory('CreateEventService', ['Restangular', 'AuthService', function (Restangular, Auth) {
            console.log(Auth.currentUserId());
            var url = Restangular.service('events', Restangular.one('user', Auth.currentUserId()));

            return{
                getEventDetails: function(eventID){
                    return url.one(eventID);
                },
                getScheduleInfo: function(eventID){
                    return url.one(eventID).one('scheduleinfo');
                },
                getEventGuestList: function(eventID){
                    return url.one(eventID).one('guestlist');
                },
                getEventVideo: function(eventID){
                    return url.one(eventID).one('videotimeline');
                }

            }


        }]);

});