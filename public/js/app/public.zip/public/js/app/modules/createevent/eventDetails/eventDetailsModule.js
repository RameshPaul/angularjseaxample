define([
        'angular',
        'eventDetailsDeps'
    ],

function (angular) {

    return angular.module('Inwiter.CreateEvent.EventDetails', [
                                                    'mgcrea.ngStrap',
                                                    'textAngular'
                                                    //'GoogleLocationModule'
                                                  ]);

});
