define([
    'angular'
],
function (angular) {
    var createEvent = angular.module('Inwiter.CreateEvent');
    if(createEvent.register != undefined){
        createEvent = createEvent.register;
    }

    createEvent.directive("saveDraft",[function(){
        return{
            restrict: 'A',
            link: function(scope, element, attrs){
                element.click(function(e){
                    jQuery("#event-details-form-validate").trigger("click");
                });
            }
        }
    }]);

    createEvent.directive("eventDetailsForm", ['$rootScope','UtilityService', function($rootScope, Utility){
        return{
            restrict: 'A',
            link: function(scope, element, attrs){
                console.log(element);
                console.log("Event details form directive attributes ",attrs);
                element.attr("required",'');
                jQuery("#eventDetailsForm [name=eventname]").focus();

                /**
                 * Event Details form validation using jQuery
                 */

                /** Elements declaration **/


                /** Hide errors on field click **/
                jQuery("#eventDetailsForm .form-control").on('click', function(){
                    jQuery(this).parent().children('.text-error').addClass('hide');
                    jQuery(this).parent('.clearfix').children('.text-error').addClass('hide');
                });

                jQuery("#eventDetailsForm .radio").on('click', function(){
                    jQuery(this).parents('.clearfix').children('.text-error').addClass('hide');
                });

                jQuery(".create-event").on('click', '.event-guest-list-elm', function(){
                    jQuery("#eventGuestListErr").addClass('hide');
                });

                jQuery(".create-event").on('click', '.event-video-elm', function(){
                   jQuery("#eventVideoTimeLineErr").addClass('hide');
                });

                /**
                 * Validation click events
                 */
                jQuery("#event-details-form-validate").unbind('click')
                    .on('click', function(){
                        validateEventDetails();
                    });
                jQuery("#save-draft")
                    .on('click', function(){
                       var vl = validateForSaveDraft();
                        if(vl){
                            $rootScope.isCreateEventValid = true;
                            $rootScope.$emit('onFormValidationComplete', {'target':'save'});
                        }else{
                            $rootScope.isCreateEventValid = false;
                        }
                        console.log($rootScope.isCreateEventValid);
                    });

                jQuery("#preview-event").unbind('click')
                    .on('click', function(){
                        var vl = validateForSaveDraft();
                        if(vl){
                            $rootScope.isCreateEventValid = true;
                            $rootScope.$emit('onFormValidationComplete', {'target':'preview'});
                        }else{
                            $rootScope.isCreateEventValid = false;
                        }
                        console.log($rootScope.isCreateEventValid);
                    });

                jQuery("#create-event").unbind('click')
                    .on('click', function(){
                        validateForSend();
                    });

                function validateForSaveDraft(){
                    /** RSVP Select option validation **/
                    var needRsvpElm = jQuery("#eventDetailsForm [name=needRsvp]"),
                        needRsvp = jQuery("#eventDetailsForm [name=needRsvp]:checked").length,
                        needRsvpErrElm = jQuery("#eventDetailsForm .need-rsvp-error");
                    if(needRsvp < 1){
                        needRsvpErrElm.removeClass('hide');
                        needRsvpElm.focus();
                        return false;
                    }else{
                        needRsvpErrElm.addClass('hide');
                    }

                    /** Event category option validation **/
                    var eventCategoryElm = jQuery("#eventDetailsForm [name=eventcategory]"),
                        eventCategoryErrElm = jQuery("#eventDetailsForm .event-category-error");
                    if(!Utility.isEmpty(eventCategoryElm.val())){
                        eventCategoryErrElm.removeClass('hide');
                        eventCategoryElm.focus();
                        return false;
                    }else{
                        eventCategoryErrElm.addClass('hide');
                    }

                    /** Event Name field validation **/
                    var eventNameElm = jQuery("#eventDetailsForm [name=eventname]"),
                        eventNameErrElm = jQuery("#eventDetailsForm .event-name-error");
                    if(!Utility.isEmpty(eventNameElm.val())){
                        eventNameErrElm.removeClass('hide');
                        eventNameElm.focus();
                        return false;
                    }else{
                        eventNameErrElm.addClass('hide');
                    }

                    /** Event Start Date validation **/
                    if(needRsvpElm.val() === '1') {
                        var eventStartDateElm = jQuery("#eventDetailsForm [name=eventstartdt]"),
                            eventStartDateErrElm = jQuery("#eventDetailsForm .event-start-dt-error");
                        if (!Utility.isEmpty(eventStartDateElm.val())) {
                            eventStartDateErrElm.removeClass('hide');
                            eventStartDateElm.focus();
                            return false;
                        } else {
                            eventStartDateErrElm.addClass('hide');
                        }
                    }

                    /** Event Start Time validation **/
                    if(needRsvpElm.val() === '1') {
                        var eventStartDateTimeElm = jQuery("#eventDetailsForm [name=eventstarttm]"),
                            eventStartDateTimeErrElm = jQuery("#eventDetailsForm .event-start-tm-error");
                        if (!Utility.isEmpty(eventStartDateTimeElm.val())) {
                            eventStartDateTimeErrElm.removeClass('hide');
                            eventStartDateTimeElm.focus();
                            return false;
                        } else {
                            eventStartDateTimeErrElm.addClass('hide');
                        }
                    }

                    return true;
                }

                function validateForPreview(){

                }

                function validateForSend(){
                    var startDate = $rootScope.totalEventDetails.eventDetails.eventStartDate;
                    var startTime = $rootScope.totalEventDetails.eventDetails.eventStartTime;
                    var endDate = $rootScope.totalEventDetails.eventDetails.eventEndDate;
                    var endTime = $rootScope.totalEventDetails.eventDetails.eventEndTime;
                    var tillDate = $rootScope.totalEventDetails.eventRecursion.endDate;
                    var scheduleDate = $rootScope.totalEventDetails.schedulingOption.scheduleDate;
                    var scheduleOption = $rootScope.totalEventDetails.schedulingOption.schedule;

                    var eventStartDateErrElm = jQuery("#eventDetailsForm .event-start-dt-error");
                    var eventStartDateElm = jQuery("#eventDetailsForm [name=eventstartdt]");

                    var vl = validateEventDetails();
                    if(vl){
                        if(validateContacts()) {
                            if(validateVideoTimeLine()){
                                scope.validateUTCDate().then(function(response){
                                    console.log("utc date", response);
                                    console.log(startDate, startTime, endDate, endTime, tillDate);
                                    if(response.status.toUpperCase() == 'ERROR'){
                                        eventStartDateErrElm.removeClass('hide');
                                        eventStartDateElm.focus();
                                        return false;
                                    }else{
                                        if(endDate != ""){
                                            if(endDate < startDate){
                                                eventStartDateErrElm.removeClass('hide');
                                                eventStartDateElm.focus();
                                                return false;
                                            }
                                        }

                                        if(scheduleOption == '3'){
                                            if(tillDate < startDate){
                                                eventStartDateErrElm.removeClass('hide');
                                                eventStartDateElm.focus();
                                                return false;
                                            }
                                        }

                                        if(scheduleOption == '2'){
                                            if(scheduleDate < startDate){
                                                eventStartDateErrElm.removeClass('hide');
                                                eventStartDateElm.focus();
                                                return false;
                                            }
                                        }
                                        $rootScope.isCreateEventValid = true;
                                        $rootScope.$emit('onFormValidationComplete', {'target':'create'});
                                        return true;
                                    }
                                });
                            }else{
                                $rootScope.isCreateEventValid = false;
                            }
                        }else{
                            $rootScope.isCreateEventValid = false;
                        }
                    }else{
                        $rootScope.isCreateEventValid = false;
                    }
                }

                function validateEventDetails(){
                    if(validateForSaveDraft()) {
                        /** Event Timezone option validation **/
                        var eventTimezoneElm = jQuery("#eventDetailsForm [name=eventtimezone]"),
                            eventTimezoneErrElm = jQuery("#eventDetailsForm .event-timezone-error");
                        if (!Utility.isEmpty(eventTimezoneElm.val())) {
                            eventTimezoneErrElm.removeClass('hide');
                            eventTimezoneElm.focus();
                            return false;
                        } else {
                            eventTimezoneErrElm.addClass('hide');
                        }

                        /** Event Schedule validation **/
                        var eventScheduleOptionElm = jQuery("#eventDetailsForm [name=eventscheduleon]"),
                            eventScheduleOptionCheckedElm = jQuery("#eventDetailsForm [name=eventscheduleon]:checked"),
                            eventScheduleOptionErrElm = jQuery("#eventDetailsForm .event-schedule-on-error");
                        if (eventScheduleOptionCheckedElm.val()) {
                            if (eventScheduleOptionCheckedElm.attr('data-value') === '2') {
                                var eventScheduleDateElm = jQuery("#eventDetailsForm [name=eventscheduledate]"),
                                    eventScheduleDateErrElm = jQuery("#eventDetailsForm .event-schedule-date-error");
                                if (!Utility.isEmpty(eventScheduleDateElm.val())) {
                                    eventScheduleDateErrElm.removeClass('hide');
                                    eventScheduleDateElm.focus();
                                    return false;
                                } else {
                                    eventScheduleDateErrElm.addClass('hide');
                                }
                            }

                            console.log(eventScheduleOptionCheckedElm.attr('data-value'));
                            /** Event Recursion option validation **/
                            if (eventScheduleOptionCheckedElm.attr('data-value') === '3') {
                                console.log("scheduling option 2");
                                var eventRepeatTillDateElm = jQuery("#eventDetailsForm [name=eventrepeattilldate]"),
                                    eventRepeatTillDateErrorElm = jQuery("#eventDetailsForm .event-repeat-till-date-error");
                                console.log(eventRepeatTillDateElm.val());
                                if (!Utility.isEmpty(eventRepeatTillDateElm.val())) {
                                    eventRepeatTillDateErrorElm.removeClass('hide');
                                    eventRepeatTillDateElm.focus();
                                    return false;
                                } else {
                                    eventRepeatTillDateErrorElm.addClass('hide');
                                }

                                var eventRepeatOccationElm = jQuery("#eventDetailsForm [name=eventrepeatoccarance]"),
                                    eventRepeatOccationErrorElm = jQuery("#eventDetailsForm .event-repeat-occarance-error");
                                if (!Utility.isEmpty(eventRepeatOccationElm.val())) {
                                    eventRepeatOccationErrorElm.removeClass('hide');
                                    eventRepeatOccationElm.focus();
                                    return false;
                                } else {
                                    eventRepeatOccationErrorElm.addClass('hide');
                                }

                                var eventRepeatSendElm = jQuery("#eventDetailsForm [name=eventrepeatsend]"),
                                    eventRepeatSendErrorElm = jQuery("#eventDetailsForm .event-repeat-send-error");
                                if (!Utility.isEmpty(eventRepeatSendElm.val())) {
                                    eventRepeatSendErrorElm.removeClass('hide');
                                    eventRepeatSendElm.focus();
                                    return false;
                                } else {
                                    eventRepeatSendErrorElm.addClass('hide');
                                }

                            }
                        } else {
                            eventScheduleOptionErrElm.removeClass('hide');
                            eventScheduleOptionElm.focus();
                            return false;
                        }
                        return true;
                    }else{
                        return false;
                    }
                }

                /**
                 * Event Repeat Option Management
                 */
                var eventDetailsForm = jQuery("#eventDetailsForm");
                var eventScheduleOnElm = jQuery("#eventDetailsForm [name=eventscheduleon]");
                var dateDff = 0;
                var eventRepeatStartDateElm = jQuery("#eventDetailsForm [name=eventstartdt]"),
                    eventRepeatTillDateElm = jQuery("#eventDetailsForm [name=eventrepeattilldate]"),
                    eventRepeatTillDateName = "#recurrenceEndDate";

                /*
                eventScheduleOnElm.on("click", function(){
                    var val = jQuery(this).attr('data-value');
                    console.log(val);
                    if(val == '3'){
                        console.log("in is");
                        /** Calculate diff between start date and till date on till date change /

                        jQuery(".events").on("change", '#recurrenceEndDate', function(e){
                            console.log("in till date change");
                            var tillDateVal = this.value;
                            var startDateVal = eventRepeatStartDateElm.val();
                            //var cTillDateVal = tillDateVal.split("-");
                            //var cStartDateVal = startDateVal.split("-");
                            var fTillDateVal = new Date(tillDateVal);//cTillDateVal[0]+" "+cTillDateVal[1];
                            var fStartDateVal = new Date(startDateVal);//cStartDateVal[0]+" "+cStartDateVal[1];

                            console.log(tillDateVal+"--"+startDateVal);
                            var utcTillDate = new Date(Utility.convertLocalToUTCDate(fTillDateVal));
                            var utcStartDate = new Date(Utility.convertLocalToUTCDate(fStartDateVal));
                            console.log(utcStartDate+"=="+utcTillDate);
                            var eventRepeatTillDateErrorElm = jQuery(".event-repeat-till-date-error");

                            if(utcTillDate <= utcStartDate){
                                console.log("In if");
                                console.log(eventRepeatTillDateErrorElm);
                                eventRepeatTillDateErrorElm.removeClass('hide');
                                eventRepeatTillDateElm.focus();
                                return false;
                            }else{
                                eventRepeatTillDateErrorElm.addClass('hide');
                                var dateDiff = parseInt(Utility.getDateDiff(utcStartDate, utcTillDate));
                                console.log("Date diff:-"+dateDiff);
                                if(dateDiff <= 7){
                                    manageRepeatOccationOption(['0']);
                                }else if((dateDiff > 7) && (dateDiff <= 30)){
                                    manageRepeatOccationOption(['0','1']);
                                }else if((dateDiff > 30) && (dateDiff <= 365)){
                                    manageRepeatOccationOption(['0','1','2']);
                                }else if(dateDiff > 365){
                                    manageRepeatOccationOption(['0','1','2','3']);
                                }else{
                                    manageRepeatOccationOption([]);
                                }
                            }
                        });
                    }
                });


                function manageRepeatOccationOption(values){
                    var eventRepeatOccationOptionElm = jQuery("#eventDetailsForm [name=eventrepeatoccarance] > option");
                    eventRepeatOccationOptionElm.hide();
                    eventRepeatOccationOptionElm.each(function(index, elem){
                        for(var i=0; i<values.length; i++){
                            var elVal = this.value;
                            console.log(elVal);
                            if(elVal === values[i]){
                                jQuery(elem).show();
                            }
                        }
                    });
                }
                */

                /**
                 * Event Repeat next occarances calculation
                 /
                var eventDetailsForm = jQuery("#eventDetailsForm");
                var viewNextOccarancesElm = "#view-next-occarances";

                eventDetailsForm.on("click", viewNextOccarancesElm, function(){
                    var eventRepeatTillDateElm = jQuery("#eventDetailsForm [name=eventrepeattilldate]");
                    var eventRepeatStartDateElm = jQuery("#eventDetailsForm [name=eventstartdttm]");
                    var eventRepeatOccaranceElm = jQuery("#eventDetailsForm [name=eventrepeatoccarance]");
                    console.log("in view next occarances click");
                    //if(validateEventDetails()){
                    console.log("form valid ");
                    var startDate = eventRepeatStartDateElm.val();
                    var tillDate = eventRepeatTillDateElm.val();
                    var occarance = eventRepeatOccaranceElm.val();
                    console.log(occarance);
                    var count = 10;
                    var recurance = [];
                    switch(occarance){
                        case '0':
                            recurance = calculateNextRecurrances(startDate, tillDate, 1, count);
                            break;
                        case '1':
                            recurance = calculateNextRecurrances(startDate, tillDate, 7, count);
                            break;
                        case '2':
                            recurance = calculateNextRecurrances(startDate, tillDate, 30, count);
                            break;
                    }
                    console.log(recurance);
                    scope.nextRecurances = recurance;
                    scope.$apply();
                    //}
                });

                function calculateNextRecurrances(startDate, endDate, occarance, count){
                    var sdt1 = startDate.split("-");
                    var edt1 = endDate.split("-");
                    var stdt = sdt1[0]+" "+sdt1[1];
                    var edt = edt1[0]+" "+edt1[1];
                    var tillDate = new Date(edt);
                    console.log(stdt+"--"+edt+" -ocr"+occarance+" -count"+count);
                    var recurrances = [];
                    var baseDate = stdt;

                    for(var i=0;i<count;i++){
                        var recur = Utility.addDays(baseDate,occarance);
                        console.log(recur);
                        if(recur < tillDate){
                            var newDate = recur.getMonth()+" "+recur.getDate()+" "+recur.getFullYear()+" "+recur.getHours()+":"+recur.getMinutes()+":"+recur.getSeconds();
                            recurrances.push(newDate);
                        }
                        baseDate = recur;
                    }
                    console.log(recurrances);
                    return recurrances;
                }
                */

                /**
                 * VALIDATE CONTACTS
                 */
                function validateContacts(){
                    var guestList = scope.eventGuestListModel.getGuestList();
                    var guestListElm = jQuery("#eventGuestList");
                    var guestListErrElm = jQuery("#eventGuestListErr");

                    var vl = false;
                    var returnvl = false;
                    if(guestList.length > 0){
                        for(var i=0; i<guestList.length; i++){
                            if(!Utility.validateEmail(guestList[i].email)){
                                i = guestList.length;
                                vl = false;
                            }else{
                                vl = true;
                            }
                        }

                        if(i > 1){//if(vl){
                            guestListErrElm.addClass('hide');
                            returnvl = true;
                        }else if(i == 1 && vl == true){
                            guestListErrElm.addClass('hide');
                            returnvl = true;
                        }else{
                            returnvl = false;
                            guestListErrElm.removeClass('hide');
                            //guestListElm.trigger('click');
                            $('html, body').animate({scrollTop: guestListElm.offset().top -100 }, 'fast');
                        }
                        return returnvl;
                    }else{
                        guestListErrElm.removeClass('hide');
                        //guestListElm.trigger('click');
                        $('html, body').animate({scrollTop: guestListElm.offset().top -100 }, 'fast');
                        return vl;
                    }
                }

                /**
                 * Validate video time line
                 */
                function validateVideoTimeLine(){
                    var videoTimeLine = scope.eventVideoModel.getVideoTimeLineQueue();
                    var videoTimeLineElm = jQuery("#eventVideoTimeLineElm");
                    var videoTimeLineErrElm = jQuery("#eventVideoTimeLineErr");

                    if(videoTimeLine.length > 0){
                        videoTimeLineErrElm.addClass('hide');
                        return true;
                    }else{
                        videoTimeLineErrElm.removeClass('hide');
                        $('html, body').animate({scrollTop: videoTimeLineElm.offset().top -100 }, 'fast');
                        return false;
                    }
                }

            }
        }

    }]);

});