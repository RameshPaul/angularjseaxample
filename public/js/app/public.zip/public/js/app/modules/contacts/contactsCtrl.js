define([
    'angular'
], function(angular){
    var contacts = angular.module("Inwiter.Contacts");
    if(contacts.register != undefined){
        contacts = contacts.register;
    }

    contacts.controller("ContactsCtrl", ['$scope', '$rootScope', '$location', 'ContactsModel', 'GroupsModel', 'ContactsImporterService', '$stateParams', function($scope, $rootScope, $location, Contacts, Groups, ContactsImporterService, $stateParams){
        //Route to this page if it is active
        $scope.isActive = function(route) {
            return route === $location.path();
        };
        $scope.title = "contacts controller loaded";

        //Global variables
        var startItem = 0;
        var contactsQueryLimit = 20;
        var itemsQueried = contactsQueryLimit;
        var itemsFetched = 0;
        var selectedGroup = 0;
        var selectedGroupId = 0;
        var userView = 'all';


        $scope.serverResponse = '';

        var routePrams = $stateParams.view;
        console.log(routePrams);

        $scope.templates = {
            allContacts: {name: 'contactsAllTpl.html', url : '/public/js/app/modules/contacts/contactsAllTpl.html'},
            groups: {name: 'contactsGroupTpl.html', url : '/public/js/app/modules/contacts/contactsGroupTpl.html'}
        };

        if(routePrams == 'all'){
            $scope.templates.contactsTpl = $scope.templates.allContacts;
        }else if(routePrams == 'groups'){
            console.log("groups view");
            $scope.templates.contactsTpl = $scope.templates.groups;
        }else{
            $scope.templates.contactsTpl = $scope.templates.allContacts;
        }


        //SCOPE MODELS
        $scope.contactsList = []; //CONTACTS MODEL
        $scope.groupsList = []; //Groups list model
        $scope.groupContacts = []; //Group contacts model

        $scope.selectedContacts = [];

        //Pagination
        $scope.pagination = {};
        $scope.pagination.enable = false;
        $scope.pagination.currentPage = 0;
        $scope.pagination.pageSize = 3;
        $scope.pagination.numberOfPages=function(){
            var totalPages = Math.ceil($scope.eventsLibrary.length/$scope.pagination.pageSize);
            return totalPages+1;
        };


        /** Initialize contacts **/
        (function(){
            //Get all contacts of the user
            selectedGroupId = 'all';
            getContacts(startItem, contactsQueryLimit);

            //Get all groups of the user
            getGroups();

        })();

        /** IMPORT CONTACTS SECTION **/

        $scope.contactsImportTemplate = {};
        $scope.contactsImportTemplate.url = '/public/js/app/modules/contactsImport/contactsImportTpl.html';//$rootScope.contactsImportTemplate;

        $scope.$on("contactsLoadSucess", function(emails){
           console.log(emails);
            console.log("contacts load success");
        });

        $scope.$on("importContactsEvent", function(emails){
            console.log("import contacts event -- ");
            console.log(emails);
            console.log(ContactsImporterService.getSelectedContacts());
        });

        $scope.$on("contactsLoadError", function(err){
            console.log(err);
            console.log("contacts error");
        });

        $scope.nextPage = function(){
            console.log(itemsQueried);

            if(itemsFetched >= itemsQueried){
                var lnt = $scope.contactsList.length;
                var sLimit = lnt;
                var eLimit = contactsQueryLimit;
                if(selectedGroup === 'all'){
                    getContacts(sLimit, eLimit);
                }else{
                    getGroupContacts(selectedGroupId, sLimit, eLimit);
                }
            }
            return $scope.pagination.currentPage=$scope.pagination.currentPage+1;
        };

        // toggle selection for a given eventId
        $scope.toggleContactsSelection = function toggleSelection(contactId) {
            var idx = $scope.selectedContacts.indexOf(contactId);

            // is currently selected
            if (idx > -1) {
                $scope.selectedContacts.splice(idx, 1);
            }

            // is newly selected
            else {
                $scope.selectedContacts.push(contactId);
            }
            console.log($scope.selectedContacts);
        };

        $scope.showGroupContacts = function(groupId){
            selectedGroupId = groupId;
            var sLimit = startItem;
            var eLimit = contactsQueryLimit;
            getGroupContacts(groupId, sLimit, eLimit);
        };

        /**
         * Create new contact
         * @param newContact {{}}
         */
        $scope.addNewContact = function(newContact){
            createNewContact(newContact);
        };

        /**
         * Remove contacts
         * @param items {string } or {[]}
         */
        $scope.removeContacts = function(items){
            var contactIds = [];
            if(items === undefined){
                contactIds = $scope.selectedContacts;
            }else{
                contactIds.push(items);
            }
            deleteContact(contactIds);
        };

        /**
         * Edit contact
         * @param contact {{}}
         */
        $scope.updateContacts = function(contact){
          editContact(contact);
        };

        $scope.addNewGroup = function(groupName){
            createNewGroup(groupName);
        };

        $scope.removeSelectedGroups = [];

        $scope.removeGroup = function(items){
            var groups = [];
            if(items === undefined){
                groups = removeSelectedGroups;
            }else{
                groups.push(items);
            }
            deleteGroup(items);
        };

        $scope.updateGroup = function(groupData){
            editGroup(groupData);
        };

        $scope.copyToGroup = function(groupId, contacts){
            addToGroup(groupId, contacts);
        };

        function importContact(){

        }

        function errorHandler(error){
            console.log(error);
        }

        /**
         * CONTACTS OPERATION METHODS
         */

        /**
         * Get contacts from server
         * @param startLimit
         * @param endLimit
         */
        function getContacts(startLimit, endLimit){
            var filter = {"intStartLimit":startLimit, "intEndLimit": endLimit};
            Contacts.getContacts(filter).then(function(response){
                if(response.status == 'SUCCESS') {
                    $scope.contactsList = response.data.userContactList;
                }else{
                    errorHandler(response);
                }
            }, errorHandler);
        }

        /**
         * Create new contact mapper
         * @param data
         * @returns {*}
         */
        function prepareCreateContactData(data){
            var createContactStrecture = {"userContact":[],"userGroups":[{"groupName":"","groupID":"","keyDate":""}]};
            var newContact = angular.copy(createContactStrecture);
            var contact = {"firstName":data.firstName,"lastName":data.lastName,"email":data.email,"gender":data.gender,"contactID":""};
            var groups = data.groups;
            newContact.userContact.push(contact);
            newContact.userGroups = groups;
            return newContact;
        }

        /**
         * Create new contact functionality
         * @param newContact
         */
        function createNewContact(newContact){
            var contactData = prepareCreateContactData(newContact);
            Contacts.createContact(contactData).then(function(response){
                $scope.serverResponse = response;
                //Add to the contacts model here $scope.contactsList
                $scope.contactsList.push(contactData.userContact);
            }, errorHandler);
        }

        /**
         * Delete contact from model
         * @param items
         */
        function deleteContact(items){
            var data = {"contactIDList": items};
            Contacts.deleteContents(data).then(function(response){
                $scope.serverResponse = response;
                //Delete from model here $scope.contactsList
                deleteContactSuccess(items);
            },errorHandler);
        }

        function deleteContactSuccess(items){
            var lnt = $scope.contactsList;
            for(var i=0;i<lnt;i++){
                var cid = $scope.contactsList[i].contactID;
                for(var j=0;j<items.length;j++){
                    var qcid = items[i];
                    if(cid == qcid){
                        $scope.contactsList.splice(i,1);
                    }
                }
            }
        }

        /**
         * Prepare edit contact data
         * @param contact {object}
         */
        function prepareEditContactData(contact){
            return {userContact : {"firstName":contact.firstName,"lastName":contact.lastName,"email":contact.email,"gender":contact.gender,"contactID":contact.contactID}};
        }

        /**
         * Edit contact details
         * @param contact
         */
        function editContact(contact){
            var editContactData = prepareEditContactData(contact);
            Contacts.updateContacts(editContactData).then(function(response){
                $scope.serverResponse = response;
                //Update Model here $scope.contactsList
                editContactResponse(editContactData);
            },errorHandler);
        }

        /**
         * Update contact list on edit
         * @param contact
         */
        function editContactResponse(contact){
            var lnt = $scope.contactsList.length;
            var contactId = contact.contactID;
            for(var i=0; i<lnt;i++){
                var cid = $scope.contactsList[i].contactID;
                if(cid === contactId){
                    $scope.contactsList[i].firstName = contact.firstName;
                    $scope.contactsList[i].lastName = contact.lastName;
                    $scope.contactsList[i].gender = contact.gender;
                    $scope.contactsList[i].email = contact.email;
                }
            }
        }

        /**
         * GROUPS OPERATION METHODS
         */
        function getGroups(){
            Groups.getGroups().then(function(response){
                if(response.status.toUpperCase() === 'SUCCESS'){
                    $scope.groupsList = response.data.userGroupsList;
                }else{
                    errorHandler(response);
                }
            }, errorHandler);
        }

        function getGroupContacts(groupId, sLimit, eLimit){
            var filter = {"intStartLimit": sLimit, "intEndLimit": eLimit};
            Groups.getGroupContacts(groupId, filter).then(function(response){
                $scope.serverResponse = response.description;
                if(response.status.toUpperCase() === 'SUCCESS') {
                    if (sLimit === startItem) {
                        $scope.contactsList = getGroupContactsSuccess(response.data.groupContactList);
                    } else {
                        var pcontacts = getGroupContactsSuccess(response.data.groupContactList);
                        for (var i = 0; i < pcontacts.length; i++) {
                            $scope.contactsList.push(pcontacts[i]);
                        }
                    }
                }else{
                    errorHandler(response);
                }
            },errorHandler);
        }

        function getGroupContactsSuccess(data){
            var userContacts = [];
            for(var i=0;i<data.length;i++){
                var cnt = angular.copy(data[i].userContact);
                cnt.keyData = data[i].keyDate;
                cnt.groupID = data[i].groupID;
                userContacts.push(cnt);
            }
            return userContacts;
        }

        function createNewGroup(groupName){
            var data = {userGroup:{"groupName":groupName,"groupID":"","keyDate":""}};
            Groups.createGroup(data).then(function(response){
                $scope.serverResponse = response.description;
                if(response.status.toUpperCase() === 'SUCCESS'){
                    var newGroup = {"groupName":groupName,"groupID":response.data.userGroup.groupID};
                    //Add new group to $scop.groupsList
                    $scope.groupsList.push(newGroup);
                }else{
                    errorHandler(response);
                }
            },errorHandler);
        }

        function deleteGroup(items){
            var data = {"groupIDList":items};
            Groups.deleteGroup(data).then(function(response){
                $scope.serverResponse = response.description;
                if(response.status === 'SUCCESS'){
                    deleteGroupSuccess(items);
                }else{
                    errorHandler(response);
                }
                //Delete from Modle here $scope.groupsList
            },errorHandler);
        }

        function deleteGroupSuccess(data){
            var lnt = $scope.groupsList.length;
            for(var i=0;i<lnt;i++){
                var gid = $scope.groupsList[i].groupID;
                for(var j=0;j<data.length;j++){
                    if(gid === data[j]){
                        $scope.groupsList.splice(i,1);
                    }
                }
            }
        }

        function editGroup(groupData){
            var data = {userGroup:{"groupName":groupData.groupName,"groupID":groupData.groupID,"keyDate":""}};
            Groups.updateGroup(data).then(function(response){
                $scope.serverResponse = response;
                if(response.status.toUpperCase() === 'SUCCESS'){
                    editGroupSuccess(response.data.groupdData);
                }else{
                    errorHandler(response);
                }
                //Update model here $scope.groupsList
            },errorHandler)
        }

        function editGroupSuccess(data){
            var lnt = $scope.groupsList.length;
            for(var i=0; i<lnt;i++){
                var gid = $scope.groupsList[i].groupID;
                if(gid === data.groupID){
                    $scope.groupsList[i].groupName = data.groupName;
                }
            }
        }

        function prepareAddToGroupData(groupId, contacts){
            var userContats = [];
            var groups = [];
            var jsonObject = {"userContact":[{"firstName":"","lastName":"","email":"","gender":"","contactID":""}],"userGroups":[{"groupName":"","groupID":"","keyDate":""}]}
            for(var i=0; i<contacts.length;i++){
                var ecnt = angular.copy(jsonObject.userContact[0]);
                ecnt.firstName = contacts[i].firstName;
                ecnt.lastName = contacts[i].lastName;
                ecnt.email = contacts[i].email;
                ecnt.gender = contacts[i].gender;
                ecnt.contactID = contacts[i].contactID;
                userContats.push(ecnt);
            }
            var grp = angular.copy(jsonObject.userGroups[0]);
                grp.groupID = groupId;
            groups.push(grp);
            return {"userContact":userContats,"userGroups":groups};
        }

        function addToGroup(groupId, contacts){
            var data = prepareAddToGroupData(groupId, contacts);
            Groups.addGroupContacts(groupId, data).then(function(response){
                $scope.serverResponse = response.description;
                if(response.status === 'SUCCESS'){
                    //Update model here $scope.contactsList

                }else{
                    errorHandler(data);
                }
            }, errorHandler);
        }
    }]);

    contacts.filter('startFrom', function() {
        return function(input, start) {
            start = +start; //parse to int
            return input.slice(start);
        }
    });

});