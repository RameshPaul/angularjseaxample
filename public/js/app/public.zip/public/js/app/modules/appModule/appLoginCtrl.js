define([
        'angular'
    ],
    function (angular) {

        angular.module('Inwiter')

            .controller('AppLoginCtrl', ['$scope', '$rootScope', 'Restangular', 'AuthService', 'UserService', 'LocalStorageService', function ($scope, $rootScope, Restangular, Auth, Users, LocalStorage, $routeProvider ,$route) {

                console.log($routeProvider);
                console.log(LocalStorage.get('_inwiterAppUser'));
                /**
                 * Initiate
                 *
                 */
                function init(){

                }

            }]);

    });