define([
    'angular'
], function(angular){
    var contacts = angular.module("Inwiter.Contacts");
    if(contacts.register != undefined){
        contacts = contacts.register;
    }
    contacts.factory("GroupsModel", ['ContactsService', function(ContactsService){
        var groups = [];

        var groupsModel = {};
        groupsModel = {
            createGroup: function(groupName){
                return ContactsService.createGroup().customPUT(groupName);
            },
            deleteGroup: function(data){
                return ContactsService.deleteGroup().remove(data);
            },
            renameGroup: function(groupId, data){
                return ContactsService.renameGroup(groupId).post(data);
            },
            getGroups: function(){
              return ContactsService.getGroups().get();
            },
            getGroupContacts: function(groupId, filter){
                return ContactsService.getGroupContacts(groupId).get(filter);
            },
            addGroupContacts: function(groupId, data){
                return ContactsService.addGroupContacts(groupId).customPUT(data);
            }

        };
        return groupsModel;
    }]);
});