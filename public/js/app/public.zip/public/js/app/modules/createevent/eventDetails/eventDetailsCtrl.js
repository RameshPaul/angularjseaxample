define([
    'angular'
],
function (angular) {
    var eventDetails = angular.module('Inwiter.CreateEvent.EventDetails');
    console.log(eventDetails.register);
    eventDetails.controller('EventDetailsCtrl',['$scope', '$location', '$rootScope', 'UserModel', 'LazyLoadService', 'EventDetailsService', '$sce', 'UtilityService', '$filter', 'ContactsService', '$timeout', 'CreateEventModel', 'EventDetailsModel', function($scope, $location, $rootScope, UserModel, LazyLoad, EventDetailsService, $sce, Utility, $filter, ContactsService, $timeout, CreateEventModel, EventDetailsModel){

        $scope.userId = $rootScope.userModel.userID;
        $scope.userType = $rootScope.userModel.userType;
        $scope.userStatus = $rootScope.userModel.userStatus;
        $scope.planExpired = $rootScope.userModel.planExpired;
        $scope.maxDays = 60;

        $scope.userGroups = [];

        console.log($scope.userType);
        console.log("in event details controller");
        /**
         *  EDIT EVENT OR COPY EVENT
         */


        //var $datePicker = $injector.get('ui.bootstrap.datetimepicker');
        //$scope.eventDetails = angular.copy(EventDetailsModel.getEventDetails());

        $scope.name = "event anme";
        //vew model

        /** ng views **/
        $scope.eventDetails = {eventCategory:"", eventDescription: "", eventEndDate: "", eventEndTime: "", eventLocation: "", eventName: "", eventStartDate: "", eventStartTime: "", needRsvp: 1};
        $scope.myReplyOptions = {};//{hideComments:"0", hideGuestList:"0", knowMeOnGuestsComment:"", knowMeOnGuestsRsvp:"", knowMeOnGuestsView:"", reminderEnable: ""};
        $scope.guestReplyOptions = {};//{kidsNumber:"", remindEvent:"", totalGuestsLimit:""};
        $scope.schedulingOption = {'timeZone': '-05:00_Eastern Time [US & Canada]'};
        $scope.eventRecursion = {};
        $scope.nextRecurances = [];
        $scope.eventCategoriesList = [];
        $scope.showEventSettings = false;
        $scope.needRSVPWatcher = $scope.eventDetails.needRsvp;

        $scope.eventTextEditorText = '';

        $rootScope.totalEventDetails = {
                                        "eventDetails": $scope.eventDetails,
                                        "myReplyOptions": $scope.myReplyOptions,
                                        "guestReplyOptions": $scope.guestReplyOptions,
                                        "schedulingOption": $scope.schedulingOption,
                                        "eventRecursion": $scope.eventRecursion
                                       };

        $scope.needRsvpEvent = function(rsvpOption, value){
            var rsvp = rsvpOption.toString();
          console.log(rsvp);
            var type = 'invitation';
            if(rsvp === '0'){
                type = 'greeting';
                if($rootScope.userGroups.length > 0){
                    $scope.userGroups = angular.copy($rootScope.userGroups)
                }else{
                    getGroups();
                }
            }
            getEventCategories(type, value);
        };

        //$scope.needRsvpEvent('1');

        /**
         * Toggle event settings
         */
        $scope.toggleEventSettings = function(){
            $scope.showEventSettings = $scope.showEventSettings === false ? true: false;
        };

        $scope.eventDescriptionDone = function(){
            $scope.eventTextEditorText = $sce.trustAsHtml($scope.eventDetails.eventDescription);
        };

        $scope.getTimeStampToDate = function(timestamp){
            var dt = new Date(timestamp);
            console.log("timestamp to date c"+dt);
            return dt.getDate()+"-"+(dt.getMonth()+1)+"-"+dt.getFullYear();
        };

        $scope.getTimeStampToTime = function(timestamp){
            //var dt = new Date(timestamp);
            //return dt.getHours()+":"+dt.getMinutes();
            return Utility.time24TOAMPM(timestamp);
        };

        /**
         * REPEAT OPTION MANAGEMENT
         * @type {{}}
         */
        $scope.repeatOption = {};
        $scope.repeatOption.occarances = [
                                            {value:'0', text: 'daily', show: true},
                                            {value:'1', text: 'Weekly', show: true},
                                            {value:'2', text: 'Monthly', show: true},
                                            {value:'3', text: 'Yearly', show: true}
                                         ];
        $scope.repeatOption.tillDateError = false;

        $scope.repeatOption.tillDateChange = function(tillDateVal, startDateVal){
            console.log("till date change");
            var fTillDateVal = new Date(tillDateVal);
            var fStartDateVal = new Date(startDateVal);

            console.log(tillDateVal+"--"+startDateVal);
            var utcTillDate = new Date(Utility.convertLocalToUTCDate(fTillDateVal));
            var utcStartDate = new Date(Utility.convertLocalToUTCDate(fStartDateVal));
            console.log(utcStartDate+"=="+utcTillDate);

            if(utcTillDate <= utcStartDate){
                console.log("In if");
                //console.log(eventRepeatTillDateErrorElm);
                $scope.repeatOption.tillDateError = true;
                return false;
            }else{
                $scope.repeatOption.tillDateError = false;
                var dateDiff = parseInt(Utility.getDateDiff(utcStartDate, utcTillDate));
                console.log("Date diff:-"+dateDiff);
                if(dateDiff <= 7){
                    manageRepeatOccationOption(['0']);
                }else if((dateDiff > 7) && (dateDiff <= 30)){
                    manageRepeatOccationOption(['0','1']);
                }else if((dateDiff > 30) && (dateDiff <= 365)){
                    manageRepeatOccationOption(['0','1','2']);
                }else if(dateDiff > 365){
                    manageRepeatOccationOption(['0','1','2','3']);
                }else{
                    manageRepeatOccationOption([]);
                }
            }
        };

        function manageRepeatOccationOption(values){
            var lnt = $scope.repeatOption.occarances.length;
            var obj = $scope.repeatOption.occarances;
            for(var k=0; k<lnt; k++){
                $scope.repeatOption.occarances[k].show = false;
            }

            for(var i=0; i<values.length; i++){
                var val = values[i];
                for(var j=0; j<lnt; j++){
                    if(val == obj[j].value){
                        $scope.repeatOption.occarances[j].show = true;
                    }
                }

            }
        }

        $scope.repeatOption.nextOccarances = function(startDate, tillDate, occarance){
            //var eventRepeatTillDateElm = jQuery("#eventDetailsForm [name=eventrepeattilldate]");
            //var eventRepeatStartDateElm = jQuery("#eventDetailsForm [name=eventstartdttm]");
            //var eventRepeatOccaranceElm = jQuery("#eventDetailsForm [name=eventrepeatoccarance]");
            console.log("in view next occarances click");
            //if(validateEventDetails()){
            console.log("form valid ");
            //var startDate = eventRepeatStartDateElm.val();
            //var tillDate = eventRepeatTillDateElm.val();
            //var occarance = eventRepeatOccaranceElm.val();
            console.log(occarance);
            var count = 10;
            var recurance = [];
            startDate = Utility.fullDate(startDate);
            tillDate = Utility.fullDate(tillDate);
            console.log(startDate, tillDate, "occarance-", occarance);
            switch(occarance){
                case '0':
                    recurance = calculateNextRecurrances(startDate, tillDate, 1, count);
                    break;
                case '1':
                    recurance = calculateNextRecurrances(startDate, tillDate, 7, count);
                    break;
                case '2':
                    recurance = calculateNextRecurrances(startDate, tillDate, 30, count);
                    break;
            }
            console.log(recurance);
            $scope.nextRecurances = recurance;
        };

        function calculateNextRecurrances(startDate, endDate, occarance, count){
            var sdt1 = startDate.split("-");
            var edt1 = endDate.split("-");
            var stdt = sdt1[1]+" "+sdt1[2]+" "+sdt1[0];
            var edt = edt1[1]+" "+edt1[2]+" "+edt1[0];
            var tillDate = new Date(edt);
            console.log(stdt+"--"+edt+" -ocr "+occarance+" -count "+count);
            var recurrances = [];
            var baseDate = stdt;

            for(var i=0;i<count;i++){
                var recur = Utility.addDays(baseDate,occarance);
                console.log(recur);
                if(recur < tillDate){
                    //var newDate = recur.getMonth()+" "+recur.getDate()+" "+recur.getFullYear();//+" "+recur.getHours()+":"+recur.getMinutes()+":"+recur.getSeconds();
                    var newDate = recur;//new Date(newDate);
                    recurrances.push(newDate.getTime());
                }
                baseDate = recur;
            }
            console.log(recurrances);
            return recurrances;
        }

        /**
         * Event repeat Non event functionality
         */
        function getGroups(){
            ContactsService.getGroups().customGET().then(function(response){
                console.log(response);
                if(response.status.toUpperCase() === 'SUCCESS'){
                    if(response.data.userGroups.length > 0) {
                        $scope.userGroups = response.data.userGroups;
                    }else{
                    }
                }
            }, function(response){
                console.log(response);
            });
        }

        $scope.groups = {};
        $scope.groups.selectedGroupName = '';
        $scope.groups.selectedGroupID = '';
        $scope.groups.groupSelectionError = false;

        $scope.onGroupSelection = function(groupID, groupName){
            console.log($scope.eventRecursion.group);
            $scope.groups.groupSelectionError = false;
            console.log("group changed ", groupID);
            if(groupID != "") {
                ContactsService.getGroupContacts(groupID).get().then(function (response) {
                    console.log(response.data);
                    if (response.status.toUpperCase() == 'SUCCESS') {
                        var contacts = response.data.groupContacts;
                        groupSelectionResponse(contacts, groupID, groupName);
                    }
                }, function () {

                });
            }
        };

        function groupSelectionResponse(contacts, groupID, groupName){
            var lnt = contacts.length;
            console.log("group selection reponse", contacts);
            if(lnt <= 0){
                console.log("group selection error");
                $scope.groups.groupSelectionError = true;
                //$timeout(function(){
                //    $scope.groups.groupSelectionError = false;
                //}, 5000);
            }else{
                $scope.groups.selectedGroupName = groupName;
                $scope.groups.selectedGroupID = groupID;
            }
        }


        function loadDefaults(){

        }

        function resetEventDetails(){

        }

        function validateModel(){

        }

        function LocationAutoFill(){

        }

        function getEventCategories(type, value){
            var filter = {"categoryType":type};
            EventDetailsService.getEventCategories().get(filter).then(function(response){
                console.log(response);
                $scope.eventCategoriesList = response.data;
                console.log("set value", value);
                $timeout(function(){
                    $scope.eventDetails.eventCategory = value;
                },100);
            });
        }

        function getUTCEquivalentDate(currentDate){
            EventDetailsService.getUTCEquivalentDate().getList().then(function(response){
                console.log(response);
            });
        }


        /**
         * SET DEFAULT VALUE
         */
        function setEventDetailsDefaults(){

        }

        /**
         * UPDATE EDIT EVENT
         */
        if($rootScope.isEdit){
            updateEditEventData();
        }else{
            updateDefaultEventData();
        }

        function updateEditEventData(){
            var eventDetails = CreateEventModel.getEventDetails();
            var eventSettings = CreateEventModel.getEventSettings();
            var scheduleInfo = CreateEventModel.getEventScheduleInfo();
            var data = {eventDetails: eventDetails, eventSettings: eventSettings, scheduleInfo: scheduleInfo};
            EventDetailsModel.setEventDetails(data);

            //SET SCOPE MODEL FOR TEMPLATE
            var eventData = EventDetailsModel.getEventDetails();
            $scope.eventDetails = angular.copy(eventData.eventDetails);
            $scope.myReplyOptions = angular.copy(eventData.myReplyOptions);
            $scope.guestReplyOptions = angular.copy(eventData.guestReplyOptions);
            $scope.schedulingOption = angular.copy(eventData.schedulingOption);
            $scope.eventRecursion = angular.copy(eventData.eventRecursion);
            console.log("event details model", eventData);
            updateEventDetailsTemplate(eventData);
        }

        function updateEventDetailsTemplate(eventData){
            console.log(typeof $scope.eventDetails.needRsvp);
            //SET RSVP Option
            if($scope.eventDetails.needRsvp){
                $scope.eventDetails.needRsvpYes = true;
                $scope.eventDetails.needRsvpNo = false;
            }else{
                $scope.eventDetails.needRsvpNo = true;
                $scope.eventDetails.needRsvpYes = false;
            }

            //SET EVENT CATEGORY
            $scope.needRsvpEvent($scope.eventDetails.needRsvp, eventData.eventDetails.eventCategory);

            //SET START TIME
            var startTime = new Date(eventData.eventDetails.eventStartDate+" "+eventData.eventDetails.eventStartTime);
            $scope.eventDetails.eventStartTime = startTime.getTime();

            //SET END TIME
            if(eventData.eventDetails.eventEndTime != "00:00:00"){
                var endTime = new Date(eventData.eventDetails.eventEndDate+" "+eventData.eventDetails.eventEndTime);
                $scope.eventDetails.eventEndTime = endTime.getTime();
            }

            //SET DESCRIPTION
            console.log(eventData.eventDetails.eventDescription);
            $scope.eventTextEditorText = $sce.trustAsHtml(eventData.eventDetails.eventDescription);

            //SET SCHEDULING OPTIONS
            if(eventData.schedulingOption.schedule == '1'){
                $scope.schedulingOption.scheduleSend = true;
                $scope.schedulingOption.scheduleSpecific = false;
                $scope.schedulingOption.scheduleRepeat = false;
            }

            if(eventData.schedulingOption.schedule == '2'){
                $scope.schedulingOption.scheduleSend = false;
                $scope.schedulingOption.scheduleSpecific = true;
                $scope.schedulingOption.scheduleRepeat = false;
            }

            if(eventData.schedulingOption.schedule == '3'){
                $scope.schedulingOption.scheduleSend = false;
                $scope.schedulingOption.scheduleSpecific = false;
                $scope.schedulingOption.scheduleRepeat = true;
            }


            console.log("scheduling option-", $scope.schedulingOption);
        }


        function updateDefaultEventData(){
            console.log("in default event data");
            //SET RSVP Option
            $scope.eventDetails.needRsvp = 1;
            $scope.eventDetails.needRsvpYes = true;
            $scope.eventDetails.needRsvpNo = false;
            $scope.needRsvpEvent($scope.eventDetails.needRsvp);

            var dt = new Date();
            //SET EVENT START DATE
            $scope.eventDetails.eventStartDate = dt.getDate()+"-"+dt.getMonth+"-"+dt.getFullYear();

            //SET EVENT START TIME
            $scope.eventDetails.eventStartDate = dt.getTime();

            //SET USER TIMEZONE
            var timeZoneOffSet = Utility.getTimeZoneOffSet();
            $scope.schedulingOption.timeZone = Utility.getDefaultTimeZone(timeZoneOffSet);

            //SET SCHEDULING OPTION
            $scope.schedulingOption.scheduleSend = true;
            $scope.schedulingOption.scheduleSpecific = false;
            $scope.schedulingOption.scheduleRepeat = false;

        }
    }]);

});