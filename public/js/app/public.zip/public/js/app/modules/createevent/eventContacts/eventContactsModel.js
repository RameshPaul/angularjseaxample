define([
        'angular'
    ],
    function (angular) {
        var eventContacts = angular.module('Inwiter.CreateEvent.EventContacts');
        eventContacts.factory('EventGuestListModel',['UserModel', 'UtilityService', function(User, Utility){
            //Model
            var contactsModel = [
                                    {"email": '', "name":'',"addRemove":true, "valid": true}
                                ];
            return {
                getGuestList: function(){
                    return contactsModel;
                },
                setGuestList: function(contacts){
                    contactsModel = angular.copy(contacts);
                },
                addNewGuest: function(data){
                    var tmp = {"email": data.email, "name":data.name,"addRemove":true, "valid": true};
                    var pos = contactsModel.push(tmp);
                    return pos;
                },
                removeGuest: function(position){
                    var pos = contactsModel.splice(position,1);
                    return pos;
                },
                emailsCount: function(){
                    var count = 0;
                    for(var i=0; i<contactsModel.length; i++){
                        var obj = contactsModel[i];
                        console.log(obj.email, contactsModel[i]);
                        if(Utility.validateEmail(obj.email)){
                            count = count+1;
                        }
                    }
                    console.log(count);
                    return count;
                },
                removeDuplicates: function(data){
                    return data;
                }
            };
        }]);
    });