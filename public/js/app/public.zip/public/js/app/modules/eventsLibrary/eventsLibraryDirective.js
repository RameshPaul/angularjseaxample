define([
    'angular'
],
function(angular){
    var eventsLibrary = angular.module("Inwiter.EventsLibrary");
    if(eventsLibrary.register != undefined){
        eventsLibrary = eventsLibrary.register;
    }
    eventsLibrary.directive("eventsLibraryLoadMore", [function(){
        return{
            restrict: 'A',
            link: function(scope, element, attrs){
                element.unbind("click");
                element.bind("click", function(event){
                    console.log("in loadmore click");
                    scope.nextPage();
                    scope.$apply();
                });
            }
        }
    }]);
});