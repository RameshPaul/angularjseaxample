define([
        'angular'
        //'angularFileUpload',
        //'timer'
],

function (angular) {
    var eventVideo = angular.module('Inwiter.CreateEvent.EventVideo', ['angularFileUpload']);
    console.log("event video module---",eventVideo);
    return eventVideo;
});
