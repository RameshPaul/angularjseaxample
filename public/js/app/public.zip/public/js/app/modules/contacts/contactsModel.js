define([
    'angular'
], function(angular){
    var contacts = angular.module("Inwiter.Contacts");
    if(contacts.register != undefined){
        contacts = contacts.register;
    }
    contacts.factory("ContactsModel", ['ContactsService', function(ContactsService){
        var contacts = [];
        var model = {};
        model = {
            createContact: function(data){
                return ContactsService.createContacts().customPUT(data);
            },
            getContacts: function(filter){
                console.log(ContactsService.getContacts());
                return ContactsService.getContacts().get(filter);
            },
            updateContacts: function(data){
                return ContactsService.updateContacts().post(data);
            },
            deleteContacts: function(data){
                return ContactsService.deleteContacts().remove(data);
            }
        };
        return model;
    }]);
});