define([
    'angular'
],
function (angular) {

var inwiterApp = angular.module('Inwiter.CreateEvent');
    if(inwiterApp.register != undefined){
        inwiterApp = inwiterApp.register;
    }

    inwiterApp.factory('CreateEventModel', ['UserModel', 'UtilityService', function (UserModel, Utility) {
            var eventJSONModel = {"eventDetails":{"userID":100098,"eventID":"","enableRSVP":"","scheduledOption":"","eventEndDate":"","eventEndTime":"","eventScheduledDate":"","eventScheduledTime":"","eventStartDate":"","eventStartTime":"","Browser":"","eventCategory":"","eventDescription":"","appType":"","eventGuestThemeURL":"","eventHostEmail":"","eventHostName":"","languageCode":"","eventStatus":"","eventTimezoneOffset":"","eventTitle":"","eventType":"1","eventVenue":"","videoFileURL":"","videoThumbURL":"","eventJobDefinitionId":""},"eventSettings":{"totalGuests":2,"kidsAllowed":"","guestListHidden":"","commentsHidden":"","notifyOnRSVP":"","notifyOnComment":"","notifyOnGuestView":""},"eventReminder":{"enable":"","reminderTime":"","reminderDate":""},"eventGuestList":[],"scheduledInfo":{"recurrentFrequency":"","recurrentSendBeforeInDays":"","recurrentReminderInDays":"","recurrentDescription":"","recurrentGroupID":"","recurrentTillDate":""},"videoTimeline":{"type":"","upload":{"file":""},"create":{}}};
            console.log("Create Event Model ", UserModel.getUser());

            var userModel = UserModel.getUser();

            function formEventJSON(data){

                /** CALCULATE CONVERTIONS  **/
                console.log(data);
                var eventStartDate = Utility.fullDate(data.eventDetails.eventStartDate);
                console.log(data.eventDetails.eventStartTime);
                console.log(Utility.fullTime24(data.eventDetails.eventStartTime));
                var eventStartTime = Utility.fullTime24(data.eventDetails.eventStartTime);
                console.log(data.eventDetails.eventEndDate);

                var eventEndDate = Utility.fullDate(data.eventDetails.eventEndDate);
                if(eventEndDate == "NaN-NaN-NaN"){
                    eventEndDate = "";
                }

                var eventEndTime = Utility.fullTime24(data.eventDetails.eventEndTime);
                console.log(Utility.fullTime24(data.eventDetails.eventEndTime));
                if(eventEndTime == "NaN:NaN:NaN") {
                    eventEndTime = "";
                }
                var scheduleOption = Utility.checkObjectKey(data.schedulingOption, 'schedule', '');
                var eventScheduleDate = '';
                var eventScheduleTime = "00:00";
                if(scheduleOption === '2'){
                    eventScheduleDate = Utility.fullDate(data.schedulingOption.scheduleDate);
                }else{
                    eventScheduleDate = eventStartDate;
                }

                var eventTimezone = data.schedulingOption.timeZone;

                //var notifyGuestView = "0";
                //if(data.eventDetails.needRsvp != '1'){
                //    notifyGuestView = Utility.checkObjectKey(data.myReplyOptions.knowMeOnGuestsView;
                //}

                var schedulingOptionFlag = Utility.checkObjectKey(data.schedulingOption, 'schedule', '');
                var needRsvp = data.eventDetails.needRsvp;
                if(schedulingOptionFlag === '3' && needRsvp === '0'){
                    schedulingOptionFlag = '4';
                }

                var eventStatus = 'DR';
                if(data.eventStatus == 'create') {
                    if (schedulingOptionFlag == '1') {
                        eventStatus = 'SB';
                    } else if (schedulingOptionFlag == '2' || schedulingOptionFlag == '3' || schedulingOptionFlag == '4') {
                        eventStatus = 'SH';
                    } else {
                        eventStatus = 'DR';
                    }
                }

                var recursionTillDate = "";
                if(data.eventRecursion.endDate != ''){
                    recursionTillDate = Utility.fullDate(data.eventRecursion.endDate);
                }

                var eventType = '1';
                if(data.eventDetails.needRsvp == '1'){
                    eventType = '1';
                }else{
                    eventType = '2';
                }

                var videoFile = '',
                    videoThumb = '';
                if(data.videoTimeline != undefined){
                    videoFile = data.videoTimeline.src;
                    videoThumb = data.videoTimeline.thumbLarge;
                }

                var eventData =  angular.copy(eventJSONModel);
                    eventData.eventDetails.userID = userModel.userID;
                    eventData.eventDetails.eventID = data.eventID;
                    eventData.eventDetails.enableRSVP = data.eventDetails.needRsvp; //YES (1), NO (0)
                    eventData.eventDetails.scheduledOption = schedulingOptionFlag; //SEND NOW (1), SCHEDULE(2), REPEAT WITH NEED RSVP 1 (3), REPEAT WITH NEED RSVP 0 (4)
                    eventData.eventDetails.eventEndDate = eventEndDate;
                    eventData.eventDetails.eventEndTime = eventEndTime;
                    eventData.eventDetails.eventScheduledDate = eventScheduleDate;
                    eventData.eventDetails.eventScheduledTime = eventScheduleTime;
                    eventData.eventDetails.eventStartDate = eventStartDate;
                    eventData.eventDetails.eventStartTime = eventStartTime;
                    eventData.eventDetails.Browser = Utility.getBrowser()+"/"+Utility.getDeviceType();
                    eventData.eventDetails.eventCategory = data.eventDetails.eventCategory;
                    eventData.eventDetails.eventDescription = escape(Utility.checkObjectKey(data.eventDetails, 'eventDescription', ''));
                    eventData.eventDetails.appType = "0"; //FOR WEBSITE 0
                    eventData.eventDetails.eventGuestThemeURL = data.background.src; //GUEST BACKGROUND PAGE URL
                    eventData.eventDetails.eventHostEmail = userModel.userEmail;
                    eventData.eventDetails.eventHostName = userModel.userName;
                    eventData.eventDetails.languageCode = "en"; //USER LANGUAGE CODE (en)
                    eventData.eventDetails.eventStatus = eventStatus; //SAVE DRAFT (DR), CREATE EVENT (SB) WHEN EVENT SCHEDULE IS SEND NOW, CREATE EVENT (SH) WHEN EVENT SCHEDULE IS SCHEDULE OR REPEAT
                    eventData.eventDetails.eventTimezoneOffset = eventTimezone; //TIME ZONE +05:30
                    eventData.eventDetails.eventTitle = data.eventDetails.eventName;
                    eventData.eventDetails.eventType = eventType; //INVITATION (1) OR GREETING (2)
                    eventData.eventDetails.eventVenue = Utility.checkObjectKey(data.eventDetails, 'eventLocation', '');
                    eventData.eventDetails.videoFileURL = videoFile;
                    eventData.eventDetails.videoThumbURL = videoThumb;
                    eventData.eventDetails.eventJobDefinitionId = "";
                    eventData.eventDetails.RSVPEmail = userModel.rsvpEmailID;
                    eventData.eventDetails.hashTag = "";
                    eventData.eventDetails.DBA = userModel.businessDBA;
                    eventData.eventDetails.eventJobRequestID = "";
                    eventData.eventDetails.userType = userModel.userType;
                    eventData.eventDetails.personalizedURL = userModel.personalizedURL;

                    eventData.eventSettings.totalGuests = Utility.checkObjectKey(data.guestReplyOptions, 'totalGuestsLimit', '0');
                    eventData.eventSettings.kidsAllowed = Utility.checkObjectKey(data.guestReplyOptions, 'kidsNumber', '0', '1');
                    eventData.eventSettings.guestListHidden = Utility.checkObjectKey(data.myReplyOptions, 'hideGuestList', '0', '1');
                    eventData.eventSettings.commentsHidden = Utility.checkObjectKey(data.myReplyOptions, 'hideComments', '0', '1');
                    eventData.eventSettings.notifyOnRSVP = Utility.checkObjectKey(data.myReplyOptions, 'knowMeOnGuestsRsvp', '0', '1');
                    eventData.eventSettings.notifyOnComment = Utility.checkObjectKey(data.myReplyOptions, 'knowMeOnGuestsComment', '0', '1');
                    eventData.eventSettings.notifyOnGuestView = Utility.checkObjectKey(data.myReplyOptions, 'knowMeOnGuestsView', '0', '1');
                    eventData.eventSettings.reminderEnable = Utility.checkObjectKey(data.myReplyOptions, 'reminderEnable', '0', '1');

                    eventData.eventReminder.enable = Utility.checkObjectKey(data.guestReplyOptions, 'remindEvent', '0');
                    eventData.eventReminder.reminderTime = eventStartTime;
                    eventData.eventReminder.reminderDate = eventStartDate;
                    eventData.eventReminder.reminderStatus = "";

                    eventData.eventGuestList = data.guestList;

                    //if(data.schedulingOption.schedule === '2') {
                        eventData.scheduledInfo.recurrentFrequency = Utility.checkObjectKey(data.eventRecursion, 'occation', ''); //REPEAT ON OCCURRENCE - DAILY (1), WEEKLY (2), MONTHLY (3)
                        eventData.scheduledInfo.recurrentSendBeforeInDays = Utility.checkObjectKey(data.eventRecursion, 'sendon', ''); //REPEAT SEND ON - ONE DAY BEFORE (1), TWO DAYS BEFORE (2) INT
                        eventData.scheduledInfo.recurrentReminderInDays = ""; //
                        eventData.scheduledInfo.recurrentDescription = ""; //
                        eventData.scheduledInfo.recurrentGroupID = Utility.checkObjectKey(data.eventRecursion, 'group', ''); //GROUPID OF SELECTED GROUP
                        eventData.scheduledInfo.recurrentTillDate = recursionTillDate;
                    //}
                    eventData.videoTimeline.type = "";
                    eventData.videoTimeline.upload = {"file": ""};
                    eventData.videoTimeline.create = {};

                    eventData.eventCreationType = data.eventStatus;
                return eventData;
            }

            var eventModel = {
                                'eventDetails': {},
                                'eventSettings': {},
                                'eventReminder': {},
                                'eventGuestList': {},
                                'scheduledInfo': {},
                                'videoTimeline': {}
                             };
            return{
                 setEventDetails: function(eventDetails){
                    eventModel.eventDetails = angular.copy(eventDetails);
                 },
                setEventSettings: function(eventSettings){
                    eventModel.eventSettings = eventSettings;
                },
                setEventScheduleInfo: function(scheduleInfo){
                    eventModel.scheduledInfo = scheduleInfo;
                },
                setEventContacts: function(contactList){
                    eventModel.eventContacts = angular.copy(contactList);
                },
                setEventVideo: function(eventVideo){
                    eventModel.eventVideo = angular.copy(eventVideo);
                },
                getEventModel: function(){
                    return eventModel;
                },
                getEventDetails: function(){
                    return eventModel.eventDetails;
                },
                getEventSettings: function(){
                    return eventModel.eventSettings;
                },
                getEventScheduleInfo: function(){
                  return eventModel.scheduledInfo;
                },
                getEventContacts: function(){
                    return eventModel.eventGuestList;
                },
                getEventVideo: function(){
                    return eventModel.videoTimeline;
                },
                formJSON: function(data){
                    //Form JSON According to server needed
                    return formEventJSON(data);
                }
             }
        }]);

});