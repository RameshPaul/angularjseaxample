define([
    'angular'
],
function(angular){
    var eventVideo  = angular.module("Inwiter.CreateEvent.EventVideo");
    eventVideo.factory("EventVideoModel",[function(){
        var videoTimeLine = [];
        var videoQueue = {
            addItem: function(item){
                var pos = videoTimeLine.push(item);
                return pos;
            },
            removeItem: function(index){
                var pos = videoTimeLine.splice(index, 1);
                return pos;
            },
            getVideoTimeLineQueue: function(){
                return videoTimeLine;
            },
            setVideoTimeLineQueue: function(data){
                videoTimeLine = angular.copy(data);
            },
            clearQueue: function(){
                videoTimeLine = [];
            }
        };

        return videoQueue;
    }]);
});