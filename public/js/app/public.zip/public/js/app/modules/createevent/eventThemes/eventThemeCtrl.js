define(['angular'], function(angular){
    var eventTheme = angular.module('Inwiter.CreateEvent.EventTheme');

    eventTheme.controller("EventThemeCtrl", ['$scope', '$rootScope', 'EventThemeService', 'EventThemeModel', '$fileUploader', 'AuthService', 'uploadModuleURL', 'UtilityService', '$timeout', function($scope, $rootScope, EventThemeService, EventThemeModel, $fileUploader, Auth, uploadModuleURL, Utility, $timeout){

        //GLOBALS

        //MODALS
        $scope.backgroundsList = [];
        $scope.uploadBackgound = {};
        $scope.uploadBackgound.show = false;
        $scope.uploadBackgound.isUploaded = false;
        $scope.uploadBackgound.isCanceled = false;
        $scope.uploadBackgound.isError = false;
        $scope.uploadBackgound.Error = '';


        //Get backgrounds from server
        $scope.getThemes = function() {
            var filter = {userType: $rootScope.userType};
            EventThemeService.getBackgrounds().get(filter).then(function (response) {
                var res = response;
                console.log("bacground themes", res);
                if (res.status.toUpperCase() === 'SUCCESS') {
                    $scope.backgroundsList = res.data;
                    setDefaultBackground();
                } else {
                    errorHandler(res);
                }
            }, errorHandler);
        };
        $scope.getThemes();

        function errorHandler(res){
            console.log(res);
            $scope.uploadBackgound.Error = res.description;
            $scope.uploadBackgound.isError = true;
        }

        //update selected background
        $scope.updateSelectedBackground = function(index){
            //console.log("in update background");
            resetSelectedBackground();
            $scope.backgroundsList[index].selected = 1;
            //console.log($scope.backgroundsList);
            EventThemeModel.setEventBackgroundTheme($scope.backgroundsList[index]);
        };

        function resetSelectedBackground(){
          hideErrors();
          var lnt = $scope.backgroundsList.length;
            for(var i=0; i<lnt; i++){
                $scope.backgroundsList[i].selected = 0;
            }
        }


        /**
         * Upload Theme functionality
         */
        var uploader;
        $scope.uploader;

        (function(){
            // create a uploader with options
            uploader = $scope.uploader = $fileUploader.create({
                scope: $scope,                          // to automatically update the html. Default: $rootScope
                headers: Auth.getHeaders(),
                //method: 'PUT',
                url: uploadModuleURL.apiPrefix+'user/'+Auth.currentUserId()+uploadModuleURL.uploadVideo,
                autoUpload: true,
                formData: [
                    {'uploadType': 'backGround' }
                ],
                filters: [
                    function (item) {                    // first user filter
                        console.log(item);
                        var vli = Utility.validateImage(item);
                        return vli.val;
                        //return true;
                    }
                ]
            });

            //AFTER ADDING FILE
            uploader.bind('afteraddingfile', function (event, item) {
                $scope.uploadBackgound.show = true;
               // console.info('After adding a file', item);
                $scope.progressBarClass = '';
            });

            //WHEN ADDING FAILED
            uploader.bind('whenaddingfilefailed', function (event, item) {
                console.info('When adding a file failed', item);
                var data = {description: 'Please upload images files less then 700MB'};
                uploadError(data);
            });

            //BEFORE UPLOAD
            uploader.bind('beforeupload', function (event, item) {
                //console.info('Before upload', item);
                beforeUpload();
            });

            //UPLOAD PROGRESS
            uploader.bind('progress', function (event, item, progress) {
                //console.info('Progress: ' + progress, item);
                uploadProgress();
            });

            //UPLOAD SUCCESS
            uploader.bind('success', function (event, xhr, item, response) {
                //console.info('Success', xhr, item, response);
                //uploader.clearQueue();
                $scope.progressBarClass = 'progress-bar-striped active';
                uploadSuccess(response);
            });

            uploader.bind('cancel', function (event, xhr, item) {
                //console.info('Cancel', xhr, item);
                $scope.progressBarClass = '';
                uploadCancel();
            });

            uploader.bind('error', function (event, xhr, item, response) {
                //console.info('Error', xhr, item, response);
                $scope.progressBarClass = '';
                uploadError(response);
            });

            uploader.bind('complete', function (event, xhr, item, response) {
                //console.info('Complete', xhr, item, response);
                //uploadComplete();
            });

        })();

        $scope.cancelUpload = function(){
            console.log("in calcel upload scope");
            $scope.isUploadCanceled = true;
            $scope.uploadBackgound.show = false;
            clearUpload();
        };

        function clearUpload(){
            uploader.cancelAll();
            uploader.clearQueue();
        }

        function hideErrors(){
            $scope.uploadBackgound.isError = false;
        }

        function beforeUpload(){
            hideErrors();
        }

        function uploadProgress(){

        }

        function uploadSuccess(res){
            console.log("in upload success ");
            $scope.uploadBackgound.isUploaded = true;

            if(res.status.toUpperCase() === 'SUCCESS'){
                $scope.uploadBackgound.show = false;
                var data = res.data;
                var bg = {'src': data.filePath, 'title': '', 'selected': true, 'type': 'custom'};
                EventThemeModel.setEventBackgroundTheme(bg);
                addUploadedBackgorund(bg);
                clearUpload();
            }else{
                uploadError(res);
            }
        }

        function uploadError(err){

            errorHandler(err);
        }

        function uploadCancel(){
            console.log("upload cancled");
        }

        function addUploadedBackgorund(bg){
            var index = getBackgoundIndexByType('custom');
            if(index >= 0){
                var pos = $scope.backgroundsList.splice(index, 1, bg);
                var inPos = index;
            }else{
                var pos = $scope.backgroundsList.unshift(bg);
                $scope.updateSelectedBackground(0);
                var inPos = 0;
            }

            console.log("background shift pos", pos);
            $timeout(function(){
                $rootScope.$emit("changeBackground", {'index': inPos, 'type': 'default'});
            }, 500);

        }

        function getBackgoundIndexByType(type){
            var lnt = $scope.backgroundsList.length;
            var itemIndex;
            for(var i=0; i<lnt; i++){
                var item = $scope.backgroundsList[i];
                if(item.type == type){
                    itemIndex = i;
                }
            }
            return itemIndex;
        }

        /**
         * Set default theme when nothing is set
         */
         function setDefaultBackground() {
            var selectedBackground = EventThemeModel.getEventBackgroundTheme();
            console.log("event background theme ", selectedBackground);
            if (Utility.isObjectEmpty(selectedBackground)) {
                var index = getBackgoundIndexByType('default');
                console.log(index);
                $timeout(function(){
                    $rootScope.$emit("changeBackground", {'index': index, 'type': 'default'});
                }, 500);
            }
        }
    }]);
    eventTheme.value("uploadModuleURL",{"apiPrefix":"/api/","uploadVideo":"/upload/"});
});