/**
 * Video recorder globals that are used by flash
 */
var videorecorderSWF;

function videorecorderJS() {
}


define([
    'angular'
],
function(angular){
    var videoRecorder = angular.module("Inwiter.CreateEvent.EventVideo");
    videoRecorder.factory("VideoRecorderService", ['Restangular', 'AuthService', '$rootScope', 'UserModel', 'LazyLoadService', function(Restangular, Auth, $rootScope, UserModel, Lazyload){

        /** Global variables **/
        var recordCount = 0;
        var isVideoRecorded = false;
        var videoRecorderURLs = {"getRecorderPath": ''};
        var User  = UserModel.getUser();
        var recorderData = {};
        var encodeURL = window.location.origin+"/";
        var playBackData = {"streamType":"pseudo","videoURL":encodeURL};
        /**
         * To register swf object aginest DOM
         * @param appName
         * @returns {*}
         */
        function getSWFObject(appName) {
            //if (navigator.appName.indexOf ("Microsoft") !=-1) {
            // return window[appName];
            //if (jQuery.browser.msie) {
                return document.getElementById(appName);
            //} else {
            //    return document[appName];
            //}
        }

        /**
         * Communication with SWF object
         * @param data {{}}
         * @param funct {string}
         */
        function callToFlashPlayer(data, funct) {
            try {
                switch (funct) {
                    // VIDEO RECORDER
                    case 'StartRecording':
                        videorecorderSWF.recordVideo();
                        break;
                    case 'StopRecording':
                        videorecorderSWF.stopRecord();
                        break;
                    case 'PlayRecordedVideo':
                        videorecorderSWF.play(data);
                        break;
                    case 'StopRecordedVideo':
                        videorecorderSWF.stop();
                        break;
                    case 'SetRecorderFile':
                        videorecorderSWF.setRecordFile(data);
                        break;
                    case 'VRecSaveFile':
                        videorecorderSWF.saveFile();
                        break;
                    case 'VRecCancelFile':
                        videorecorderSWF.cancelFile();
                        break;
                }
            } catch (err) {
                console.log(err,+data,+funct);
            }
        }

        /**
         * Callbacks from SWF object to JS
         *
         */
        videorecorderJS.init = function () {
            console.log("video recorder init ");
            videorecorderSWF = getSWFObject("videorecorderSWF");
            var file = getVideoRecorderPath();
        };

        /** SAVE FILE **/
            videorecorderJS.saveFile = function(file) {
                var data = [ file ];
                getRecordedFile(file);
                console.log("Save file "+ file);
            };

            videorecorderJS.cancelFile = function() {
                console.log("cancel File");
            };

            videorecorderJS.enableSaveButton = function(vl) {
                console.log("enable disable save buttons-"+vl);
            };
            videorecorderJS.recordState = function(state) {
                console.log("AS TO JS record state " + state);
                if (state == 'begin') {
                    //videorecorderJS.initTimer();
                } else if (state == 'end') {
                    //videorecorderJS.stopTimer();
                }
            };
            videorecorderJS.playState = function(state) {
                console.log("Play state-"+state);
            };

        /**
         * Get video recoder file path from server
         * @returns {*}
         */
        var onPlayerLoad = function(){};
        function getVideoRecorderPath() {
            var url = videoRecorderURLs.getRecorderPath;
            var data = {userType: User.userType};
            var request = Restangular.service("recordvideo", Restangular.one('user', Auth.currentUserId())).one();
                          request.get(data).then(
                            function(response) {
                                console.log();
                                var res = response.data;
                                console.log(response);
                                recorderData = res;
                                setVideoRecorderFilePath(JSON.stringify(res));
                                onPlayerLoad();
                            },
                            function(error){

                            }
                        );

            //var resp = {"RTMPSettings":{"absolutePath":"/nasmedia/","relativePath":"useruploads/recghfasdgjgj123fgh","RTMP":"rtmp://192.168.0.116:1935/mediaserver","maximumDuration":"120","minimumRecordTime":"5"},"qualitySettings":{"width":"720","height":"405","quality":"90","FPS":"24","videoCodec":"H264","audioCodec":"SPEEX","extension":".flv"}};//{"absolutePath":"/nasmedia/","relativePath":"useruploads/","rtmp":"rtmp://192.168.0.116:1935/mediaserver","maximumDuration":"120","minimumRecordTime":"5"};
            //setVideoRecorderFilePath(JSON.stringify(resp));
            //onPlayerLoad();
        }

        function setVideoRecorderFilePath(data){
            callToFlashPlayer(data, 'SetRecorderFile');
        }

        function stopRecorder(){
            if(videorecorderSWF != undefined){
                callToFlashPlayer({}, 'StopRecording');
            }
        }

        function startRecorder(){
            callToFlashPlayer({}, 'StartRecording');
        }

        function cancelRecorder(){
            callToFlashPlayer({}, 'VRecCancelFile');
        }

        function playVideo(data1){
            var data = JSON.stringify(data1);
            callToFlashPlayer(data, 'PlayRecordedVideo');
        }

        function stopVideo(){
            callToFlashPlayer({}, 'StopRecordedVideo');
        }

        function saveRecord(){
            callToFlashPlayer({}, 'VRecSaveFile');
        }
        var getRecordFile = function(){};
        function getRecordedFile(file){
            getRecordFile(file);
            $rootScope.$broadcast("getRecordedFile", {file: file});
        }


        /**
         * LOAD HTML5 PLAYER
         */
        function loadHTML5Player(){
            console.log("load html player");
            Lazyload.HTML5Player();
        }

        /**
         * CANCEL RECORDING SERVICE
         */
        var onCancelrecord = function(){};

        $rootScope.$on("cancelRecording", function(){
            var data ={status: 'canceled'};
            onCancelrecord(data);
            videorecorderSWF = undefined;
        });


        /**
         * Video Recorder service
         * @type {{init: init, startRecord: startRecord, stopRecord: stopRecord, playVideo: playVideo, pauseVideo: pauseVideo, saveRecording: saveRecording}}
         */
        var service = {
            init : function() {
                console.log("video recorder init ");
                videorecorderSWF = getSWFObject("videorecorderSWF");
                getVideoRecorderPath();
                loadHTML5Player();
            },
            startRecord: function(){
                startRecorder();
            },
            stopRecord: function(){
                stopRecorder();
            },
            playVideo: function(data){
                playVideo(data);
            },
            stopVideo: function(){
                stopVideo();
            },
            saveRecord: function(callback){
                getRecordFile = callback;
                saveRecord();
            },
            cancelRecord: function(){
                cancelRecorder();
            },
            onCancelRecord: function(callback){
                onCancelrecord = callback;
            },
            onPlayerLoad: function(callback){
                onPlayerLoad = callback;
            },
            playerStatus: function(){
                if(videorecorderSWF != undefined){
                    return true;
                }else{
                    return false;
                }
            },
            resetRecorder: function(){
                videorecorderSWF = undefined;
            },
            getRecorderData: function(){
                return recorderData;
            },
            getPlaybackData: function(){
                return playBackData;
            }



        };
        return service;
    }]);
});




