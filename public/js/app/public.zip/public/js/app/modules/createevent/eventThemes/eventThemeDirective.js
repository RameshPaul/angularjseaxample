define(['angular'], function(angular){
    var eventTheme = angular.module('Inwiter.CreateEvent.EventTheme');

    eventTheme.directive("selectEventBackgroundTheme", ['$rootScope', function($rootScope){
        return{
            restrict: 'A',
            link: function(scope, element, attr){
                element.bind("click", function(e){
                    console.log(e, attr);
                    var index = attr.index;
                    console.log(index);
                    scope.updateSelectedBackground(index);
                    changeBackground(index);
                });
            }
        }
    }]);

    eventTheme.directive("uploadBackground", ['$rootScope', function($rootScope){
        return {
            restrict: 'A',
            link: function(scope, element, attrs){
                $rootScope.$on("changeBackground", function(event, data){
                    console.log("in change background event", data);
                    scope.updateSelectedBackground(data.index);
                    changeBackground(data.index, data.type);
                });
            }
        }
    }]);

    function changeBackground(index, type){
        console.log("change back", index);
        jQuery(".backgrounds-ul > li > span").removeClass('selected');
        jQuery(".backgrounds-ul > li").eq(index).children('span').addClass('selected');

        jQuery(".backgrounds-ul > li > a").removeClass('selected');
        jQuery(".backgrounds-ul > li").eq(index).children('a').addClass('selected');
        if(type == 'default'){
            jQuery(".backgrounds-ul > li").eq(index).trigger("click");
        }
    }

});