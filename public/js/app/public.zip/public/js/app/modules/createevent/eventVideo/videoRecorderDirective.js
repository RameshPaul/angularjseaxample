define([
    'angular'
],
function(angular){
    var videoRecorder = angular.module("Inwiter.CreateEvent.EventVideo");
    console.log("directive video recorder");
    videoRecorder.directive("videoRecorder",['base_url', '$compile', 'VideoRecorderService', '$rootScope', function(base_url, $compile, VideoRecorderService, $rootScope){
        return {
            restrict: 'A',
            link: function(scope, element, attrs){
                console.log(" video recorder directive");
                var videoRecorderHTML = '<object data="/public/swf/videorecorder.swf" width="640" height="360" align="middle" class="recoderStyleClass" id="videorecorderSWF"><param name="src" value="/public/swf/videorecorder.swf"><param name="allowscriptaccess" value="always"><param name="allowfullscreen" value="false"><param name="quality" value="high"><param name="bgcolor" value="#ffffff"><param name="wmode" value="transparent"><embed name="videorecorderSWF" id="videorecorderSWF" src="/public/swf/videorecorder.swf" pluginspage="http://www.adobe.com/go/getflashplayer" height="315" width="560" wmode="transparent"></object>';

                //var livePreviewHTML = '<object id="livepreviewSWF" class="livepreviewSWF" height="405" width="640" wmode="opaque"><param name="src" value="' + base_url + 'swf/livepreview.swf?version=889348344"><param name="flashVars" value=""><param name="allowscriptaccess" value="always"><param name="allowFullScreen" value="true"><param name="wmode" value="opaque" /><param name="scale" value="noscale" /><embed name="livepreviewSWF" src="' + base_url + 'swf/livepreview.swf?version=789125728" pluginspage="http://www.adobe.com/go/getflashplayer" height="405" width="640" id="livepreviewSWF" flashvars="" allowfullscreen="true" wmode="opaque" scale="noscale"></object>';

                var isPlayerLoaded = false;
                /** Jquery event handler for video recorder modal **/

                jQuery(".video-recorder-modal").on('show.bs.modal', function(e){
                    console.log("in jquery open");
                    loadPlayer();
                });

                jQuery(".video-recorder-modal").on("hide.bs.modal", function(){
                    console.log("modal closed");
                    $rootScope.$broadcast("cancelRecording");
                    removePlayer();
                });

                function loadPlayer(){
                    element.removeClass('hide');
                    if(!isPlayerLoaded){
                        isPlayerLoaded = true;
                        element.html(videoRecorderHTML);
                    }
                }

                function removePlayer(){
                    element.addClass('hide');
                    isPlayerLoaded = false;
                    VideoRecorderService.resetRecorder();
                }

                scope.$on("loadVideoRecorder", function(){
                    loadPlayer();
                });

                scope.$on("removeVideoRecorder", function(){
                   removePlayer();
                });
            }
        }
    }]);

    videoRecorder.directive("timer", [function(){
        return{
            restrict: 'A',
            link: function(scope, element, attr){
                var Intervel = 1000;
                var targetTime = attr.countdown;
                var targetTimeOrig = angular.copy(targetTime);
                var timeOutID = 0;
                console.log("in timer directive ", targetTime);
                var timer = {};

                    timer.stop = function(){
                      console.log("timer stopped", targetTime);
                      clearInterval(timeOutID);
                      scope.$broadcast("timer-stopped", targetTime);

                    };

                    timer.clearInterval = function(){
                        clearInterval(timeOutID);
                    };

                    timer.start = function(){
                        timeOutID = setInterval(function(){
                            var secs = targetTime;
                            console.log(secs);
                            if(secs >= 0){
                                var tm = timer.convertToTime(secs);
                                var total = timer.convertToTime(targetTimeOrig);
                                element.html(tm+'/'+total);
                            }else{
                                timer.stop();
                            }
                            targetTime = targetTime-1;
                        }, Intervel);
                    };

                    timer.reset = function(){
                        clearInterval(timeOutID);
                        var total = timer.convertToTime(targetTimeOrig);
                        element.html(timer.convertToTime(targetTime)+'/'+total);
                    };

                    timer.convertToTime = function(secs){
                        var hours = Math.floor(secs / (60 * 60));

                        // var hours = (secs / (60 * 60));

                        var divisor_for_minutes = secs % (60 * 60);
                        var minutes = Math.floor(divisor_for_minutes / 60);

                        // var minutes = (divisor_for_minutes / 60);

                        var divisor_for_seconds = divisor_for_minutes % 60;
                        var seconds = Math.ceil(divisor_for_seconds);
                        // var seconds = parseFloat(divisor_for_seconds);

                        var hrs, mns, sec;
                        if (hours.toString().length < 2) {
                            hrs = '0' + hours.toString();
                        } else {
                            hrs = hours;
                        }

                        if (minutes.toString().length < 2) {
                            mns = '0' + minutes.toString();
                        } else {
                            mns = minutes;
                        }

                        if (seconds.toString().length < 2) {
                            sec = '0' + seconds.toString();
                        } else {
                            sec = seconds;
                        }

                        return  mns + ":" + sec;
                    };

                /**
                 * Timer Events
                 */

                    scope.$on("timer-start", function(e, data){
                        timer.start();
                    });

                    scope.$on("timer-stop",function(e, data){
                        timer.stop();
                    });

                    scope.$on("timer-reset", function(e, data){
                        timer.clearInterval();
                        if(data != undefined && data.time != undefined){
                            targetTime = data.time;
                            targetTimeOrig = angular.copy(targetTime);
                        }else{
                            targetTime = attr.countdown;
                        }
                        timer.reset();
                    });

                    timer.reset();

            }

        }
    }]);

    videoRecorder.directive("startVideoRecord", ['VideoRecorderService', '$rootScope', function(VideoRecorderService, $rootScope){
        return{
            restrict: 'A',
            link: function(scope, element, attrs){
                scope.timerRunning = false;
                var start = false;
                var time = attrs.startVideoRecord;
                console.log(time);
                //scope.$broadcast('timer-set-countdown', time);

                element.unbind("click");
                element.bind("click", function(event){

                    if(start){
                        console.log("start stop flag", start);
                        start = false;
                        scope.$broadcast('timer-stop');
                        //recorderStopped();
                    }else{
                        start = true;
                        checkAndLoadPlayer();
                    }
                });

                scope.$on('timer-stopped', function (event, data){
                    console.log('Timer Stopped - data = ', data);
                    /*VideoRecorderService.stopRecord();
                    element.html('Retake');
                    $rootScope.$broadcast('onRecordStartStop', {status: 'stop'});
                    */
                    recorderStopped();
                });

                //CANCEL RECORDING
                VideoRecorderService.onCancelRecord(function(){
                    console.log("recorder canceled");
                    start = false;
                    element.html('Start');
                    scope.$emit('timer-reset');
                    scope.$broadcast("hidePreviewPlayer");
                    $rootScope.$broadcast("recordClosed");
                    $rootScope.$broadcast('onRecordStartStop', {status: 'start'});
                });

                function checkAndLoadPlayer(){
                    $rootScope.$broadcast("recordClosed");
                    start = true;
                    var playerStatus = VideoRecorderService.playerStatus();
                    console.log("plater status--", playerStatus);
                    if(playerStatus){
                        $rootScope.$broadcast('onRecordStartStop', {status: 'start'});
                        scope.$emit('timer-reset');
                        scope.timerRunning = true;
                        scope.$broadcast('timer-start');
                        VideoRecorderService.startRecord();
                        element.html('Stop');
                    }else{
                        scope.$broadcast("loadVideoRecorder");
                    }
                }

                function recorderStopped(){
                    start = false;
                    scope.timerRunning = false;
                    VideoRecorderService.stopRecord();
                    element.html('Retake');
                    scope.$emit('timer-reset');
                    //$rootScope.$broadcast('onRecordStartStop', {status: 'stop'});
                    VideoRecorderService.saveRecord(function(file){
                        var encodeData = VideoRecorderService.getRecorderData();
                        console.log(encodeData);
                        var fileData = 'storage/'+encodeData.RTMPSettings.relativePath+encodeData.qualitySettings.extension;
                        console.log("play file", file, fileData);
                        $rootScope.$broadcast("addForEncoding", {file: fileData});
                        scope.$broadcast("showEncodingProgress");
                    });
                }

                VideoRecorderService.onPlayerLoad(function(){
                   console.log("player reloaded");
                    if(start) {
                        scope.$broadcast("hidePreviewPlayer");
                        scope.$broadcast("loadVideoRecorder");
                        scope.$broadcast("hideEncodingProgress");
                        scope.$broadcast('timer-reset');
                        scope.$broadcast('timer-start');
                        scope.timerRunning = true;
                        VideoRecorderService.startRecord();
                        element.html('Stop');
                        $rootScope.$broadcast('onRecordStartStop', {status: 'start'});
                    }
                });
            }
        }
    }]);

    videoRecorder.directive("playVideoRecord", ['VideoRecorderService', '$rootScope', function(VideoRecorderService, $rootScope){
        return {
            restrict: 'A',
            link: function(scope, element, attrs){
                //scope.$broadcast('timer-stop');
                scope.timerRunning = false;
                element.addClass('disabled');
                var videoData = {};
                var isPlaying = false;

                element.bind("click", function(){
                    var data = angular.copy(VideoRecorderService.getPlaybackData());
                        data.videoURL = data.videoURL+videoData.src;
                    if(isPlaying){
                        isPlaying = false;
                        VideoRecorderService.stopVideo();
                    }else{
                        isPlaying = true;
                        VideoRecorderService.playVideo(data);
                    }
                });

                $rootScope.$on('onRecordStartStop', function(e, data){
                    if(data.status == 'stop'){
                        //element.removeClass('disabled');
                    }else{
                        element.addClass('disabled');
                        VideoRecorderService.stop();
                    }
                });

                //scope.$apply();
                //CANCEL RECORDING
                VideoRecorderService.onCancelRecord(function(){
                    console.log("recorder canceled");
                });

                $rootScope.$on("encodeResponse", function(e, data){
                    console.log("encode response ", data);
                    //scope.$broadcast("showPreviewPlayer", data);
                    videoData = angular.copy(data);
                    element.removeClass('disabled');
                    scope.$broadcast("hideEncodingProgress");
                    $rootScope.$broadcast('onRecordStartStop', {status: 'stop'});
                });
            }
        }
    }]);

    videoRecorder.directive("processingBar", ['VideoRecorderService', function(VideoRecorderService){
        return{
            restrict: 'A',
            link: function(scope, element, attr){
                scope.$on("getRecordedFile", function(e, data){
                    //console.log("")
                });

                scope.$on("showEncodingProgress", function(e, data){
                    element.removeClass('hide');
                });

                scope.$on("hideEncodingProgress", function(e, data){
                    element.addClass('hide');
                });

                function showEncoding(){

                }

                function hideEncoding(){

                }


            }
        }
    }]);

    videoRecorder.directive("recorderPreviewPlayer", ['$rootScope', function($rootScope){
        return{
            restrict: 'A',
            link: function(scope, element, attr){
                var video_4_Player;
                scope.$on("showPreviewPlayer", function(e, data){
                    element.removeClass('hide');
                    scope.$broadcast("removeVideoRecorder");

                    //LOAD HTML5 PLAYER
                    console.log("show Preview Player-", data);

                    var videoTag = jQuery("<video>",
                        {"id":'recorded_video',
                            "class":'video-js vjs-default-skin vjs-big-play-centered block-video',
                            "controls":'true',
                            "preload": 'auto',
                            "width":'640px',
                            "height":'360px'
                        }
                    );
                    var source = {"src": '/storage/useruploads/2014_07_1953ca14100b9e5.mp4', "type":'video/mp4'};//{"src": 'http://192.168.0.125/'+data.src, "type":'video/mp4', "poster": 'http://192.168.0.125/'+data.thumbLarge};
                    var src1 = jQuery("<source>", source);
                    jQuery(videoTag).append(src1);
                    element.html(videoTag);
                    //$(videoTag).appendTo(".modal-body");
                    videojs('recorded_video',{"width":'640',"height":'360'},function(ev){
                        video_4_Player = jQuery(this);
                        console.log("player loaded");
                        console.log(video_4_Player);
                        scope.$broadcast("hideEncodingProgress");
                        $rootScope.$broadcast('onRecordStartStop', {status: 'stop'});
                    });

                });

                scope.$on("hidePreviewPlayer", function(e, data){
                    console.log("hide preview play6er ");
                    element.addClass('hide');
                    element.html('');
                    console.log(video_4_Player);
                });

                function showPlayer(){

                }

                function hidePlayer(){

                }
            }
        };
    }]);

    videoRecorder.directive("saveVideoRecord", ['$rootScope', function($rootScope){
        return{
            restrict: 'A',
            link: function(scope, element, attr){
                element.addClass('disabled');
                element.bind("click", function(){
                   console.log("save video");
                   jQuery(".video-recorder-modal").modal('hide');
                    $rootScope.$broadcast("recorderDone");
                });

                $rootScope.$on('onRecordStartStop', function(e, data){
                    if(data.status == 'stop'){
                        element.removeClass('disabled');
                    }else{
                        element.addClass('disabled');
                    }
                });

            }
        }
    }]);
});