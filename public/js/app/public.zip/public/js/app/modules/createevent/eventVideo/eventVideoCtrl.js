define([
    'angular'
],

function (angular) {

    var eventVideo = angular.module('Inwiter.CreateEvent.EventVideo');

    eventVideo.controller("EventVideoCtrl",['$scope', '$rootScope', '$injector', 'AuthService', 'LazyLoadService', '$fileUploader', 'EncodingService', 'EventVideoModel', 'uploadModuleURL', 'UtilityService', 'VideoRecorderService', function($scope, $rootScope, $injector, Auth, LazyLoad, $fileUploader, EncodeService, EventVideoModel, uploadModuleURL, Utility, VideoRecorderService){

        /** Global Scope objects **/
        $scope.videoTimeline = {};
        $scope.videoTimeline.queue = EventVideoModel.getVideoTimeLineQueue();
        $scope.isVideoUploadView = true;
        $scope.isVideoTimeLine = false;
        $scope.isUploadCanceled = false;
        $scope.showVideoUploadBtn = true;
        $scope.videoRecoderDuration = 120;
        $scope.videoUploadComplete = false;
        $scope.maxVideoLength = '00:15:00';
        $scope.progressBarClass = '';
        $scope.videoUpload = {};
        $scope.videoUpload.isUploading = false;
        $scope.videoUpload.uploadError = false;
        $scope.videoUpload.errorText = '';
        $scope.videoRecorder = {};

        $rootScope.videoTimelineData = $scope.videoTimeline.queue;


        console.log("in event video controller");

        /**
         * Upload video Edit
         */
        function edit() {
            var data = [];
            EventVideoModel.setVideoTimeLineQueue(data);
        }

        if($rootScope.isEdit) {
            edit();
        }

        /**
         * Upload video functionality
         *  angular-file-upload v0.5.7
         *  https://github.com/nervgh/angular-file-upload
         */
        var uploader;
        $scope.uploader;

        function init(){
            console.log("IN EVENT VIDEO INIT");
            // create a uploader with options
            uploader = $scope.uploader = $fileUploader.create({
                scope: $scope,                          // to automatically update the html. Default: $rootScope
                headers: Auth.getHeaders(),
                //method: 'PUT',
                url: uploadModuleURL.apiPrefix+'user/'+Auth.currentUserId()+uploadModuleURL.uploadVideo,
                autoUpload: true,
                formData: [
                    {'uploadType': 'video' }
                ],
                filters: [
                    function (item) {                    // first user filter
                        var valid = Utility.validateVideo(item);
                        return valid.val;
                        //return true;
                    }
                ]

            });

            //AFTER ADDING FILE
            uploader.bind('afteraddingfile', function (event, item) {
                console.info('After adding a file', item);
                $scope.progressBarClass = '';
                $scope.videoUpload.isUploading = true;
                console.log($scope.videoUpload.isUploading);
                $scope.videoUpload.uploadError = false;
            });

            //WHEN ADDING FAILED
            uploader.bind('whenaddingfilefailed', function (event, item) {
                console.info('When adding a file failed', item);
                var err = {description: 'Please upload video files below 700MB'};
                uploadError(err);
            });

            //BEFORE UPLOAD
            uploader.bind('beforeupload', function (event, item) {
                console.info('Before upload', item);
                beforeUplaod();
            });

            //UPLOAD PROGRESS
            uploader.bind('progress', function (event, item, progress) {
                console.info('Progress: ' + progress, item);
                uploadProgress();
            });

            //UPLOAD SUCCESS
            uploader.bind('success', function (event, xhr, item, response) {
                console.info('Success', xhr, item, response);
                //uploader.clearQueue();
                $scope.progressBarClass = 'progress-bar-striped active';
                uploadSuccess(response);
            });

            uploader.bind('cancel', function (event, xhr, item) {
                console.info('Cancel', xhr, item);
                $scope.progressBarClass = '';
                uploadCancel();
            });

            uploader.bind('error', function (event, xhr, item, response) {
                console.info('Error', xhr, item, response);
                $scope.progressBarClass = '';
                uploadError(response);
            });

            uploader.bind('complete', function (event, xhr, item, response) {
                console.info('Complete', xhr, item, response);
                uploadComplete();
            });

            console.log("uploader object-", uploader);
        }

        $scope.cancelUpload = function(){
            resetUpload();
            console.log("in calcel upload scope");
            $scope.isUploadCanceled = true;
            $scope.showVideoUploadBtn = true;
            //uploader.cancelAll();
            //uploader.clearQueue();
        };

        $scope.openUpload = function(){
            resetUpload();
        };

        function beforeUplaod(){
            $scope.showVideoUploadBtn = false;
            //$scope.$apply();
        }

        function uploadProgress(){

        }

        function resetUpload(){
            EncodeService.cancelJob();
            $scope.videoUpload.isUploading = false;
            $scope.videoUpload.uploadError = false;
        }

        function uploadSuccess(res){
            //resetUpload();
            if(res.status.toUpperCase() === 'SUCCESS'){
                var data = res.data;
                    data.length = $scope.maxVideoLength;
                addForEncoding(data);
            }else{
                uploadError(res);
            }
        }

        function uploadError(err){
            EncodeService.cancelJob();
            errorHandler(err);
        }

        function uploadComplete(){

        }

        function uploadCancel(){
            console.log("upload cancled");
            EncodeService.cancelJob();
        }

        function errorHandler(error){
            var defaultError = 'Some internal error has occurred Please try later';
            $scope.videoUpload.errorText = Utility.checkObjectKey(error, 'description', defaultError);
            $scope.videoUpload.uploadError = true;
            console.log(error);
        }

        /**
         *  UPLOAD MODAL CLOSED
         */
        $scope.$on("uploadClosed", function(e, data){
            console.log("upload modal closed");
            EncodeService.cancelJob();
        });

        /***
         * Encode callbacks
         */
        function addForEncoding(data){
            EncodeService.addJob(data, encodeSuccess, encodeError);
        }

        function encodeSuccess(data, replacePath){
            console.log(data);
            addVideoToTimeLine(data, replacePath);
            $scope.videoUploadComplete = true;
        }

        function encodeError(data){
            console.log(data);
            errorHandler(data);
        }

        /***
         * Video time line
         */
        function addVideoToTimeLine(data, replacePath){
            var video = prepareVideoItem(data, replacePath);
            if(video.status.toUpperCase() == 'ERROR'){
                var error = {description: 'We are unable to process your video please upload/record valid video'};
                encodeError(error);
            }else{
                $scope.isVideoUploadView = false;
                EventVideoModel.clearQueue();
                EventVideoModel.addItem(video);
                updateVideoTimeLine();
                $scope.$broadcast("closeUploadVideoModal");
            }
        }

        function prepareVideoItem(jsonData, replacePath){
            var data = JSON.parse(jsonData.result);
            console.log(data, replacePath);
            var find = replacePath;
            var re = new RegExp(find, 'g');
            var video = {};
            console.log((data.output_video.outputfile).replace(re,''));
            video.src = (data.output_video.outputfile).replace(re,'');
            video.thumbSmall = (data.output_thumbs[0].outputfile).replace(re,'');
            video.thumbLarge = (data.output_thumbs[1].outputfile).replace(re,'');
            video.duration = data.output_video.length;
            video.status = (data.output_video.status);
            console.log(video);
            return video;
        }

        function updateVideoTimeLine(){
            $scope.videoTimelineData = EventVideoModel.getVideoTimeLineQueue();
        }

        $scope.videoTimeline.remove = function(index){
            EventVideoModel.removeItem(index);
            updateVideoTimeLine();
            if($scope.videoTimelineData.length == 0){
                $scope.isUploadCanceled = false;
                $scope.showVideoUploadBtn = true;
                $scope.isVideoUploadView = true;
                $scope.videoUploadComplete = false;
            }
        };

        /**
         * Video Recorder
         */
        $scope.videoRecorder.maxRecordTime = 20;
        $scope.videoRecorder.enableControls = false;
        $scope.videoRecorder.enableSaveBtn = false;
        $scope.videoRecorder.processingBar = {};
        $scope.videoRecorder.processingBar.enable = false;
        $scope.videoRecorder.video = {};
        $scope.videoRecorder.launch = function(){
            VideoRecorderService.init();
        };

        $rootScope.$on("onRecordStartStop", function(e, data){
           if(data.status == 'stop'){
               $scope.videoRecorder.maxRecordTime = 180;
               console.log("on Record stop", data);
               $scope.videoRecorder.enableSaveBtn = true;
           }else{
               $scope.videoRecorder.enableSaveBtn = false;
           }
        });

        $rootScope.$on("getRecordedFile", function(e, data){
            console.log(data);
        });

        $scope.videoRecorder.saveRecorderFile = function(file){
            console.log("video recorder save file in ctrl",+file);
        };

        VideoRecorderService.onCancelRecord(function(){
           console.log("recorder canceled");
        });

        $rootScope.$on("addForEncoding", function(e, data1){
            console.log("add for encoding ", data1);
            var data = {filePath: data1.file, fileType: 'video', length: $scope.maxVideoLength};
            EncodeService.addJob(data, function(data, replacePath){
                console.log("Encode success", data, replacePath);
                var response = prepareVideoItem(data, replacePath);
                $scope.videoRecorder.video = data;
                $scope.videoRecorder.repalcePath = replacePath;
                $rootScope.$broadcast("encodeResponse", response);
            }, function(data){
                console.log("encode error");
                encodeError(data);
            });
        });

        $rootScope.$on("recordClosed", function(e, data){
            console.log("recorder modal closed");
            EncodeService.cancelJob();
            $scope.videoRecorder.video = {};
        });

        $rootScope.$on("recorderDone", function(e, data){
            console.log("recorder done-", data);
            addVideoToTimeLine($scope.videoRecorder.video, $scope.videoRecorder.repalcePath);
        });


        //INIT
        init();
    }]);
    eventVideo.value("uploadModuleURL",{"apiPrefix":"/api/","uploadVideo":"/upload/"})
});
