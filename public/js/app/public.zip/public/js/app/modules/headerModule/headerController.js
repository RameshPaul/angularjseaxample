define([
        'angular'
    ],
    function (angular) {

        angular.module('Inwiter.Header')

            .controller('HeaderCtrl', ['$scope', '$rootScope', 'UserModel', function ($scope, $rootScope, UserModel) {
                console.log("user Header ctrl");
                /**
                 * APP HEADER
                 */
                $rootScope.$on("onUserModelReady", function(){
                    $scope.user = angular.copy(UserModel.getUser());
                    $scope.user.firstName = $scope.user.firstName.substring(0, 9);
                    if($scope.user.photoURL == ""){
                        $scope.user.photoURL = '/public/images/user-dummy.jpg';
                    }
                    console.log("In header ctrl", $scope.user);

                });
            }]);

    });
