define([
        'angular'
    ],
    function (angular) {

        angular.module('Inwiter')

            .controller('AppCtrl', ['$scope', '$rootScope', '$http', 'ajaxURL', 'AuthService', 'UserModel', '$timeout', '$stateParams', '$location', function($scope, $rootScope, $http, ajaxURL, AuthService, UserModel, $timeout, $stateParams, $location){

                console.log("in app main controller");

                $scope.styleSheets = [];

                /**
                 * GLOBAL EVENTS FOR WHOLE APP
                 */
                $scope.infoBar = {enable: false, text: "Please check your self your looking too smart"};
                $scope.infoBar.enable = false;
                jQuery(".info-bar").removeClass('hide');
                $scope.infoBar.close = function(){
                    $scope.infoBar.enable = false;
                    console.log($scope.infoBar.enable);
                };
                $scope.infoBar.show = function(data){
                    if(data.description == undefined){
                        $scope.infoBar.text = "Some internal error occurred please try after some time";
                    }else{
                        $scope.infoBar.text = data.description;
                    }

                    $scope.infoBar.enable = true;
                    $timeout(function(){
                        $scope.infoBar.close();
                    },5000)
                };

                /** SUCCESS NOTIFICATION **/
                $rootScope.$on("showInfoBar", function(data, res){
                    console.log(data, res);
                    $scope.infoBar.show(res);
                });



            }]);

});