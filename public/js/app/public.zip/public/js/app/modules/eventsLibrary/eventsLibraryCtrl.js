define([
    'angular'
],
function(angular){
    var eventsLibrary = angular.module("Inwiter.EventsLibrary");
    if(eventsLibrary.register != undefined){
        eventsLibrary = eventsLibrary.register;
    }

    eventsLibrary.controller("EventsLibraryCtrl", ['$scope', '$location', '$rootScope', '$injector', 'Restangular', 'AuthService', 'EventService', 'EventsLibraryModel', 'appLogService', 'UserModel', 'UtilityService', '$stateParams', function($scope, $location, $rootScope, $injector, Restangular, Auth, EventService, EventModel, appLogService, UserModel, Utility, $stateParams){
        //Route to this page if it is active
        $scope.isActive = function(route) {
            return route === $location.path();
        };

        console.log("in events library controller");
        console.log("Userid-", UserModel.getUser());

        var startLimit = 0;
        var defaultItemsLimit = 6;
        var viewAllItemsLimit = 10;
        var selectedTab = 'upcoming';
        var itemsQueried = 3;
        var itemsFetched = 0;

        var userView = 'default';

        var routePrams = $stateParams.view;
        if(routePrams == 'all'){
            userView = 'all';
            defaultItemsLimit = 10;
            selectedTab = 'all';
        }

        $scope.templates = {
            defaultEvents: {name: 'eventsLibraryDefaultTpl.html', url : '/public/js/app/modules/eventsLibrary/eventsLibraryDefaultTpl.html'},
            allEvents: {name: 'eventsLibraryAllTpl.html', url : '/public/js/app/modules/eventsLibrary/eventsLibraryAllTpl.html'},
            groupEvents: {name: 'groupEventsTpl.html', url : '/public/js/app/modules/eventsLibrary/groupEventsTpl.html'}
        };

        if(userView == 'all'){
            $scope.templates.eventsLibrary = $scope.templates.allEvents;
        }else{
            $scope.templates.eventsLibrary = $scope.templates.defaultEvents;
        }

        $scope.showError = '';
        $scope.showResponseMessage= '';
        $scope.selectedEvents = [];
        $scope.recurrenceEventsList = [];
        $scope.defaultView = true;
        $scope.response = [];
        $scope.eventsLibrary = EventModel.getEvents();
        $scope.pagination = {};
        $scope.pagination.selectedItems = $scope.eventsLibrary[selectedTab];
        $scope.pagination.enable = false;
        $scope.pagination.currentPage = 0;
        $scope.pagination.pageSize = 3;
        $scope.pagination.numberOfPages=function(){
            console.log($scope.eventsLibrary[selectedTab].length, $scope.pagination.pageSize);
            var totalPages = Math.ceil($scope.eventsLibrary[selectedTab].length/$scope.pagination.pageSize);
            return totalPages+1;
        };




        //CANCEL EVENT MODEL
        $scope.cancelEventModel = {text: ""};
        console.log($scope.eventsLibrary[selectedTab]);

        function resetLimits(){
            startLimit = 0;
            defaultItemsLimit = 6;
        }

        /**
         * Past evnets directive handler
         */
        $scope.showPastEvents = function(){
            resetLimits();
            selectedTab = 'past';
            $scope.defaultView = true;
            EventModel.removeAllEvents();
            getEvents(startLimit, defaultItemsLimit, selectedTab);
            resetPagination(defaultItemsLimit);
        };

        /**
         * Upcoming events directive handler
         */
        $scope.showUpcomingEvents = function(){
            resetLimits();
            selectedTab = 'upcoming';
            $scope.defaultView = true;
            EventModel.removeAllEvents();
            getEvents(startLimit, defaultItemsLimit, selectedTab);
            resetPagination(defaultItemsLimit);
        };

        /**
         * Pagination handler to load next events
         * @returns {number}
         */
        $scope.nextPage = function(){
            console.log(itemsQueried);
            if(itemsFetched >= itemsQueried){
                var lnt = $scope.eventsLibrary[selectedTab].length;
                var sLimit = lnt;
                var eLimit = defaultItemsLimit;
                getEvents(sLimit, eLimit, selectedTab);
            }
            return $scope.pagination.currentPage=$scope.pagination.currentPage+1;
        };

        /**
         * Show all events handler
         */
        $scope.showAllEvents = function(){
            resetLimits();
            selectedTab = 'all';
            $scope.defaultView = true;
            EventModel.removeAllEvents();
            getEvents(startLimit, defaultItemsLimit, selectedTab);
            resetPagination(viewAllItemsLimit);
        };

        /**
         * Delete event handler
         *
         */
        $scope.deleteEvent = function(index, eventId, flag, type, cancelText){
            console.log("selected item index--"+eventId);
            var data = [], pos = [];
            data.push(eventId);
            pos.push(index);
            removeSelectedEvents(data, flag, type, cancelText);
        };

        /**
         * Delete selected events handler
         * @param flag
         */
        $scope.deleteSelectedEvents = function(flag){
            removeSelectedEvents($scope.selectedEvents, flag);
        };

        /**
         * Event selection functionality
         * @param size
         */

        // selected events
        $scope.selectedEvents = [];

        // toggle selection for a given eventId
        $scope.toggleEventSelection = function toggleSelection(eventId) {
            var idx = $scope.selectedEvents.indexOf(eventId);

            // is currently selected
            if (idx > -1) {
                $scope.selectedEvents.splice(idx, 1);
            }

            // is newly selected
            else {
                $scope.selectedEvents.push(eventId);
            }
            console.log($scope.selectedEvents);
        };

        /**
         * Delete/Cancel/Remove selected or signle event
         */
        function removeSelectedEvents(items, flag, type, cancelText){
            console.log(items);
            items.push(13);
            var data = Utility.objectToRequestData({"deleteFlag": flag, "eventIdList": JSON.stringify(items)});//
            if(flag == 'XX') {
                EventService.remove(data).then(function(response){
                    console.log(response);
                    if(response.status.toUpperCase() == 'SUCCESS'){
                        deleteSuccess(items, flag, type);
                    }
                }, errorHandler);
            }
            if(flag == 'CC'){
                data.cancelText = cancelText;
                EventService.post(data).then(function(response){
                    console.log(response);
                    if(response.status.toUpperCase() == 'SUCCESS'){
                        deleteSuccess(items, flag, type);
                    }
                }, errorHandler);
            }
        }

        /**
         * Delete event success
         */
        function deleteSuccess(items, flag, type){
            console.log(items, flag, type);
            EventModel.removeEvents(items, type);
            updateQueue();
        }

        /**
         * Reset pagination
         * @param size
         */
        function resetPagination(size){
            itemsQueried = size;
            $scope.pagination.currentPage = 0;
            $scope.pagination.pageSize = size/2;
            $scope.pagination.selectedItems = $scope.eventsLibrary[selectedTab];
        }

        /**
         * Get events from server
         * @param startLimit {int}
         * @param endLimit {int}
         * @param type {string}
         */
        function getEvents(startLimit, endLimit, type){
            var filters = {"intStartLimit": startLimit, "intEndLimit": endLimit, "eventRequestType": type};
            var data = EventService.get(filters);
            console.log(data);
            $scope.response = data.$object;
            data.then(eventsResponse, errorHandler);
            appLogService.debug("Get events - event type = "+type+" Filters applied");
            appLogService.debug(filters);
        }

        /**
         * events response
         *
         */
        function eventsResponse(){
            console.log($scope.response);
            var response = $scope.response;
            if(response.status.toUpperCase() === 'SUCCESS') {
                var resData = response.data.userEvents;
                itemsFetched = resData.length;
                var res = resData;
                EventModel.addEvents(res, selectedTab);
                updateQueue(res);
                appLogService.debug("Data fetched from server items length-"+itemsFetched+" type-"+selectedTab);
            }else{
                errorHandler(response);
            }
        }

        /**
         * error handler
         * @param error
         */
        function errorHandler(error){
            appLogService.debug("Got error see below ==");
            appLogService.error(error);
            $scope.showError = error.description;
        }

        /**
         * Update queue after server response
         * @param data
         */
        function updateQueue(){
            $scope.eventsLibrary = EventModel.getEvents();
        }

        /**
         * Recurrence event functionality
         *
         */
        var recurrenceRequestData = {};
        $scope.recurrenceEventData = function(eventId){
            var filters = {"type":"recurrence"};
            var request = Restangular.one(EventService, eventId).getList(filters);
            recurrenceRequestData = request.$object;
            request.then(recurrenceResponse, errorHandler);
        };

        function recurrenceResponse(response){
            console.log(response);
            $scope.recurrenceEventsList = recurrenceRequestData;
        }


        /**
         *  VIEW MAPPING Function
         */
        $scope.eventStatusToText = function(flag){
            console.log(flag);
            if(flag == 'DR'){
                return 'DRAFT';
            }
            if(flag == 'SB' || flag == 'SS'){
                return 'SENT'
            }
            if(flag == 'SH'){
                return 'SCHEDULED';
            }
            if(flag == 'CC'){
                return 'CANCELED';
            }
            if(flag == 'XX'){
                return 'DELETED';
            }
            if(flag == 'ST'){
                return 'STAGING';
            }

        };

        $scope.eventTypeToText = function(type){
            if(type == '1'){
                return 'INVITATION';
            }
            if(type == '2'){
                return 'GREETING';
            }
        };

        $scope.dateTimeToTimestamp = function(date, time){
            var dt = new Date(date+" "+time);
            return dt.getTime();
        };


        /**
         * LOAD EVENTS BASED ON CONFIG
         */
        (function(){
            if(userView == 'all'){
                $scope.showAllEvents();
                console.log("ALL EVENTS LOADED");
            }else{
                $scope.showUpcomingEvents();
                console.log("upcoming events loaded");
            }

        })();

    }]);

    eventsLibrary.filter('startFrom', function() {
        return function(input, start) {
            start = +start; //parse to int
            return input.slice(start);
        }
    });

    eventsLibrary.filter('num', function() {
        return function(input) {
            var rs = parseInt(input);
            if(isNaN(rs)){
                rs = 0;
            }
            return rs;
        }
    });

});
