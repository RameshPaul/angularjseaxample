define([
    'angular'
], function(angular){
    var guest = angular.module("Inwiter.GuestModule");

    guest.directive("rsvpBtnGroup", [function(){
        return{
            restrict: 'A',
            link: function(scope, element, attrs){
                console.log("in btn group directive");
                jQuery(".btn-group > label").click(function(e){
                    jQuery(".btn-group > label").removeClass('active');
                    jQuery(this).addClass('active');
                });
            }
        }
    }]);

    guest.directive('ngRadioExtend', ['$rootScope', function($rootScope){
        return {
            require: 'ngModel',
            restrict: 'A',
            link: function(scope, iElm, iAttrs, controller) {
                iElm.bind('click', function(){
                    $rootScope.$$phase || $rootScope.$apply()
                });
            }
        };
    }]);

    guest.directive('backStreach', [function(){
        return{
            restrict: 'A',
            link: function(scope, element, attr){
                console.log("element");
                console.log(element.parent().parent());

                scope.$watch("backgroundTheme", function(url){
                    console.log("old-"+url);
                    if(url != ""){
                        element.parent().parent().backstretch(url);
                    }
                });
            }
        }
    }]);
});