define([
    'angular'
],
function (angular) {
    var eventDetails = angular.module('Inwiter.CreateEvent.EventDetails');
        eventDetails.factory('EventDetailsModel',['UserModel', function(User){
            //For
            var eventDetails = {
                                        "rsvp": 1,
                                        "eventType": '',
                                        "eventName": '',
                                        "startDateTime": '',
                                        "endDateTime": '',
                                        "eventDescription": '',
                                        "location": ''
                                    };
            var myReplyOptions = {
                                    "keepGuestListHidden": '',
                                    "knowMeOnGuestsRSVP": '',
                                    "knowMeOnGuestsComment": ''
                                };
            var guestReplyOptions = {
                                        "howManyKidsAttend":'',
                                        "limitTotalGuests":'',
                                        "remindOneDayBefore":''
                                    };
            var eventScheduling = {
                                    "timeZone":'',
                                    "schedulingOption": '', //send now, send on specific date, automatic scheduling
                                    "sendOnSpecificDate": '', //Date
                                    "automaticScheduling": {
                                        "startDate": '', // same as event start date
                                        "endDate": '',
                                        "recurrenceType":'',
                                        "sendEmailOn": ''
                                    }
                                };

            var eventInfo = {
                                eventDetails: {
                                                eventCategory: '',
                                                eventDescription: '',
                                                eventEndDate: '',
                                                eventEndTime: '',
                                                eventLocation: '',
                                                eventName: '',
                                                eventStartDate: '',
                                                eventStartTime: '',
                                                needRsvp: ''
                                              },
                                eventRecursion: {
                                                    endDate: '',
                                                    occation: '',
                                                    sendon: '',
                                                    group: ''
                                                },
                                guestReplyOptions: {
                                                    kidsNumber: '',
                                                    remindEvent: '',
                                                    totalGuestsLimit: ''
                                                   },
                                myReplyOptions: {
                                                    hideComments: '',
                                                    hideGuestList: '',
                                                    knowMeOnGuestsComment: '',
                                                    knowMeOnGuestsRsvp: '',
                                                    knowMeOnGuestsView: ''
                                                },
                                schedulingOption: {
                                                    schedule: '',
                                                    timeZone: '',
                                                    scheduleSend: true,
                                                    scheduleSpecific: false,
                                                    scheduleRepeat: false
                                                  }
                            };

            return {
                getEventDetails: function(){
                    return eventInfo;
                },
                setEventDetails: function(data1){
                    var data = angular.copy(data1);
                    eventInfo.eventDetails.eventCategory = data.eventDetails.eventCategory;
                    eventInfo.eventDetails.eventDescription = data.eventDetails.eventDescription;
                    eventInfo.eventDetails.eventEndDate = data.eventDetails.eventEndDate;
                    eventInfo.eventDetails.eventEndTime = data.eventDetails.eventEndTime;
                    eventInfo.eventDetails.eventLocation = data.eventDetails.eventVenue;
                    eventInfo.eventDetails.eventName = data.eventDetails.eventTitle;
                    eventInfo.eventDetails.eventStartDate = data.eventDetails.eventStartDate;
                    eventInfo.eventDetails.eventStartTime = data.eventDetails.eventStartTime;
                    eventInfo.eventDetails.needRsvp = Boolean(parseInt(data.eventDetails.enableRSVP));

                    eventInfo.eventRecursion.endDate = data.scheduleInfo.recurrentTillDate;
                    eventInfo.eventRecursion.occation = data.scheduleInfo.recurrentFrequency;
                    eventInfo.eventRecursion.sendon = data.scheduleInfo.recurrentSendBeforeInDays;
                    eventInfo.eventRecursion.group = data.scheduleInfo.recurrentGroupID;

                    eventInfo.guestReplyOptions.kidsNumber = Boolean(parseInt(data.eventSettings.kidsAllowed));
                    eventInfo.guestReplyOptions.remindEvent = Boolean(parseInt(data.eventSettings.reminderEnable));
                    eventInfo.guestReplyOptions.totalGuestsLimit = data.eventSettings.totalGuests;

                    eventInfo.myReplyOptions.hideComments = Boolean(parseInt(data.eventSettings.commentsHidden));
                    eventInfo.myReplyOptions.hideGuestList = Boolean(parseInt(data.eventSettings.guestListHidden));
                    eventInfo.myReplyOptions.knowMeOnGuestsComment = Boolean(parseInt(data.eventSettings.notifyOnComment));
                    eventInfo.myReplyOptions.knowMeOnGuestsRsvp = Boolean(parseInt(data.eventSettings.notifyOnRSVP));
                    eventInfo.myReplyOptions.knowMeOnGuestsView = Boolean(parseInt(data.eventSettings.notifyOnGuestView));

                    eventInfo.schedulingOption.schedule = data.eventDetails.scheduledOption;
                    eventInfo.schedulingOption.timeZone = data.eventDetails.eventTimezoneOffset;
                }
            }
        }]);
});