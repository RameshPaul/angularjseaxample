define(['angular'], function(angular){
    var analytics = angular.module('Inwiter.analytics', []);

    analytics.controller("AnalyticsCtrl", ['$scope', '$rootScope', function($scope, $rootScope){

    }]);
});