define([
    'angular'
],

function (angular) {

    return angular.module('Inwiter.Header', []);

});