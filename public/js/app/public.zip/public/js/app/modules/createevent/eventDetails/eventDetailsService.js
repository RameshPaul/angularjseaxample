define([
    'angular'
],
function (angular) {
    var eventDetails = angular.module('Inwiter.CreateEvent.EventDetails');

    eventDetails.factory("EventDetailsService",['Restangular', 'AuthService', function(Restangular, Auth){

        return {
            getEventCategories: function(){
                return Restangular.one('events');
            },
            getLocation: function(location){

            },
            getUTCEquivalentDate: function(){
                return Restangular.one('utcdate');
            }
        }
    }]);
});