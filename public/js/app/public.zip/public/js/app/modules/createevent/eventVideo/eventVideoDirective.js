define([
    'angular'
],
function(angular){
    var eventVideo  = angular.module("Inwiter.CreateEvent.EventVideo");
    eventVideo.directive("flowFileAdded",[function(){
        return{
            restrict: 'A',
            link: function(scope, element, attrs){
                console.log("directive file added");
            }
        }
    }]);
    eventVideo.directive("uploadVideoModal",[function(){
        return{
            restrict: 'A',
            link: function(scope, element, attrs){
                scope.$on("closeUploadVideoModal", function(){
                    jQuery("#upload-video-modal").modal('hide');
                });

                jQuery("#upload-video-modal").on("hide.bs.modal", function(){
                    scope.$broadcast("uploadClosed");
                });
            }
        }
    }]);
});