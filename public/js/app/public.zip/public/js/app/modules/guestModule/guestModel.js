define([
    'angular'
], function(angular){
    var guest = angular.module("Inwiter.GuestModule");
});