define([
        'angular',
        'createEvent'
],
function (angular) {
var inwiterApp = angular.module('Inwiter.CreateEvent');
    console.log(inwiterApp);
    if(inwiterApp.register != undefined){
        inwiterApp = inwiterApp.register;
    }
    inwiterApp.controller('CreateEventCtrl', ['$scope', '$location', '$rootScope', '$injector', 'LazyLoadService', 'UserAuth', 'EventService', 'CreateEventModel', '$state', 'UtilityService', '$window', '$timeout', '$stateParams', 'CreateEventService', 'UserModel', 'EventDetailsModel', 'EventGuestListModel', 'EventVideoModel', 'EventThemeModel', function ($scope, $location, $rootScope, $injector, LazyLoad, UserAuth, EventService, CreateEventModel, $state, Utility, $window, $timeout, $stateParams, CreateEventService, UserModel, EventDetailsModel, EventGuestListModel, EventVideoModel, EventThemeModel) {
            $scope.isActive = function(route) {
                return route === $location.path();
            };
            //var eventDetails = {createEvent: {"eventDetails":{"userID":100098,"eventID":1230,"enableRsvp":1,"scheduledOption:":"0","eventEndDate":"2014-06-16","eventEndTime":"18:00","eventScheduledDate":"2014-06-16","eventScheduledTime":"10:00","eventStartDate":"2014-06-16","eventStartTime":"12:00","Browser":"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.114 Safari/537.36","eventCategory":"Birthday","eventDescription":"Please come and enjoy the party","deviceType":"0","eventGuestThemeURL":"usermedia/guestpagetheme/Theme1.jpg","eventHostEmail":"madhu54108@gmail.com","eventHostName":"Madhu","laguageCode":"en","eventStatus":"SB","eventTimezoneOffcet":"+05:30","eventTitle":"My Birthday Party","eventType":"Invitation","eventVenue":"Hyderabad","videoFileURL":"usermedia/100098/videofile.mp4","videoThumbURL":"usermedia/100098/videofile.jpg"},"eventSettings":{"enable":"TRUE","totalGuest":2,"kidsAllowed":"FALSE","guestListHidden":"FALSE","notifyOnRsvp":"FALSE","notifyOnComment":"FALSE","notifyOnGuestView":"FALSE"},"eventRemider":{"enable":"TRUE","reminderTime":"10:00","reminderDate":"2014-06-15"},"eventGuestList":[{"name":"Madhu","email":"mkudala@inwiter.com"},{"name":"Ramesh","email":"rchatragadda@inwiter.com"}],"scheduledInfo":{"type":"","sheduled":{"date":""},"repete":{"type":"","tilDate":"","scheduledBefore":""},"group":{}},"videoTimeline":{"type":"","upload":{"file":""},"create":{}}}};

            var Auth = {};
            var saveDraftCount = 0;
            var eventID = '';

            $rootScope.userModel = UserModel.getUser();

            console.log("Resolver function", UserAuth);

            var previewTab = '';

            /** Event edit  **/
            $rootScope.isEdit = false;
            $rootScope.eventAction = 'new';
            $rootScope.userType = $rootScope.userModel.userType;


            $rootScope.userGroups = [];

            /** validation root scopes **/
            $rootScope.isCreateEventValid = false;


        $scope.selectedOption = '';

        $scope.templates = {
            eventDetails: {name: 'eventDetailsTpl.html', url : '/public/js/app/modules/createEvent/eventDetails/eventDetailsTpl.html'},
            eventContacts: {name: 'eventContactsTpl.html', url : '/public/js/app/modules/createEvent/eventContacts/eventContactsTpl.html'},
            eventVideo: {name: 'eventVideoTpl.html', url : '/public/js/app/modules/createEvent/eventVideo/eventVideoTpl.html'},
            eventTheme: {name: 'eventThemeTpl.html', url: '/public/js/app/modules/createEvent/eventThemes/eventThemeTpl.html'}
        };


        /**
         *  EDIT EVENT OR COPY EVENT
         */
            var urlParameters = $stateParams;
            var urlEventAction = urlParameters.action;
            var urlEventID = urlParameters.eventID;
            console.log("State params",urlParameters, urlEventAction, urlEventID);
            if((!angular.isUndefined(urlEventAction)) && (!angular.isUndefined(urlEventID))){
                console.log((urlEventAction == 'edit') || (urlEventAction == 'copy'));
                if((urlEventAction == 'edit') || (urlEventAction == 'copy')){
                    console.log(angular.isNumber(urlEventID));
                    $rootScope.isEdit = true;
                    $rootScope.eventAction = urlEventAction;
                }
            }

            console.log($rootScope.isEdit, $rootScope.eventAction);
            console.log("URL PATH-"+$location.path());
            if($rootScope.isEdit){
                CreateEventService.getEventDetails(urlEventID).get().then(function(response){
                    console.log(response.data);
                    if(response.status.toUpperCase() == 'SUCCESS'){
                        identifyEvent(response.data);
                    }else{
                        $state.go('404');
                    }
                });
            }else{
                //loadRemainingModules();
            }

            function loadAllTemplates(){
                $scope.eventDetailsTemplate = $scope.templates.eventDetails;
                $scope.eventContactsTemplate = $scope.templates.eventContacts;
                $scope.eventVideoTemplate = $scope.templates.eventVideo;
                $scope.eventThemeTemplate = $scope.templates.eventTheme;

                $scope.eventDetailsModel = EventDetailsModel;
                $scope.eventGuestListModel = EventGuestListModel;
                $scope.eventVideoModel = EventVideoModel;
                $scope.eventThemeModel = EventThemeModel;
            }
            loadAllTemplates();


            function identifyEvent(response){
                var respEventID = response.eventDetails.eventID;
                var respUserID = response.eventDetails.userID;
                if((respEventID == urlEventID) && (respUserID == $rootScope.userModel.userID)){
                    //USER IS VALID AND EVENT IS COPY OR EDIT
                    eventID = respEventID;
                    if(urlEventAction == 'edit'){
                        saveDraftCount = 1;
                    }
                    CreateEventModel.setEventDetails(response.eventDetails);
                    CreateEventModel.setEventSettings(response.eventSettings);
                    getScheduleInfo(respEventID);
                    //loadRemainingModules();
                    //console.log("State", $state);
                }else{
                    //USER IS NOT VALID REDIRECT TO HOME PAGE
                    $state.go('404');
                }
            }

            function getScheduleInfo(eventID){
                console.log(CreateEventService.getScheduleInfo(eventID));
                CreateEventService.getScheduleInfo(eventID).get().then(function(response){
                    console.log(response);
                    if(response.status.toUpperCase() == 'SUCCESS'){
                        CreateEventModel.setEventScheduleInfo(response.data.scheduledInfo);
                        getEventContactsData(eventID);
                    }else{
                        console.log("Error occurred on get Schedule info");
                    }
                });
            }

            function getEventContactsData(eventID){
                CreateEventService.getEventGuestList(eventID).get().then(function(response){
                    console.log(response);
                    if(response.status.toUpperCase() == 'SUCCESS'){
                        CreateEventModel.setEventContacts(response.data.eventGuestList);
                        getEventVideo(eventID);
                    }else{
                        console.log("Get contacts failed");
                    }
                });
            }

            function getEventVideo(eventID){
                CreateEventService.getEventVideo(eventID).get().then(function(response){
                    console.log(response);
                    if(response.status.toUpperCase() == 'SUCCESS'){
                        CreateEventModel.setEventVideo(response.data.videoTimeline);
                        loadRemainingModules();
                    }else{
                        console.log("Error occurred on get Event Video");
                    }
                });
            }


            /** Init lazy loading of create event module**/
            function loadRemainingModules(){
                LazyLoad.createEvent.textEditor().then(function(){
                    loadGoogleMapHelper();
                });
            }

            function loadGoogleMapHelper(){
                //LazyLoad.createEvent.googleAddressLocation().then(function(){
                    loadEventDetails();
                //});
            }

            function loadEventDetails(){
                LazyLoad.createEvent.eventDetails(function(){
                    $scope.eventDetailsTemplate = $scope.templates.eventDetails;
                    EventDetailsModel = $injector.get('EventDetailsModel');
                    $scope.eventDetailsModel = EventDetailsModel;
                    //load contacts module
                    $timeout(function() {
                        loadUploadModule();
                    }, 1000);

                });
            }

            function loadUploadModule(){
                LazyLoad.createEvent.eventVideoDependencies('fileUpload').then(function() {
                  loadEventContacts();
                });
            }

            function loadEventContacts(){
                LazyLoad.createEvent.eventContacts().then(function(){
                    $scope.eventContactsTemplate = $scope.templates.eventContacts;
                    EventGuestListModel = $injector.get('EventGuestListModel');
                    $scope.eventGuestListModel = EventGuestListModel;
                    //Load video module
                    $timeout(function(){
                        loadEventVideoModuleDependencies();
                    }, 1000);
                })
            }

            function loadEventVideoModuleDependencies(){
                //LazyLoad.createEvent.eventVideoDependencies('fileUpload').then(function(){
                    //LazyLoad.createEvent.eventVideoDependencies('timer').then(function(){
                        $timeout(function(){
                            loadEventVideoModule();
                        }, 1000);
                    //});
                //});
            }

            function loadEventVideoModule(){
                LazyLoad.createEvent.eventVideo().then(function(){
                    $scope.eventVideoTemplate = $scope.templates.eventVideo;
                    EventVideoModel = $injector.get('EventVideoModel');
                    $scope.eventVideoModel = EventVideoModel;
                    $timeout(function(){
                        loadEventThemeModule();
                    }, 1000);
                });
            }

            function loadEventThemeModule(){
                //LazyLoad.createEvent
                LazyLoad.createEvent.eventTheme().then(function(){
                    $scope.eventThemeTemplate = $scope.templates.eventTheme;
                    EventThemeModel = $injector.get('EventThemeModel');
                    $scope.eventThemeModel = EventThemeModel;
                });
            }

            /**
             *  VALIDATE FOR UTC DATE
             */
            $scope.validateUTCDate = function(){
                var timeZone = $rootScope.totalEventDetails.schedulingOption.timeZone;
                var date = $rootScope.totalEventDetails.eventDetails.eventStartDate;
                var time = $rootScope.totalEventDetails.eventDetails.eventStartTime;
                var dateJSON = {"timeZone":timeZone,"date":Utility.fullDate(date),"time": Utility.fullTime24(time)};
                console.log(dateJSON);
                var json = Utility.objectToRequestData({"validateData": JSON.stringify(dateJSON)});
                var xhr = Utility.validateUTCDate().customPOST(json);
                return xhr;
            };

            /**
             * Watcher for form validation
             */
            $rootScope.$on("onFormValidationComplete", function(event, data){
                console.log("form validation complete event", data);
                if(data.target == 'save'){
                    $scope.saveDraft();
                }else if(data.target == 'create'){
                    $scope.sendEvent();
                }else if(data.target == 'preview'){
                    $scope.previewEvent();
                }
            });

            /**
             * Save draft event functionality
             * If event allready exists request is POST else request is CUSTOMPUT
             */
            $scope.saveDraft = function(){
                if($rootScope.isCreateEventValid){
                    var target = 'save';
                    var eventDetails = collectEventData(target);
                    console.log(eventDetails);
                    createEventSend(eventDetails, target);
                }
            };

            /**
             * Cancel event functionality
             * Check if event exists in the list and then send CUSTOMDELETE
             */
            $scope.cancelEvent = function(){
                var target = 'cancel';
                var eventDetails = collectEventData(target);
                console.log(eventDetails);
                createEventSend(eventDetails, target);
            };

            /**
             * Preview event functionality
             * Send POST request and navigate to Preview page
             */
            $scope.previewEvent = function(){
                var target = 'preview';
                var eventDetails = collectEventData(target);
                console.log(eventDetails);
                createEventSend(eventDetails, target);

            };

            /**
             * Send event functionality
             * Send POST request and navigate to Thank you page
             */
            $scope.sendEvent = function(){
                if($rootScope.isCreateEventValid) {
                    var target = 'create';
                    var eventDetails = collectEventData(target);
                    console.log(eventDetails);
                    createEventSend(eventDetails, target);
                }
            };

            function createEventSend(eventDetails, target){
                var filter = {
                                "JSONData": encodeURIComponent(JSON.stringify(eventDetails)),
                                "eventCreationType": eventDetails.eventCreationType,
                                "eventID": eventID
                             };
                var formData = Utility.objectToRequestData(filter);
                console.log(formData);
                console.log("form data sent is ", filter, saveDraftCount);
                if(saveDraftCount == 0){
                    EventService.customPUT(formData).then(function(res){
                        console.log(res);
                        createEventSuccess(res, target);
                    },errorResponse);
                }else{
                    EventService.customPOST(formData).then(function(res){
                        console.log(res);
                        createEventSuccess(res, target);
                    },errorResponse);
                }
                saveDraftCount = 1;
            }

            function createEventSuccess(res, target){
                console.log("in create event success", res);
                if (res.status.toUpperCase() == 'SUCCESS') {
                    $rootScope.$emit("showInfoBar", res);
                    console.log(target);
                    if(target == 'create'){
                        console.log("in target");
                        //window.location = '/createevent.thankyou';
                        $state.go('createeventthankyou');
                    }else if(target == 'preview'){
                        eventID = res.data.eventID;
                        previewTab = $window.open(res.data.guestURL, '_blank');
                    }else{
                        eventID = res.data.eventID;
                    }
                }else{
                    $rootScope.$emit("showInfoBar", res);
                }
            }

            function validateDates(date){
                //var data = Utility.
            }

            /**
             * Handle error responses
             * @param error {{}}
             */
            function errorResponse(error){
                console.log("on error");
                console.log(error);
                $rootScope.$emit("showInfoBar", error);
            }

            /**
             * Handle Create event success result
             * @param result {{}}
             */
            function onCreateEventSuccess(result){
                console.log("on success");
                console.log(result);
                //NAVIGATE TO THANK YOU PAGE

            }

            function onPreviewEventSuccess(response){
                console.log(response);
                //NAVIGATE TO PREVIEW PAGE

            }

            /**
             * To collect whole event data from create event model
             */
            function collectEventData(flag){
                //return CreateEventModel.getEventModel();
                var totalData = $rootScope.totalEventDetails;
                    totalData.videoTimeline = EventVideoModel.getVideoTimeLineQueue()[0];//{"videoFile":"","videoThumb":"","duration":""},//$rootScope.videoTimelineData;
                    totalData.guestList = EventGuestListModel.getGuestList();//[{"name":"","email":""}],//$rootScope.guestListData;
                    totalData.background = EventThemeModel.getEventBackgroundTheme();//{"backgroudURL":""};
                    totalData.eventStatus = flag;
                    totalData.eventID = eventID;
                var eventDetails = CreateEventModel.formJSON(totalData);
                console.log(eventDetails);
                return eventDetails;
            }

            /**
             * In case of edit invoke this function
             * to auto fill all create event data
             */
            function edit(){
                CreateEvent.getList().then(function(events){
                    console.log(events);
                },errorResponse);
            }

            $scope.send = function(){
                saveDraft();
            };

            //console.log($state);

            /** Enable disable event controls **/
            $rootScope.enableSaveDraft = true;
            $rootScope.enablePreview = true;
            $rootScope.enableSendNow = true;
            $rootScope.isBusinessUser = true;

        }]);
});
