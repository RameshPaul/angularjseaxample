define([
        'angular'
],

function (angular) {
    /**
     * Create event module
     * By default it loads event details
     * Based on the user interaction load the necessary modules
     */
    return angular.module('Inwiter.CreateEvent', [
                                'Inwiter.CreateEvent.EventDetails',
                                'Inwiter.CreateEvent.EventContacts',
                                'Inwiter.CreateEvent.EventVideo',
                                'Inwiter.CreateEvent.EventTheme'
                             // 'mgcrea.ngStrap',
                              //'textAngular'
                        ]);

});
