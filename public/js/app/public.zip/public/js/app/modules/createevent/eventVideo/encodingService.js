define([
    'angular'
],
function(angular){
    var sse = angular.module("Inwiter.CreateEvent.EventVideo");
    sse.factory("EncodingService",['Restangular', 'AuthService', 'UtilityService', function(Restangular, Auth, Utility){
        var source;
        var timer;
        var isEncodingCancel = false;

        var counts = 10;
        var iterations = 0;

        /** Event Polling **/
            //event polling

        function addEncodingJob(data){
            if(!isEncodingCancel) {
                var request = Restangular.service('encode', Restangular.one('user', Auth.currentUserId()));
                var reqData = Utility.objectToRequestData(data);
                console.log(reqData);
                request.post(reqData).then(function (response) {
                    var res = response;
                    console.log(res);
                    if(!isEncodingCancel) {
                        if (res.status.toUpperCase() === 'SUCCESS') {
                            if (res.data.jobID != '') {
                                setTimeout(function(){
                                    trackEncodingJob(res.data);
                                }, 1000);
                            } else {
                                encodeError(res);
                            }
                        }
                    }
                }, function (error) {
                    console.log(error);
                    encodeError(error);
                });
            }
        }

        function trackEncodingJob(data){
            var totaltime = 1;
            // Make ajax request every 10 sec to get encoding status
            var timeInterval = 2000;
            var timeLimit = 600000;
            //var timer = setInterval(loopEncodingJob, timeInterval);

            function loopEncodingStatus(){
                if(!isEncodingCancel) {
                    totaltime = totaltime + timeInterval;
                    if (totaltime <= timeLimit) {
                        var request = Restangular.service('encode', Restangular.one('user', Auth.currentUserId())).one();
                        request.get(data).then(function (response) {
                            console.log(response);
                            var res = response;
                            console.log(res);
                            if ((res.status.toUpperCase() === 'SUCCESS') && !(isEncodingCancel)) {
                                var flag = (res.data.jobStatus).toUpperCase();
                                console.log(flag);
                                switch (flag) {
                                    case 'INQUEUE' :
                                        timer = setTimeout(loopEncodingStatus, timeInterval);
                                        break;
                                    case 'SUCCESS' :
                                        clearTimeout(timer);
                                        encodeSuccess(res.data, res.absolutePath);
                                        break;
                                    case 'ERROR' :
                                        clearTimeout(timer);
                                        encodeError(data);
                                        break;
                                    default  :
                                        clearTimeout(timer);
                                        encodeError(data);
                                        break;
                                }
                            }
                        }, function (error) {
                            encodeError(error);
                        });
                    } else {
                        var error = {"status": 'error', "description": "Server is busy not responding"};
                        encodeError(error);
                    }
                }
            }

            if(!isEncodingCancel) {
                loopEncodingStatus();
            }
        }

        function encodeSuccess(data, replacePath){
            console.log("encode success");
            console.log(data);
            service.success(data, replacePath);
        }

        function encodeError(data){
            console.log("encode error");
            service.error(data);
        }

        var service = {
            addJob: function(data, success, error){
                        isEncodingCancel = false;
                        clearTimeout(timer);
                        service.success = success;
                        service.error = error;
                        addEncodingJob(data);
                    },
            cancelJob: function(){
                        isEncodingCancel = true;
                        clearTimeout(timer);
                    }
            };

        return service;

    }]);


});