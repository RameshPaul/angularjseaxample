define([
    'angular'
], function(angular){
    angular.module("Inwiter.Dashboard", []);
});