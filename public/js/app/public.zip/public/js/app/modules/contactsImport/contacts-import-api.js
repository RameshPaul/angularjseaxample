/*
 *  * contacts-import-api v0.0.1
 *   * ♡ Written by Ramesh Babu for inviter
 *    * import contacts js wrapper for cloudsponge api - http://www.cloudsponge.com/
 *     */
define([
    'angular'
], function(angular){
    'use strict';
var importContacts = angular.module('Inwiter');
    if(importContacts.register != undefined){
        importContacts = importContacts.register;
    }

importContacts.factory("ContactsImporterService", ['$http', '$rootScope', 'ContactsService', function($http, $rootScope, ContactsService){
            console.log("contacts import service loaded");
            var newPopup;
            var emailsObj=[];
            var permissionResponse;
            var permissionCount=0;
            var permissionCountLimit = 20;
            var popupTimer;
            var winliveData;
            var importContacts = {
                url : '/importcontacts/',
                popup : '/importcontacts/popup/',
                getImportId : '/importcontacts/getimportid/',
                getStatus : '/importcontacts/permission/',
                import : '/importcontacts/import/'
            };

            var contactsImportId = 0;

            /**
             * Open popup window to initiate import
             * @param service
             * @param callback
             */
            function open_popup(service, callback) {
                var url = importContacts.popup+service;
                var popup_height = '300';
                var popup_width = '500';

                if (service == 'yahoo') {
                    popup_height = '500';
                    popup_width = '500';
                } else if (service == 'gmail') {
                    popup_height = '600';
                    popup_width = '987';
                } else if (service == 'windowslive') {
                    popup_height = '600';
                    popup_width = '987';
                } else if (service == 'aol' || service == 'plaxo') {
                    popup_height = '600';
                    popup_width = '987';
                }

                newPopup = window.open(url, "_blank");
                _hasPopupClosed(service);
            }

            /**
             * Checks whether popup is closed or not
             * @param service
             * @private
             */
            function _hasPopupClosed(service)
            {
                popupTimer = setInterval(function(){
                    if(newPopup.closed) {
                        console.log("popup closed"+service);
                        if(service == 'windowslive')
                        {
                            try{
                                var res = JSON.parse(winliveData);
                                var importId = res.result.import_id;
                                console.log("at popupclosed");
                                getContactsImportId();
                                clearInterval(popupTimer);
                            }
                            catch(e)
                            {
                                clearInterval(popupTimer);
                                var err = {'error':'Import failed','description':'Import canceled'};
                                throughError(err);
                                return false;
                            }
                        }
                        else
                        {
                            clearInterval(popupTimer);
                            getContactsImportId();
                            //var err = {'error':'Import failed','description':'Import canceled'};
                            //throughError(err);
                            return true;
                        }
                    }
                    else
                    {
                        return true;
                    }
                },0);
            }


            /**
             * Start collecting
             * @param result
             * @returns {boolean}
             */
            window.startCollection = function(result)
            {
                console.log("in parent window call");
                getContactsImportId();
                return true;
            };

            /**
             * Get importid of contacts import to start importing contacts
             */
            function getContactsImportId(){
                $http.get(importContacts.getImportId).success(function(response){
                    contactsImportId = response.import_id;
                    getContactsPermission(0);
                },httpError);
            }

            /**
             * Check contacts status
             * @returns {boolean}
             */
            function getContactsPermission()
            {
                var importId = contactsImportId;
                if(permissionCount > permissionCountLimit)
                {
                    permissionCount=0;
                    console.log("maximum contacts access excceded");
                    var err = {'error':'Import failed','description':'Maximum contacts access excceded'};
                    throughError(err);
                    return false;
                }
                else{
                    //console.log("at contact status "+importId);
                    $http.get(importContacts.getStatus+importId).success(function(response){
                        permissionCount=permissionCount+1;
                        console.log(response);
                        //timeOut = setTimeout(function(){getContactsResp(importId,response);},5000);
                        getContactsResp(importId, response);
                    }, httpError);

                }
            }

            /**
             * Http error handler
             * @param error
             */
            function httpError(error){
                clearInterval(popupTimer);
                var err = {'error':'Import failed','description':'authentication failed '+error};
                throughError(err);
            }

            /**
             * handle contacts status response
             * @param importId
             * @param res
             */
            function getContactsResp(importId,res)
            {
                if(res.status.toUpperCase() === 'SUCCESS') {
                    var resdata = res.data;
                    permissionResponse = resdata;
                    var lnt = resdata.length;

                    if (lnt > 0) {
                        var status = resdata[lnt - 1].status;
                        console.log(status);
                        if (status == 'COMPLETED') {
                            getImportedContacts(importId);
                        }
                        else if (status == 'INPROGRESS') {
                            getContactsPermission();
                        }else{
                            var err = {'error': 'Import failed', 'description': resdata[lnt-1].description};
                            throughError(err);
                        }
                    }else {
                        var err = {'error': 'Import failed', 'description': 'Import failed at getting response'};
                        throughError(err);
                    }
                }else{
                    console.log("An unexpected error occured :- " + res);
                    var err = {'error': 'Import failed', 'description': 'Import failed at initializing'};
                    throughError(err);
                }
            }

            /**
             * Import contacts from server when they are ready
             * @param importId
             */
            function getImportedContacts(importId)
            {
                $http.get(importContacts.import+importId).success(function(response){
                    //console.log(response);
                    getEmails(response);
                }, httpError);
            }

            /**
             * Get emails and arrage formet
             * @param Obj
             */
            function getEmails(Obj)
            {
                if(Obj.status.toUpperCase() === 'SUCCESS') {
                    emailsObj = [];
                    console.log(Obj);
                    var res = Obj.data;
                    var lnt = res.length;
                    //console.log(" contacts lenght"+ lnt);

                    for (var i = 0; i < lnt; i++) {
                        //console.log(i);
                        var name = res[i].first_name + " " + res[i].last_name;
                        if (res[i].emails.length > 0) {
                            var email = res[i].emails[0].value;
                            var contacts = {
                                id: i,
                                email: email,
                                name: name,
                                selected: false
                            };
                            emailsObj.push(contacts);
                        }
                    }
                    importEmail();
                }else{
                    console.log("An unexpected error occured :- " + res);
                    var err = {'error': 'Import failed', 'description': 'Contacts import failed'};
                    throughError(err);
                }
            }

            /**
             * callback to import return
             */
            var importResponse = function(){};
            function importEmail()
            {
                //contactsAPI.importContacts(emailsObj);
                //return emailsObj;
                $rootScope.$broadcast("contactsLoadSuccess", emailsObj);
                //importer.success(emailsObj);
                importResponse(emailsObj);
            }

            /**
             * raise error to user
             * @param err
             */
            function throughError(err)
            {
                $rootScope.$broadcast("contactsLoadError", err);
                //importer.error(err);
            }


            /**
             *  IMPORT CSV CONTACTS
             *
             */
            function importCSV(data, callback){
                var formData = "CSVFilePath="+ data.file;
                ContactsService.importCSVContacts().customPOST(formData).then(function(response){
                    console.log(response);
                    if(response.status.toUpperCase() == 'SUCCESS'){
                        importCSVResponse(response.data);
                    }
                }, function(err){
                    console.log(err);
                    throughError({description: 'CSV Import contacts failed'});
                });
            }

            function importCSVResponse(response){
                var lnt = response.length;
                    emailsObj = [];
                for(var i=0; i< lnt; i++){
                    var name = response[i].firstName+' '+response[i].lastName;
                    var email = response[i].email;
                    var contacts = {
                                    id: i,
                                    email: email,
                                    name: name,
                                    selected: false
                                   };
                    emailsObj.push(contacts);
                }

                importEmail();
            }

            /**
             *  INWITER CONTACTS
             */
            function inwiterGroupContacts(groupID, limits){
                var filter = limits;//{intStartLimit: 0, intEndLimit: 10};
                ContactsService.getGroupContacts(groupID).get().then(function(response){
                    console.log(response);
                    if(response.status.toUpperCase() == 'SUCCESS'){
                        inwiterGroupContactsSuccess(response.data.groupContacts);
                    }else{
                        throughError(response);
                    }
                },throughError);
            }

            function inwiterGroupContactsSuccess(response){
                var lnt = response.length;
                emailsObj = [];
                for(var i=0; i< lnt; i++){
                    var name = response[i].userContact.firstName+' '+response[i].userContact.lastName;
                    var email = response[i].userContact.email;
                    var contacts = {
                        id: i,
                        email: email,
                        name: name,
                        selected: false
                    };
                    emailsObj.push(contacts);
                }

                importEmail();
            }

            function inwiterGroups(callback){
                ContactsService.getGroups().get().then(function(response){
                    console.log(response);
                    if(response.status.toUpperCase() == 'SUCCESS'){
                        callback(response.data.userGroups);
                    }
                });
            }

            function inwiterAllContacts(limits){
                ContactsService.getContacts().get(limits).then(function(response){
                    console.log(response);
                    if(response.status.toUpperCase() == 'SUCCESS'){
                        inwiterAllContactsSuccess(response.data.userContactList);
                    }else{
                        throughError(response);
                    }
                }, throughError);
            }

            function inwiterAllContactsSuccess(response){
                console.log(response);
                var lnt = response.length;
                    emailsObj = [];
                for(var i=0; i< lnt; i++){
                    var name = response[i].firstName+' '+response[i].lastName;
                    var email = response[i].email;
                    var contacts = {
                        id: i,
                        email: email,
                        name: name,
                        selected: false
                    };
                    emailsObj.push(contacts);
                }

                importEmail();
            }

            //GLOBALS
            var selectedEmails = [];
            $rootScope.showImportView = true;

            /**
             * Importer public methods
             * @type {{init: "init", importContacts: "importContacts", getContacts: "getContacts", getSelectedContacts: "getSelectedContacts", setSelectedContacts: "setSelectedContacts"}}
             */
            var importer = {
                    init: function(successCallback, errorCallback){
                        importer.success = successCallback;
                        importer.error = errorCallback;
                    },
                    importContacts: function(service){
                        importer.resetContacts();
                        open_popup(service);
                    },
                    getContacts: function(){
                        return emailsObj;
                    },
                    resetContacts: function(){
                        emailsObj = [];
                        selectedEmails = [];
                        $rootScope.$broadcast("resetModel");
                        console.log("in modal reset contacts");
                    },
                    getSelectedContacts: function(){
                        return selectedEmails;
                    },
                    setSelectedContacts: function(items){
                        selectedEmails = items;
                    },
                    importService: function(service){
                        $rootScope.showImportView = true;
                        importer.importContacts(service);
                    },
                    cancelImport: function(){
                        console.log("serice cancel");
                        $rootScope.$broadcast("importContactsCancelEvent"); //Catch event any where needed
                        $rootScope.showImportView = false;
                    },
                    importSelectedContacts: function(){
                        $rootScope.$broadcast("importSelectedContacts", selectedEmails); //Catch event any where needed
                        $rootScope.showImportView = false;
                    },
                    close: function(){
                        //close import contacts
                    },
                    templateURL: function(){
                        return '/public/js/app/modules/contactsImport/contactsImportTpl1.html';
                    },
                    importResponse: function(callback){
                        importResponse = callback;
                    },
                    importCSVContacts: function(data, callback){
                        importCSV(data, callback);
                    },
                    getInwiterGroupContacts: function(groupID, limits){
                        inwiterGroupContacts(groupID, limits);
                    },
                    getInwiterGroups: function(callback){
                        inwiterGroups(callback);
                    },
                    getInwiterAllContacts: function(limits){
                        inwiterAllContacts(limits);
                    }

            };

            return importer;
    }]);

    importContacts.directive("socialContactsImportBtn", ['ContactsImporterService', function(ContactsImporterService){
            return{
                restrict: 'A',
                link: function(scope, element, attrs){
                    element.unbind("click");
                    element.bind("click", function(event){
                        scope.$broadcast("resetModel");
                        var type = attrs.socialContactsImportBtn;
                        console.log("import service click", type);
                        ContactsImporterService.resetContacts();

                        if(type !== 'none') {
                            scope.$broadcast("showLoadingBar");
                            if(type == 'csv'){
                                jQuery("#upload-csv-file").trigger('click');
                            }else if(type == 'inwiter'){
                                scope.$broadcast("loadInwiterContacts");
                                scope.$apply();
                            }else{
                                ContactsImporterService.importService(type);
                            }
                        }
                        jQuery("#launchImportContacts").modal('show');
                    });
                    scope.$watch("showImportView", function(value){
                        console.log("in watcher function");
                        console.log(value);
                        if(value === false){
                            jQuery("#launchImportContacts").modal('hide');
                        }
                    });

                    jQuery('#launchImportContacts').on('hide.bs.modal', function () {
                        console.log("modal hide");

                    });

                    ContactsImporterService.importResponse(function(data){
                        console.log("contacts loaded successfully", data);
                        scope.$broadcast("hideLoadingBar");
                    });


                }
            }
    }]);

    importContacts.directive("csvContactsImportBtn", ['ContactsImporterService', function(ContactsImporterService){
            return{
                restrict: 'A',
                link: function(scope, element, attr){

                }
            }
    }]);

    importContacts.directive("socialContactsImportDone", ['ContactsImporterService', function(ContactsImporterService){
            return{
                restrict: 'A',
                link: function(scope, element, attrs){
                    element.addClass('disabled');
                    element.unbind("click");
                    element.bind("click", function(){
                        console.log("import done directive");
                        scope.importSelectedOne();
                        jQuery("#launchImportContacts").modal('hide');
                    });

                    scope.$on("enableImportBtn", function(e, data){
                        if(data.status == 'show'){
                            element.removeClass('disabled');
                        }else{
                            element.addClass('disabled');
                        }
                    });
                }
            }
    }]);

    importContacts.directive("socialContactsImportCancel", ['ContactsImporterService', function(ContactsImporterService){
            return{
                restrict: 'A',
                link: function(scope, element, attrs){
                    element.unbind("click");
                    element.bind("click", function(){
                        console.log("in directive cancel");
                        jQuery("#launchImportContacts").modal('hide');
                        ContactsImporterService.cancelImport();
                    });
                }
            }
    }]);

    importContacts.directive("importContactsLoadingBar", [ function(){
        return{
            restrict: 'A',
            link: function(scope, element, attr){
                scope.$on("showLoadingBar", function(e, data){
                    console.log("show loading bar");
                   element.removeClass('hide');
                });

                scope.$on("hideLoadingBar", function(e, data){
                    console.log("hide loading bar");
                   element.addClass('hide');
                });
            }
        }
    }]);

    importContacts.directive("checkAllEmails", [function(){
        return function(scope, element, attrs) {

            element.bind("click", function(){
                console.log(scope.emails);
            });

            function selectAllEmails(){

            }

            function unSelectAllEmails(){

            }
        };
    }]);

    importContacts.controller("ContactsImporterCtrl", ['$scope', '$rootScope', 'ContactsImporterService', '$fileUploader', 'AuthService', 'uploadModuleURL', 'UtilityService', function($scope, $rootScope, ContactsImporterService, $fileUploader, Auth, uploadModuleURL, Utility){

            console.log("contacts import controller loaded");
            $rootScope.contactsImportTemplate = '/public/js/app/modules/contactsImport/contactsImportTpl.html';

            //Error global
            $scope.importError = {};
            $scope.importError.showError = false;
            $scope.importError.text = '';
            $scope.selectAllCheckBox= false;
            $scope.csvImport = {};
            $scope.csvImport.show = false;
            $scope.inwiterContacts = {
                                        groups: [],
                                        contacts: [],
                                        selectedGroup: '',
                                        model: {},
                                        enable: false,
                                        startLimit: 0,
                                        endLimit: 1000
                                     };



            //Catch event on contacts import failure
            $rootScope.$on("contactsLoadError", function(err){
                $scope.importError.showError = true;
                $scope.importError.text = 'Some error has been occurred';
            });

            //Catch event on contacts import success
            $rootScope.$on("contactsLoadSuccess", function(){
                updateModel();
                displayContacts();
            });

            function displayContacts(){
                if($scope.emails.length <= 0){
                    $scope.importError.text = 'No contacts to import';
                    $scope.importError.showError = true;
                }else{
                    $scope.importError.text = '';
                    $scope.importError.showError = false;
                }
            }
            //All emails to display MODEL
            $scope.emails = ContactsImporterService.getContacts();

            //Selected items MODEL
            $scope.selectedEmails = [];

            /**
             * toggle contact selection
             * @param id
             */
            $scope.toggleEventSelection = function toggleSelection(id) {
                var idx = $scope.selectedEmails.indexOf(id);

                var index = getEmailIndex(id);

                // is currently selected
                if (idx > -1) {
                    $scope.selectedEmails.splice(idx, 1);
                    $scope.emails[index].selected = false;
                }

                // is newly selected
                else {
                    $scope.selectedEmails.push(id);
                    $scope.emails[index].selected = true;
                }
                console.log($scope.selectedEmails);
                $scope.selectAllCheckBox = false;
                showHideImportBtn();
            };

            $scope.selectAllEmails = function(value){
                console.log("value -", value);
                if(!value){
                    $scope.selectAllCheckBox = true;
                    $scope.selectedEmails = [];
                    for(var i=0; i < $scope.emails.length; i++){
                        $scope.emails[i].selected = true;
                        $scope.selectedEmails.push($scope.emails[i].id);
                    }
                }else{
                    $scope.selectAllCheckBox = false;
                    for(var j=0; j < $scope.emails.length; j++){
                        $scope.emails[j].selected = false;
                    }
                    $scope.selectedEmails = [];
                }
                showHideImportBtn();
                console.log("selected emails all ", $scope.selectedEmails);
            };

            function getEmailIndex(val){
                for(var i=0; i<$scope.emails.length; i++){
                    var id = $scope.emails[i].id;
                    if(id == val){
                        return i;
                    }
                }
            }

            function showHideImportBtn(){
                var data;
                if($scope.selectedEmails.length > 0){
                    $scope.importError.showError = false;
                    data = {status: 'show'};
                }else{
                    data = {status: 'hide'};
                }
                $scope.$broadcast("enableImportBtn", data);
            }

            /**
             * Update model on change
             */
            function updateModel(){
                $scope.emails = ContactsImporterService.getContacts();
                console.log($scope.emails);
            }

            $scope.importSelectedOne = function(){
                console.log("in ctrl fun");
                var selEmails = parseSelectedEmails();
                ContactsImporterService.setSelectedContacts(selEmails);
                ContactsImporterService.importSelectedContacts();
            };

            function parseSelectedEmails(){
                var newEmails = [];
                for(var i=0; i<$scope.selectedEmails.length; i++){
                    newEmails.push($scope.emails[i]);
                }
                return newEmails;
            }

            $scope.$on("resetModel", function(){
                console.log("reset model ");
                $scope.csvImport.show = false;
                $scope.importError.showError = false;
                $scope.inwiterContacts.enable = false;
                $scope.selectedEmails = [];
                $scope.emails = [];
                showHideImportBtn();
                updateInwiterContacts();
                $scope.$apply();
            });


        /**
         * CSV UPLOAD
         * angularFileUpload
         */
        var uploader;
        $scope.uploader;
        $scope.uploadCSV = {};

        (function(){
            // create a uploader with options
            uploader = $scope.uploader = $fileUploader.create({
                scope: $scope,                          // to automatically update the html. Default: $rootScope
                headers: Auth.getHeaders(),
                //method: 'PUT',
                url: uploadModuleURL.apiPrefix+'user/'+Auth.currentUserId()+uploadModuleURL.uploadVideo,
                autoUpload: true,
                formData: [
                    {'uploadType': 'csv' }
                ],
                filters: [
                    function (item) {                    // first user filter
                        console.log(item);
                        //var vli = Utility.validateImage(item);
                        //return vli.val;
                        return true;
                    }
                ]
            });

            //AFTER ADDING FILE
            uploader.bind('afteraddingfile', function (event, item) {
                $scope.uploadCSV.show = true;
                // console.info('After adding a file', item);
                $scope.progressBarClass = '';
            });

            //WHEN ADDING FAILED
            uploader.bind('whenaddingfilefailed', function (event, item) {
                console.info('When adding a file failed', item);
                var data = {description: 'Please upload correct csv file'};
                uploadError(data);
            });

            //BEFORE UPLOAD
            uploader.bind('beforeupload', function (event, item) {
                //console.info('Before upload', item);
                beforeUpload();
            });

            //UPLOAD PROGRESS
            uploader.bind('progress', function (event, item, progress) {
                //console.info('Progress: ' + progress, item);
                uploadProgress();
            });

            //UPLOAD SUCCESS
            uploader.bind('success', function (event, xhr, item, response) {
                //console.info('Success', xhr, item, response);
                //uploader.clearQueue();
                $scope.progressBarClass = 'progress-bar-striped active';
                uploadSuccess(response);
            });

            uploader.bind('cancel', function (event, xhr, item) {
                //console.info('Cancel', xhr, item);
                $scope.progressBarClass = '';
                uploadCancel();
            });

            uploader.bind('error', function (event, xhr, item, response) {
                //console.info('Error', xhr, item, response);
                $scope.progressBarClass = '';
                uploadError(response);
            });

            uploader.bind('complete', function (event, xhr, item, response) {
                //console.info('Complete', xhr, item, response);
                //uploadComplete();
            });

        })();

        $scope.cancelUpload = function(){
            console.log("in cancel upload scope");
            $scope.isUploadCanceled = true;
            $scope.uploadCSV.show = false;
            clearUpload();
        };

        function clearUpload(){
            uploader.cancelAll();
            uploader.clearQueue();
        }

        function hideErrors(){
            $scope.uploadCSV.isError = false;
            $scope.importError.showError = false;
        }

        function beforeUpload(){
            hideErrors();
        }

        function uploadProgress(){

        }

        function uploadSuccess(res){
            console.log("in upload success ", res);
            $scope.uploadCSV.isUploaded = true;

            if(res.status.toUpperCase() === 'SUCCESS'){
                var data = {file: res.data.filePath};
                ContactsImporterService.importCSVContacts(data);
                clearUpload();
            }else{
                uploadError(res);
            }
        }

        function uploadError(err){
            $scope.importError.text = 'Unable to upload/process csv file please check the file';
            $scope.importError.showError = true;
        }

        function uploadCancel(){
            console.log("upload canceled");
        }

        /**
         *  INWITER CONTACTS
         */

        $scope.$on("loadInwiterContacts", function(e, data){
            console.log("load inwiter contacts");
            $scope.inwiterContacts.enable = true;
            $scope.getInwiterGroups();
        });

        $scope.$on("removeInwiterContacts", function(e, data){
            console.log("remove inwiter contacts");
        });

        $scope.changeInwiterGroup = function(groupID){
            hideErrors();
            if(groupID != ""){
                var limits = {intStartLimit: $scope.inwiterContacts.startLimit, intEndLimit: $scope.inwiterContacts.endLimit};
                ContactsImporterService.getInwiterGroupContacts(groupID, limits);
            }else{
                getAllContacts();
            }
        };

        $scope.getInwiterGroups = function(){
            updateInwiterContacts();
            ContactsImporterService.getInwiterGroups(function(data){
                console.log("inwiter groups loaded", data);
                $scope.inwiterContacts.groups = data;
                getAllContacts();
            });
        };

        function getAllContacts(){
            var limits = {intStartLimit: $scope.inwiterContacts.startLimit, intEndLimit: $scope.inwiterContacts.endLimit};
            ContactsImporterService.getInwiterAllContacts(limits);
        }

        function updateInwiterContacts(){
            $scope.inwiterContacts.groups = [];
            $scope.inwiterContacts.contacts = [];
        }

    }]);
    importContacts.value("uploadModuleURL",{"apiPrefix":"/api/","uploadVideo":"/upload/"});
 });