define(['angular'], function(angular){
    var eventTheme = angular.module('Inwiter.CreateEvent.EventTheme');
    eventTheme.factory("EventThemeModel", [function(){
        var backgroundTheme = {};
        return {
            setEventBackgroundTheme: function(theme){
                backgroundTheme = theme;
            },
            getEventBackgroundTheme: function(){
                return backgroundTheme;
            }
        }
    }]);
});