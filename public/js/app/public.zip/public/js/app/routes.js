define([
    'angular'
],

function (angular) {
    'use strict';

    var inwiterApp = angular.module('Inwiter');
    inwiterApp.config([
                        "$stateProvider",
                        "$urlRouterProvider",
                        "$locationProvider",
                        "RestangularProvider",
                        "$controllerProvider",
                        "$compileProvider",
                        "$filterProvider",
                        "$provide",
                    function(
                        $stateProvider,
                        $urlRouterProvider,
                        $locationProvider,
                        RestangularProvider,
                        $controllerProvider,
                        $compileProvider,
                        $filterProvider,
                        $provide
                        ){



        /**
         * Route Resolver configuration
         */
        var registerObject =  {
            controller: $controllerProvider.register,
            directive: $compileProvider.directive,
            filter: $filterProvider.register,
            factory: $provide.factory,
            service: $provide.service
        };

        //Register all modules here
        inwiterApp.register = registerObject;
        angular.module('Inwiter.CreateEvent').register = registerObject;
        angular.module("Inwiter.EventsLibrary").register = registerObject;
        angular.module("Inwiter.Dashboard").register = registerObject;
        angular.module("Inwiter.GuestModule").register = registerObject;
        angular.module("Inwiter.Contacts").register = registerObject;
        //angular.module("Inwiter.ProfileModule")

            //GLOBAL VARS
            var loadDepedencies = {};

            // initialize REST api base url
            RestangularProvider.setBaseUrl('/api');

            // user html5 mode
            $locationProvider.html5Mode(true);

            // unmatched URLs
            $urlRouterProvider.otherwise("/404");

            //Define routes - controllers will be loaded dynamically
            //var route = routeResolverProvider.route;
            //console.log(route);

            // set routes
            $stateProvider
            /**
             * Actual Routeing urls
             */
                .state('index', {
                    url: '/index',
                    controller: function(){
                        window.location = '/home';
                    }
                })
                .state('404', {
                    url: '/404',
                    controller: function(){
                        window.location = '/404_override';
                    }
                })
                .state('login', {
                    url: "/app/index/:userId/:accessToken",
                    templateUrl: "/public/js/app/modules/appModule/appDefaultTpl.html",
                    controller: 'AppLoginCtrl'
                })
                .state('dashboard', {
                    url: "/dashboard",
                    templateUrl: "/public/js/app/modules/dashboard/dashboardTemplate.html",
                    controller: 'DashboardCtrl',
                    resolve: {
                        authService: 'AuthService',
                        userModel: 'UserModel',
                        UserAuth: function(authService, userModel, $http, $q, $timeout){
                            console.log("Controller Route resolver");
                            var userid = authService.currentUserId();
                            console.log(userid);
                            var deferred = $q.defer();

                            if(userid == 0){
                                var data = getAuthorize(authService, userModel, $http, deferred, $timeout, loadDepedencies.dashboardModule);
                                console.log(data);
                                return deferred.promise;
                            }else{
                                return ;//authService.getAuthorize();
                            }
                        }
                    }

                })
                .state('dashboard_events', {
                    url: "/dashboard.events",
                    templateUrl: "/public/js/app/modules/dashboard/defaultEventsTpl.html",
                    controller: 'EventsLibraryCtrl',
                    resolve: {
                        authService: 'AuthService',
                        userModel: 'UserModel',
                        UserAuth: function(authService, userModel, $http, $q, $timeout){
                            console.log("Controller Route resolver");
                            var userid = authService.currentUserId();
                            console.log(userid);
                            var deferred = $q.defer();

                            if(userid == 0){
                                var data = getAuthorize(authService, userModel, $http, deferred, $timeout, loadDepedencies.dashboardModule);
                                console.log(data);
                                return deferred.promise;
                            }else{
                                return ;//authService.getAuthorize();
                            }
                        }
                    }

                })
                .state('dashboard_empty', {
                    url: "/dashboard.empty",
                    templateUrl: "/public/js/app/modules/dashboard/emptyDashboardTpl.html",
                    controller: 'EventsLibraryCtrl',
                    resolve: {
                        authService: 'AuthService',
                        userModel: 'UserModel',
                        UserAuth: function(authService, userModel, $http, $q, $timeout){
                            console.log("Controller Route resolver");
                            var userid = authService.currentUserId();
                            console.log(userid);
                            var deferred = $q.defer();

                            if(userid == 0){
                                var data = getAuthorize(authService, userModel, $http, deferred, $timeout, loadDepedencies.dashboardModule);
                                console.log(data);
                                return deferred.promise;
                            }else{
                                return ;//authService.getAuthorize();
                            }
                        }
                    }

                })
                .state('eventslibrary', {
                    url: "/eventslibrary",
                    templateUrl: "/public/js/app/modules/eventsLibrary/eventsLibraryTpl.html",
                    controller: 'EventsLibraryCtrl',
                    resolve: {
                        authService: 'AuthService',
                        userModel: 'UserModel',
                        UserAuth: function(authService, userModel, $http, $q, $timeout){
                            console.log("Controller Route resolver");
                            var userid = authService.currentUserId();
                            console.log(userid);
                            var deferred = $q.defer();

                            if(userid == 0){
                                var data = getAuthorize(authService, userModel, $http, deferred, $timeout, loadDepedencies.eventsLibrary);
                                console.log(data);
                                return deferred.promise;
                            }else{
                                return ;//authService.getAuthorize();
                            }
                        }
                    }
                })
                .state('eventslibrary_all', {
                    url: "/eventslibrary/:view",
                    templateUrl: "/public/js/app/modules/eventsLibrary/eventsLibraryAllTpl.html",
                    controller: 'EventsLibraryCtrl',
                    resolve: {
                        authService: 'AuthService',
                        userModel: 'UserModel',
                        UserAuth: function(authService, userModel, $http, $q, $timeout){
                            console.log("Controller Route resolver");
                            var userid = authService.currentUserId();
                            console.log(userid);
                            var deferred = $q.defer();

                            if(userid == 0){
                                var data = getAuthorize(authService, userModel, $http, deferred, $timeout, loadDepedencies.eventsLibrary);
                                console.log(data);
                                return deferred.promise;
                            }else{
                                return ;//authService.getAuthorize();
                            }
                        }
                    }
                })
                .state('eventslibrary_group', {
                    url: "/eventslibrary.group",
                    templateUrl: "/public/js/app/modules/eventsLibrary/groupEventsTpl.html",
                    resolve: {
                        UserAuth: function(){
                            hidePageLoad();
                        }
                    }
                    /*controller: 'EventsLibraryCtrl',
                     resolve: {
                     authService: 'AuthService',
                     userModel: 'UserModel',
                     UserAuth: function(authService, userModel, $http, $q, $timeout){
                     console.log("Controller Route resolver");
                     var userid = authService.currentUserId();
                     console.log(userid);
                     var deferred = $q.defer();

                     if(userid == 0){
                     var data = getAuthorize(authService, userModel, $http, deferred, $timeout, loadDepedencies.eventsLibrary);
                     console.log(data);
                     return deferred.promise;
                     }else{
                     return ;//authService.getAuthorize();
                     }
                     }
                     }
                     */
                })
                .state('createevent', {
                    url: "/createevent",
                    templateUrl: "/public/js/app/modules/createEvent/createEventTpl.html",
                    controller: 'CreateEventCtrl',
                    resolve: {
                        authService: 'AuthService',
                        userModel: 'UserModel',
                        UserAuth: function(authService, userModel, $http, $q, $timeout){
                            console.log("Controller Route resolver");
                            var userid = authService.currentUserId();
                            console.log(userid);
                            var deferred = $q.defer();

                            if(userid == 0){
                                var data = getAuthorize(authService, userModel, $http, deferred, $timeout, loadDepedencies.createEvent);
                                console.log(data);
                                return deferred.promise;
                            }else{
                                return ;//authService.getAuthorize();
                            }
                        }
                    }
                })
                .state('createevent_action', {
                    url: "/createevent/:action/:eventID",
                    templateUrl: "/public/js/app/modules/createEvent/createEventTpl.html",
                    controller: 'CreateEventCtrl',
                    resolve: {
                        authService: 'AuthService',
                        userModel: 'UserModel',
                        UserAuth: function(authService, userModel, $http, $q, $timeout){
                            console.log("create event action Route resolver");
                            var userid = authService.currentUserId();
                            console.log(userid);
                            var deferred = $q.defer();

                            if(userid == 0){
                                var data = getAuthorize(authService, userModel, $http, deferred, $timeout, loadDepedencies.createEvent);
                                console.log(data);
                                return deferred.promise;
                            }else{
                                return ;//authService.getAuthorize();
                            }
                        }
                    }
                })
                .state('createeventthankyou', {
                    url: "/createevent.thankyou",
                    templateUrl: "/public/js/app/modules/createEvent/createEventThankyouTpl.html",
                    resolve: {
                        UserAuth: function(){
                            hidePageLoad();
                        }
                    }
                })
                .state('guest', {
                    url: "/g/:name/:transactionID",
                    templateUrl: "/public/js/app/modules/guestModule/guestTpl.html",
                    controller: "GuestCtrl"
                    /*
                    resolve: {
                        authService: 'AuthService',
                        userModel: 'UserModel',
                        UserAuth: function(authService, userModel, $http, $q, $timeout){
                            console.log("Controller Route resolver");
                            var deferred = $q.defer();

                            var data = loadDepedencies.guestModule(deferred, $timeout);
                            console.log(data);
                            return deferred.promise;
                        }
                    }
                    */
                })
                .state('host', {
                    url: "/h/:name/:eventID",
                    templateUrl: "/public/js/app/modules/guestModule/guestTpl.html",
                    controller: "GuestCtrl"
                    /*
                    resolve: {
                        authService: 'AuthService',
                        userModel: 'UserModel',
                        UserAuth: function(authService, userModel, $http, $q, $timeout){
                            console.log("Controller Route resolver");
                            var deferred = $q.defer();

                            var data = loadDepedencies.guestModule(deferred, $timeout);
                            console.log(data);
                            return deferred.promise;
                        }
                    }
                    */
                })
                .state('contacts', {
                    url: "/contacts",
                    templateUrl: "/public/js/app/modules/contacts/contactsTpl.html",
                    controller: 'ContactsCtrl',
                    resolve: {
                        authService: 'AuthService',
                        userModel: 'UserModel',
                        UserAuth: function(authService, userModel, $http, $q, $timeout){
                            console.log("Controller Route resolver");
                            var userid = authService.currentUserId();
                            console.log(userid);
                            var deferred = $q.defer();

                            if(userid == 0){
                                var data = getAuthorize(authService, userModel, $http, deferred, $timeout, loadDepedencies.contactsModule);
                                console.log(data);
                                return deferred.promise;
                            }else{
                                return ;//authService.getAuthorize();
                            }
                        }
                    }

                })
                .state('contacts_addcontact', {
                    url: "/contacts/addcontact",
                    templateUrl: "/public/js/app/modules/contacts/addContactTpl.html",
                    controller: 'ContactsCtrl',
                    resolve: {
                        authService: 'AuthService',
                        userModel: 'UserModel',
                        UserAuth: function(authService, userModel, $http, $q, $timeout){
                            console.log("Controller Route resolver");
                            var userid = authService.currentUserId();
                            console.log(userid);
                            var deferred = $q.defer();

                            if(userid == 0){
                                var data = getAuthorize(authService, userModel, $http, deferred, $timeout, loadDepedencies.contactsModule);
                                console.log(data);
                                return deferred.promise;
                            }else{
                                return ;//authService.getAuthorize();
                            }
                        }
                    }
                })
                .state('contacts_groups', {
                    url: "/contacts/:view",
                    templateUrl: "/public/js/app/modules/contacts/contactsTpl.html",
                    controller: 'ContactsCtrl',
                    resolve: {
                        authService: 'AuthService',
                        userModel: 'UserModel',
                        UserAuth: function(authService, userModel, $http, $q, $timeout){
                            console.log("Controller Route resolver");
                            var userid = authService.currentUserId();
                            console.log(userid);
                            var deferred = $q.defer();

                            if(userid == 0){
                                var data = getAuthorize(authService, userModel, $http, deferred, $timeout, loadDepedencies.contactsModule);
                                console.log(data);
                                return deferred.promise;
                            }else{
                                return ;//authService.getAuthorize();
                            }
                        }
                    }
                })
                .state('contacts_import', {
                    url: "/contacts/import",
                    templateUrl: "/public/js/app/modules/contacts/importContactsTpl.html",
                    controller: 'ContactsCtrl',
                    resolve: {
                        UserAuth: function(){
                            hidePageLoad();
                        }
                    }
                    /*resolve: {
                        authService: 'AuthService',
                        userModel: 'UserModel',
                        UserAuth: function(authService, userModel, $http, $q, $timeout){
                            console.log("Controller Route resolver");
                            var userid = authService.currentUserId();
                            console.log(userid);
                            var deferred = $q.defer();

                            if(userid == 0){
                                var data = getAuthorize(authService, userModel, $http, deferred, $timeout, loadDepedencies.contactsModule);
                                console.log(data);
                                return deferred.promise;
                            }else{
                                return ;//authService.getAuthorize();
                            }
                        }
                    }*/
                })
                .state('contacts_social', {
                    url: "/contacts/social",
                    templateUrl: "/public/js/app/modules/contactsImport/contactsImportTpl1.html",
                    controller: 'ContactsCtrl',
                    resolve: {
                        UserAuth: function(){
                            hidePageLoad();
                        }
                    }
                    /*resolve: {
                     authService: 'AuthService',
                     userModel: 'UserModel',
                     UserAuth: function(authService, userModel, $http, $q, $timeout){
                     console.log("Controller Route resolver");
                     var userid = authService.currentUserId();
                     console.log(userid);
                     var deferred = $q.defer();

                     if(userid == 0){
                     var data = getAuthorize(authService, userModel, $http, deferred, $timeout, loadDepedencies.contactsModule);
                     console.log(data);
                     return deferred.promise;
                     }else{
                     return ;//authService.getAuthorize();
                     }
                     }
                     }*/
                })
                .state('analytics', {
                    url: '/analytics',
                    controller: 'AnalyticsCtrl',
                    templateUrl: "/public/js/app/modules/analytics/analyticsTpl.html",
                    resolve: {
                        authService: 'AuthService',
                        userModel: 'UserModel',
                        UserAuth: function(authService, userModel, $http, $q, $timeout){
                            console.log("Controller Route resolver");
                            var deferred = $q.defer();

                            var data = loadDepedencies.guestModule(deferred, $timeout);
                            console.log(data);

                            return deferred.promise;
                        }
                    }

                })
                .state('profile', {
                    url: "/profile",
                    templateUrl: "/public/js/app/modules/profileModule/profileTpl.html",
                    resolve: {
                        UserAuth: function(){
                            hidePageLoad();
                        }
                    }
                })
                .state('profile_billings', {
                    url: "/profile.billings",
                    templateUrl: "/public/js/app/modules/billingModule/billingDetailsTpl.html",
                    resolve: {
                        UserAuth: function(){
                            hidePageLoad();
                        }
                    }
                })
                .state('profile_resetpassword', {
                    url: "/profile.resetpassword",
                    templateUrl: "/public/js/app/modules/profileModule/resetPasswordTpl.html",
                    resolve: {
                        UserAuth: function(){
                            hidePageLoad();
                        }
                    }
                })
                .state('logout', {
                    url: "/signout",
                    controller: function(){
                        window.location = '/logout/index';
                    }
                });


            function hidePageLoad(){
                //HIDE LOADING INDICATOR
                jQuery("#status").fadeOut(); // will first fade out the loading animation
                jQuery("#preloader").delay(350).fadeOut("slow"); // will fade out the white DIV that covers the website.
            }

    var ajaxURL = {"errorLoggingURL":"/jserrorlog", "userDetails":"/user/getuserdata/", "userID":"/user/getuserid/"};

            function getAuthorize(AuthService, UserModel, $http, deferred, $timeout, callback){
                $http({method: 'GET', url: ajaxURL.userID.toString()}).then(function(res){
                    console.log(res);
                    var response = res.data;
                    if(response.status.toUpperCase() === 'SUCCESS'){
                        return getUserDetails(response.data.userID);
                    }else{
                        errorHandler(response);
                    }
                },errorHandler);

                function errorHandler(response){
                    console.log(response.description);
                    window.location = '/home';
                }

                function getUserDetails(userID){
                    $http({method: 'GET', url: ajaxURL.userDetails+userID}).then(function(response){
                        console.log(response);
                        var res = response.data;
                        if(res.status.toUpperCase() === 'SUCCESS'){
                            return setUserDetails(res.data);
                        }else{
                            errorHandler(res)
                        }
                    },errorHandler);
                }

                function setUserDetails(res){
                    var userAuth = {};
                    var userDetails = {};
                    userAuth.userID = res.userAPIKeys.userID;
                    userAuth.userName = res.userProfile.firstName+' '+res.userProfile.lastName;
                    userAuth.appID = res.userAPIKeys.appID;
                    userAuth.appSecret = res.userAPIKeys.appSecret;
                    userAuth.accessToken = res.userAPIKeys.accessToken;
                    AuthService.login(userAuth);

                    userDetails.userID = res.userAPIKeys.userID;
                    userDetails.userName = res.userProfile.firstName+' '+res.userProfile.lastName;
                    userDetails.firstName = res.userProfile.firstName;
                    userDetails.lastName = res.userProfile.lastName;
                    userDetails.photoURL = res.userProfile.photoURL;
                    userDetails.gender = res.userProfile.gender;
                    userDetails.userEmail = res.userProfile.hostEmailID;
                    userDetails.userType = res.userProfile.userType;
                    userDetails.userStatus = res.userProfile.status;
                    userDetails.planExpired = res.userPayment.paymentStatus;
                    userDetails.rsvpEmailID = res.userProfile.rsvpEmailID;
                    userDetails.timeZone = res.userProfile.timeZone;
                    userDetails.businessDBA = res.userProfile.businessDBA;
                    userDetails.personalizedURL = res.userProfile.personalizedURL;

                    UserModel.setUser(userDetails);

                    var paymentStatus = userDetails.planExpired;
                    if(paymentStatus){
                        //TODO CONTINUEUE
                    }else{
                        //TODO REDIRECT TO PAYMENT SCREEN
                    }

                    //return deferred.resolve('user details loaded'); //{userAuth: userAuth, userDetails: userDetails};
                    //$scope.$broadcast('userAuthorized');
                    callback(deferred, $timeout);
                }

            }

            loadDepedencies.createEvent = function(deferred, $timeout){
                require([
                        //'app/modules/createEvent/createEventService',
                        //'app/modules/createEvent/createEventDirective',
                        //'app/modules/createEvent/createEventModel',
                        //'app/modules/createEvent/createEventCtrl'
                        ], function(){
                            console.log("create event modules loaded");
                            $timeout(function() {
                                hidePageLoad();
                                return deferred.resolve('Dependencies loaded');
                            }, 10);
                          }
                        );
            };

            loadDepedencies.eventsLibrary = function(deferred, $timeout){
                require([
                            //'app/modules/eventsLibrary/eventsLibraryModel',
                            //'app/modules/eventsLibrary/eventsLibraryCtrl',
                            //'app/modules/eventsLibrary/eventsLibraryDirective'
                        ],function(){
                            console.log("events library modules loaded");
                            $timeout(function() {
                                hidePageLoad();
                                return deferred.resolve('Dependencies loaded');
                            }, 10);
                        });
            };

            loadDepedencies.guestModule = function(deferred, $timeout){
                require([
                            //'app/modules/guestModule/guestCtrl',
                            //'app/services/guestService',
                            //'app/modules/guestModule/guestDirective'
                        ],function(){
                            console.log("guest modules loaded");
                            $timeout(function() {
                                hidePageLoad();
                                return deferred.resolve('Dependencies loaded');
                            }, 10);
                        });
            };

            loadDepedencies.dashboardModule = function(deferred, $timeout){
                require([
                            'app/modules/dashboard/dashboardModel',
                            'app/modules/dashboard/dashboardCtrl',
                            'app/modules/dashboard/defaultEventsCtrl'
                        ],function(){
                            console.log("dashboard modules loaded");
                            $timeout(function() {
                                hidePageLoad();
                                return deferred.resolve('Dependencies loaded');
                            }, 10);
                        });
            };

            loadDepedencies.contactsModule = function(deferred, $timeout){
                require([
                            //'app/modules/contactsImport/contacts-import-api',
                            //'app/services/contactsService',
                            //'app/modules/contacts/contactsModel',
                            //'app/modules/contacts/groupsModel',
                            //'app/modules/contacts/contactsCtrl'
                        ],function(){
                            console.log("contacts modules loaded");
                            $timeout(function() {
                                hidePageLoad();
                                return deferred.resolve('Dependencies loaded');
                            }, 10);
                        });
            };
    }]);

});



